/*
 *  Copyright (C) 1998-99 Luca Deri <deri@unipi.it>
 *                      
 *  			  Centro SERRA, University of Pisa
 *  			  http://www-serra.unipi.it/
 *  					
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#define GRAPH_H /* 
		   Do not use local defs for gifgraph 
		   (included by ntop.h) 
		*/

#include "ntop.h"

#include "gdc.h"
#include "gdchart.h"
#include "gdcpie.h"

#ifdef MULTITHREADED
extern pthread_mutex_t graphMutex;
#endif

extern char *protoIPTrafficInfos[MAX_NUM_HANDLED_IP_PROTOCOLS];
extern u_short numIpProtosToMonitor;
extern SimpleProtoTrafficInfo *ipProtoStats;
extern pcap_t *pcapPtr[MAX_NUM_DEVICES];
extern u_int numDevices;
extern char device[MAX_NUM_DEVICES][8];
extern float last60MinutesThpt[60], last24HoursThpt[24], last30daysThpt[30];
extern unsigned long numThptSamples;
extern time_t actTime, initialSniffTime, lastRefreshTime;
extern TrafficCounter ethernetPkts, ethernetBytes, ipBytes;
extern TrafficCounter broadcastPkts, multicastPkts;
extern float peakThroughput, actualThpt, lastMinThpt, lastFiveMinsThpt;
extern PacketStats rcvdPktStats;
extern TrafficCounter tcpBytes, udpBytes, icmpBytes, dlcBytes, ipxBytes, decnetBytes,
  netbiosBytes, arpRarpBytes, atalkBytes, ospfBytes, igmpBytes, otherBytes, osiBytes, otherIpBytes;
extern SimpleProtoTrafficInfo tcpGlobalTrafficStats, udpGlobalTrafficStats, icmpGlobalTrafficStats;

static unsigned long clr[] = { 0x0000FF, 0x00FF00, 0xFF0000,
			       0xFF4040L, 0x80FF80L, 0x8080FFL, 
			       0xFF80FFL, 0xFFFF80L, 0x80FFFFL,
			       0x0080FFL };

/* ************************ */

void pktSizeDistribPie() {
  char tmpStr[256], fileName[64];
  float p[7];
  char	*lbl[] = { "< 64", "< 128", "< 256", "< 512", "< 1024", "< 1518", "> 1518" };
  int len, expl[] = { 5, 10, 15, 20, 25, 30, 35 };
  FILE *fd;

  tmpnam(fileName);

  fd = fopen(fileName, "wb");

  p[0] = (float)(100*rcvdPktStats.upTo64)/(float)ethernetPkts;
  p[1] = (float)(100*rcvdPktStats.upTo128)/(float)ethernetPkts;
  p[2] = (float)(100*rcvdPktStats.upTo256)/(float)ethernetPkts;
  p[3] = (float)(100*rcvdPktStats.upTo512)/(float)ethernetPkts;
  p[4] = (float)(100*rcvdPktStats.upTo1024)/(float)ethernetPkts;
  p[5] = (float)(100*rcvdPktStats.upTo1518)/(float)ethernetPkts;
  p[6] = (float)(100*rcvdPktStats.above1518)/(float)ethernetPkts;

  GDCPIE_LineColor = 0x000000L;
  GDCPIE_explode   = expl;    /* default: NULL - no explosion */
  GDCPIE_Color     = clr;
  GDCPIE_BGColor   = 0xFFFFFFL;
  GDCPIE_EdgeColor = 0x000000L;	/* default is GDCPIE_NOCOLOR */
  GDCPIE_percent_labels = GDCPIE_PCT_NONE;

#ifdef MULTITHREADED
  accessMutex(&graphMutex);
#endif
  
  pie_gif(250,			/* width */
	  250,			/* height */
	  fd,			/* open file pointer */
	  GDC_3DPIE,		/* or GDC_2DPIE */
	  7,			/* number of slices */
	  lbl,			/* slice labels (unlike out_gif(), can be NULL */
	  p);			/* data array */

  fclose(fd);

#ifdef MULTITHREADED
  releaseMutex(&graphMutex);
#endif

  fd = fopen(fileName, "rb");
  for(;;) {
    len = fread(tmpStr, sizeof(char), 255, fd);
    if(len <= 0) break;
    sendStringLen(tmpStr, len);
  }
  
  fclose(fd);  

  unlink(fileName);
}


/* ************************ */
void ipProtoDistribPie() {
  char tmpStr[256], fileName[64];
  float p[3];
  char	*lbl[] = { "Loc", "Rem->Loc", "Loc->Rem" };
  int len, expl[] = { 0, 20, 30 };
  FILE *fd;
  TrafficCounter unicastPkts;

  tmpnam(fileName);
   
  fd = fopen(fileName, "wb");

  unicastPkts = ethernetPkts - broadcastPkts - multicastPkts;
  p[0] = (float)(tcpGlobalTrafficStats.local+udpGlobalTrafficStats.local)/1024;
  p[1] = (float)(tcpGlobalTrafficStats.remote2local+udpGlobalTrafficStats.remote2local)/1024;
  p[2] = 100-p[0]-p[1]; if(p[2] < 0) p[2] = 0;

#ifdef MULTITHREADED
  accessMutex(&graphMutex);
#endif

  GDCPIE_LineColor = 0x000000L;
  GDCPIE_explode   = expl;    /* default: NULL - no explosion */
  GDCPIE_Color     = clr;
  GDCPIE_BGColor   = 0xFFFFFFL;
  GDCPIE_EdgeColor = 0x000000L;	/* default is GDCPIE_NOCOLOR */
  GDCPIE_percent_labels = GDCPIE_PCT_NONE;
  
  pie_gif(250,			/* width */
	  250,			/* height */
	  fd,			/* open file pointer */
	  GDC_3DPIE,		/* or GDC_2DPIE */
	  3,			/* number of slices */
	  lbl,			/* slice labels (unlike out_gif(), can be NULL */
	  p);			/* data array */

  fclose(fd);

#ifdef MULTITHREADED
  releaseMutex(&graphMutex);
#endif
  
  fd = fopen(fileName, "rb");
  for(;;) {
    len = fread(tmpStr, sizeof(char), 255, fd);
    if(len <= 0) break;
    sendStringLen(tmpStr, len);
  }
  
  fclose(fd);  

  unlink(fileName);
}

/* ************************ */

void interfaceTrafficPie() {
  char tmpStr[256], fileName[64];
  float p[MAX_NUM_DEVICES];
  int i, len, expl[] = { 0, 20, 30, 40, 50, 60 };
  FILE *fd;
  TrafficCounter totPkts=0;
  struct pcap_stat stat;
  char	*lbl[MAX_NUM_DEVICES];

  tmpnam(fileName);
   
  fd = fopen(fileName, "wb");

  for(i=0; i<numDevices; i++) {
    lbl[i] = device[i];
    if (pcap_stats(pcapPtr[i], &stat) >= 0) {
      p[i] = stat.ps_recv;
      totPkts += stat.ps_recv;
    }
  }

  if(totPkts == 0)
    totPkts++;

  for(i=0; i<numDevices; i++) {
      p[i] = 100*(((float)p[i])/totPkts);
  }

#ifdef MULTITHREADED
  accessMutex(&graphMutex);
#endif

  GDCPIE_LineColor = 0x000000L;
  GDCPIE_explode   = expl;    /* default: NULL - no explosion */
  GDCPIE_Color     = clr;
  GDCPIE_BGColor   = 0xFFFFFFL;
  GDCPIE_EdgeColor = 0x000000L;	/* default is GDCPIE_NOCOLOR */
  GDCPIE_percent_labels = GDCPIE_PCT_RIGHT;
  
  pie_gif(250,			/* width */
	  250,			/* height */
	  fd,			/* open file pointer */
	  GDC_3DPIE,		/* or GDC_2DPIE */
	  numDevices,		/* number of slices */
	  lbl,		/* slice labels (unlike out_gif(), can be NULL */
	  p);			/* data array */

  fclose(fd);

  #ifdef MULTITHREADED
  releaseMutex(&graphMutex);
#endif

  fd = fopen(fileName, "rb");
  for(;;) {
    len = fread(tmpStr, sizeof(char), 255, fd);
    if(len <= 0) break;
    sendStringLen(tmpStr, len);
  }
  
  fclose(fd);  

  unlink(fileName);
}

/* ************************ */

void pktCastDistribPie() {
  char tmpStr[256], fileName[64];
  float p[3];
  char	*lbl[] = { "Unicast", "Broadcast", "Multicast" };
  int len, expl[] = { 0, 20, 30 };
  FILE *fd;
  TrafficCounter unicastPkts;

  tmpnam(fileName);
  
  fd = fopen(fileName, "wb");

  unicastPkts = ethernetPkts - broadcastPkts - multicastPkts;
  p[0] = (float)(100*unicastPkts)/(float)ethernetPkts;
  p[1] = (float)(100*broadcastPkts)/(float)ethernetPkts;
  p[2] = 100-p[0]-p[1]; if(p[2] < 0) p[2] = 0;

 #ifdef MULTITHREADED
  accessMutex(&graphMutex);
#endif

  GDCPIE_LineColor = 0x000000L;
  GDCPIE_explode   = expl;    /* default: NULL - no explosion */
  GDCPIE_Color     = clr;
  GDCPIE_BGColor   = 0xFFFFFFL;
  GDCPIE_EdgeColor = 0x000000L;	/* default is GDCPIE_NOCOLOR */
  GDCPIE_percent_labels = GDCPIE_PCT_NONE;
  
  pie_gif(250,			/* width */
	  250,			/* height */
	  fd,			/* open file pointer */
	  GDC_3DPIE,		/* or GDC_2DPIE */
	  3,			/* number of slices */
	  lbl,			/* slice labels (unlike out_gif(), can be NULL */
	  p);			/* data array */

  fclose(fd);

#ifdef MULTITHREADED
  releaseMutex(&graphMutex);
#endif

  fd = fopen(fileName, "rb");
  for(;;) {
    len = fread(tmpStr, sizeof(char), 255, fd);
    if(len <= 0) break;
    sendStringLen(tmpStr, len);
  }
  
  fclose(fd);  

  unlink(fileName);
}

/* ************************ */

void drawTrafficPie() {
  char tmpStr[256], fileName[64];
  TrafficCounter ip, nonIp;
  float p[2];
  char	*lbl[] = { "IP", "Non IP" };
  int len, expl[] = { 5, 5 };
  FILE *fd;

  ip = ipBytes;
  nonIp = ethernetBytes-ipBytes;

  tmpnam(fileName);
  fd = fopen(fileName, "wb");

  p[0] = ip*100/ethernetBytes;
  p[1] = 100-p[0];

#ifdef MULTITHREADED
  accessMutex(&graphMutex);
#endif

  GDCPIE_LineColor = 0x000000L;
  GDCPIE_BGColor   = 0xFFFFFFL;
  GDCPIE_EdgeColor = 0x000000L;	/* default is GDCPIE_NOCOLOR */
  GDCPIE_explode   = expl;    /* default: NULL - no explosion */
  GDCPIE_Color     = clr;

  pie_gif(250,			/* width */
	  250,			/* height */
	  fd,			/* open file pointer */
	  GDC_3DPIE,		/* or GDC_2DPIE */
	  2,			/* number of slices */
	  lbl,			/* slice labels (unlike out_gif(), can be NULL */
	  p);			/* data array */

  fclose(fd);

  #ifdef MULTITHREADED
  releaseMutex(&graphMutex);
#endif

  fd = fopen(fileName, "rb");
  for(;;) {
    len = fread(tmpStr, sizeof(char), 255, fd);
    if(len <= 0) break;
    sendStringLen(tmpStr, len);
  }
  
  fclose(fd);  

  unlink(fileName);
}

/* ************************ */

void drawThptGraph(int sortedColumn) {
  char tmpStr[256], fileName[64];
  int i, len;
  char  labels[60][32];
  char  *lbls[60];
  FILE *fd;
  time_t tmpTime;
  unsigned long  sc[2]    = { 0xFF0000, 0x8080FF };

#ifdef MULTITHREADED
  accessMutex(&graphMutex);
#endif

  GDC_BGColor   = 0xFFFFFFL;                  /* backgound color (white) */
  GDC_LineColor = 0x000000L;                  /* line color      (black) */
  GDC_SetColor  = &(sc[0]);                   /* assign set colors */
  GDC_ytitle = "Throughput";

  for(i=0; i<60; i++) {
    lbls[i] = labels[i];
    labels[i][0] = '\0';
  }

  tmpnam(fileName);
  fd = fopen(fileName, "wb");

  switch(sortedColumn) {
  case 1: /* 60 Minutes */
    len = numThptSamples;
    if(len > 60) len = 60;
    for(i=0; i<len; i++) {
      tmpTime = actTime-i*60;
      strcpy(labels[i], ctime(&tmpTime));
    }
    GDC_title = "Last 60 Minutes Average Throughput";
    out_graph(600, 450,            /* width, height           */
	      fd,                  /* open FILE pointer       */
	      GDC_AREA,            /* chart type              */
	      60,                  /* num points per data set */
	      lbls,                /* X labels array of char* */
	      1,                   /* number of data sets     */
	      &last60MinutesThpt); /* dataset 1               */
    break;
  case 2: /* 24 Hours */
    len = numThptSamples/24;
    if(len > 24) len = 24;
    for(i=0; i<len; i++) {
      tmpTime = actTime-(i*60*60);
      strcpy(labels[i], ctime(&tmpTime));
    }
    GDC_title = "Last 24 Hours Average Throughput";    
    out_graph(600, 450,            /* width, height           */
	      fd,                  /* open FILE pointer       */
	      GDC_3DAREA,          /* chart type              */
	      24,                  /* num points per data set */
	      lbls,                /* X labels array of char* */
	      1,                   /* number of data sets     */
	      &last24HoursThpt);   /* dataset 1               */
    break;
  case 3: /* 30 Days */
    len = numThptSamples/(24*30*60);
    if(len > 30) len = 30;
    for(i=0; i<len; i++) {
      tmpTime = actTime-(i*(60*24));
      strcpy(labels[i], ctime(&tmpTime));
    }
    GDC_title = "Last 30 Days Average Throughput";    
    out_graph(600, 450,            /* width, height           */
	      fd,                  /* open FILE pointer       */
	      GDC_3DAREA,          /* chart type              */
	      30,                  /* num points per data set */
	      lbls,                /* X labels array of char* */
	      1,                   /* number of data sets     */
	      &last30daysThpt);    /* dataset 1               */
    break;
  }

  fclose(fd);

#ifdef MULTITHREADED
  releaseMutex(&graphMutex);
#endif

  fd = fopen(fileName, "rb");
  for(;;) {
    len = fread(tmpStr, sizeof(char), 255, fd);
    if(len <= 0) break;
    sendStringLen(tmpStr, len);
  }
  
  fclose(fd);  

  unlink(fileName);
}


/* ************************ */

void drawGlobalProtoDistribution() {
  char tmpStr[256], fileName[64];
  TrafficCounter ip, nonIp;
  int len;
  float p[14];
  unsigned long sc = 0xC8C8FF;
  char	*lbl[] = { "TCP", "UDP", "ICMP", "Other IP", 
		   "(R)ARP", "DLC", "IPX", "Decnet",
		   "AppleTalk","OSPF","NetBios",
		   "IGMP","OSI","Other" };
  FILE *fd;

  ip = ipBytes;
  nonIp = ethernetBytes-ipBytes;

  tmpnam(fileName);
  fd = fopen(fileName, "wb");

  p[0] = tcpBytes;
  p[1] = udpBytes;
  p[2] = icmpBytes;
  p[3] = otherIpBytes;
  p[4] = arpRarpBytes;
  p[5] = dlcBytes;
  p[6] = ipxBytes;
  p[7] = decnetBytes;
  p[8] = atalkBytes;
  p[9] = ospfBytes;
  p[10] = netbiosBytes;
  p[11] = igmpBytes ;
  p[12] = osiBytes;
  p[13] = otherBytes;
  
#ifdef MULTITHREADED
  accessMutex(&graphMutex);
#endif

  GDC_LineColor = 0x000000L;
  GDC_BGColor   = 0xFFFFFFL;
  GDC_SetColor  = &sc;
  GDC_yaxis=0;
  GDC_requested_ymin = 0;

  out_graph(600, 250,	/* width/height */
	    fd,		  	    /* open file pointer */
	    GDC_3DBAR,		/* or GDC_2DBAR */
	    14,			    /* number of slices */
	    lbl,		    /* slice labels (unlike out_gif(), can be NULL */
	    1,
	    p);   			/* data array */

  fclose(fd);
  
#ifdef MULTITHREADED
  releaseMutex(&graphMutex);
#endif

  fd = fopen(fileName, "rb");
  for(;;) {
    len = fread(tmpStr, sizeof(char), 255, fd);
    if(len <= 0) break;
    sendStringLen(tmpStr, len);
  }
  
  fclose(fd);  

  unlink(fileName);
}

/* ************************ */

void drawGlobalIpProtoDistribution() {
  char tmpStr[256], fileName[64];
  TrafficCounter ip, nonIp;
  int len, i;
  float p[14];
  unsigned long sc = 0xC8C8FF;
  char	*lbl[256];
  FILE *fd;

  p[numIpProtosToMonitor] = 0;

  for(i=0; i<numIpProtosToMonitor; i++) {
    p[i]  = (float)ipProtoStats[i].local+ipProtoStats[i].remote;
    p[i] += (float)ipProtoStats[i].remote2local+ipProtoStats[i].local2remote;
    p[numIpProtosToMonitor] += p[i];
    lbl[i] = protoIPTrafficInfos[i];
  }

  tmpnam(fileName);
  fd = fopen(fileName, "wb");
  
#ifdef MULTITHREADED
  accessMutex(&graphMutex);
#endif

  GDC_LineColor = 0x000000L;
  GDC_BGColor   = 0xFFFFFFL;
  GDC_SetColor  = &sc;
  GDC_yaxis=0;

  out_graph(600, 250,		/* width/height */
	    fd,			/* open file pointer */
	    GDC_3DBAR,		/* or GDC_2DBAR */
	    numIpProtosToMonitor,			/* number of slices */
	    lbl,		/* slice labels (unlike out_gif(), can be NULL */
	    1,
	    p);			/* data array */

  fclose(fd);

#ifdef MULTITHREADED
  releaseMutex(&graphMutex);
#endif

  fd = fopen(fileName, "rb");
  for(;;) {
    len = fread(tmpStr, sizeof(char), 255, fd);
    if(len <= 0) break;
    sendStringLen(tmpStr, len);
  }
  
  fclose(fd);  

  unlink(fileName);
}
