char * version = "1.3.1";
char * osName  = "sparc-sun-solaris2.6";
char * author  = "Luca Deri <deri@ntop.org>";
