/*
 *  Copyright (C) 1998-2000 Luca Deri <deri@ntop.org>
 *                          Portions by Stefano Suin <stefano@ntop.org>
 *
 *		  	  Centro SERRA, University of Pisa
 *		 	  http://www.ntop.org/
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "ntop.h"
#include "globals-report.h"

#ifndef WIN32
#include <pwd.h>
#endif

/* Forward */
void handleSingleWebConnection(fd_set *fdmask);

/* **************************************** */

void initializeWeb() {
  columnSort = 0;
  addDefaultAdminUser();
}

/* **************************************** */

void* handleWebConnections(void* notUsed) {
#ifndef MULTITHREADED
  struct timeval wait_time;
#else
  int rc;
#endif
  fd_set mask, mask_copy;
  int topSock = sock;

  FD_ZERO(&mask);
  FD_SET((unsigned int)sock, &mask);
#ifdef HAVE_OPENSSL
  if(sslInitialized) {
    FD_SET(sock_ssl, &mask);
    if(sock_ssl > topSock)
      topSock = sock_ssl;
  }
#endif

  memcpy(&mask_copy, &mask, sizeof(fd_set));

#ifndef MULTITHREADED
  /* select returns immediately */
  wait_time.tv_sec = 0, wait_time.tv_usec = 0;
  if(select(topSock+1, &mask, 0, 0, &wait_time) == 1)
    handleSingleWebConnection(&mask);
#else
  while(1) {
#ifdef DEBUG
    printf("Select(ing)....\n");
#endif
    memcpy(&mask, &mask_copy, sizeof(fd_set));
    rc = select(topSock+1, &mask, 0, 0, NULL /* Infinite */);
#ifdef DEBUG
    printf("select returned: %d\n", rc);
#endif
    if(rc > 0)
      handleSingleWebConnection(&mask);
  }
#endif

return(NULL); /* NOTREACHED */
}


/* ************************************* */

#ifndef WIN32
void execCGI(char* cgiName) {
  char* userName = "nobody", line[384], buf[256];
  struct passwd * newUser = NULL;
  FILE *fd;
  int num, i;

  if(!(newUser = getpwnam(userName))) {
    printf("WARNING: unable to find user %s\n", userName);
    return;
  } else {
    setuid (newUser->pw_uid);
    setgid (newUser->pw_gid);
  }

  for(num=0, i=0; cgiName[i] != '\0'; i++)
    if(cgiName[i] == '?') {
      cgiName[i] = '\0';
      sprintf(buf, "QUERY_STRING=%s", &cgiName[i+1]);
      putenv(buf);
      num = 1;
      break;
    }

  if(num == 0) putenv("QUERY_STRING=");

  sprintf(line, "%s/cgi/%s", getenv("PWD"), cgiName);

  if((fd = popen(line, "r")) == NULL) {
    printf("WARNING: unable to exec %s\n", cgiName);
    return;
  } else {
    while(!feof(fd)) {
      num = fread(line, 1, 383, fd);
      if(num > 0)
	sendStringLen(line, num);
    }
    pclose(fd);
  }
}
#endif

/* **************************************** */

#if (defined(HAVE_DIRENT_H) && defined(HAVE_DLFCN_H)) || defined(WIN32) || defined(HPUX) || defined(AIX)
void showPluginsList() {
  FlowFilterList *flows = flowsList;
  short printHeader = 0;
  char tmpBuf[BUF_SIZE];

  while(flows != NULL) {
    if((flows->pluginPtr != NULL)
       && (flows->pluginPtr->pluginURLname != NULL)) {

      if(!printHeader) {
	/* printHTTPheader(); */
	sendString("<center><H1>Active Plugins</H1>\n<p>"
		   "<TABLE BORDER><TR>\n");
	sendString("<TR><TH>Name</TH><TH>Description</TH>"
		   "<TH>Version</TH>"
		   "<TH>Author</TH></TR>\n");
	printHeader = 1;
      }

      sprintf(tmpBuf, "<TR %s><TH ALIGN=LEFT><A HREF=/plugins/%s>%s</TH>"
	      "<TD ALIGN=LEFT>%s</TD>"
	      "<TD ALIGN=CENTER>%s</TD>"
	      "<TD ALIGN=LEFT>%s</TD></TR>\n",
	      getRowColor(),
	      flows->pluginPtr->pluginURLname,
	      flows->pluginPtr->pluginURLname,
	      flows->pluginPtr->pluginDescr,
	      flows->pluginPtr->pluginVersion,
	      flows->pluginPtr->pluginAuthor);
      sendString(tmpBuf);
    }

    flows = flows->next;
  }

  if(!printHeader) {
   sendString("<HTML><BODY BGCOLOR=#FFFFFF><P><CENTER><H1>"
	       "<i>No Plugins available</i></H1>"
	      "</CENTER></FONT></CENTER><p>\n");
  } else {
    sendString("</TABLE><p>\n");
  }
}
#else /* defined(HAVE_DIRENT_H) && defined(HAVE_DLFCN_H) */

void showPluginsList() {
  ;
}

void loadPlugins() {
  ;
}

void unloadPlugins() {
  ;
}

#endif /* defined(HAVE_DIRENT_H) && defined(HAVE_DLFCN_H) */

/* ************************************* */

void handleSingleWebConnection(fd_set *fdmask) {
  struct sockaddr_in from;
  int from_len = sizeof(from);

  if(FD_ISSET(sock, fdmask)) {
#ifdef DEBUG
    printf("Accepting HTTP request...\n");
#endif
    newSock = accept(sock, (struct sockaddr*)&from, &from_len);
  } else {
#ifdef DEBUG
    if(sslInitialized) printf("Accepting HTTPS request...\n");
#endif
#ifdef HAVE_OPENSSL
    if(sslInitialized) { newSock  = accept(sock_ssl, (struct sockaddr*)&from, &from_len); }
#else
    ;
#endif
  }

#ifdef DEBUG
  printf("Request accepted (sock=%d)\n", newSock);
#endif

  if(newSock > 0) {
    int childpid, i;

#ifdef HAVE_OPENSSL
    if(sslInitialized) 
      if(FD_ISSET(sock_ssl, fdmask))
	if(accept_ssl_connection(newSock) == -1) {
	  printf("Unable to accept SSL connection\n");
	  closeNwSocket(&newSock);
	  return;
	} else {
	  newSock = -newSock;
	}
#endif /* HAVE_OPENSSL */

#ifdef HAVE_LIBWRAP
    {
      struct request_info req;
      request_init(&req, RQ_DAEMON, DAEMONNAME, RQ_FILE, newSock, NULL);
      fromhost(&req);
      if (!hosts_access(&req)) {
	closelog(); /* just in case */
	openlog(DAEMONNAME,LOG_PID,SYSLOG_FACILITY);
	syslog(deny_severity, "refused connect from %s", eval_client(&req));
      }
      else
	handleHTTPrequest();
    }
#else
    handleHTTPrequest();
#endif /* HAVE_LIBWRAP */

    closeNwSocket(&newSock);

  }
}

/* ******************************* */

void initWeb(int webPort, char* webAddr) {
    int sockopt = 1, i;
    struct sockaddr_in sin;

    actualReportDeviceId = 0;

#ifdef DEBUG
    numChildren = 0;
#endif
    sin.sin_family      = AF_INET;
    sin.sin_port        = (int)htons((unsigned short int)webPort);
    sin.sin_addr.s_addr = INADDR_ANY;

#ifndef WIN32
    if (webAddr) {      /* Code added to be able to bind to a particular interface */
      if (!inet_aton(webAddr,&sin.sin_addr))
	printf("Unable to convert address '%s'...\n"
	       "Not binding to a particular interface!\n",  webAddr);
     }
#endif

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if(sock < 0) {
	printf("unable to create a new socket");
	exit(-1);
      }

    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char *)&sockopt, sizeof(sockopt));

#ifdef HAVE_OPENSSL
    if(sslInitialized) {
      sock_ssl = socket(AF_INET, SOCK_STREAM, 0);
      if(sock_ssl < 0) {
	printf("unable to create a new socket");
	exit(-1);
      }
      
      setsockopt(sock_ssl, SOL_SOCKET, SO_REUSEADDR, (char *)&sockopt, sizeof(sockopt));
    }
#endif


    if(bind(sock, (struct sockaddr *)&sin, sizeof(sin)) < 0) {
      printf("bind: port %d already in use.", webPort);
      closeNwSocket(&sock);
      exit(-1);
    }

#ifdef HAVE_OPENSSL
    if(sslInitialized) {
      sin.sin_family      = AF_INET;
      sin.sin_port        = (int)htons(webPort+1);
      sin.sin_addr.s_addr = INADDR_ANY;
      
      if(bind(sock_ssl, (struct sockaddr *)&sin, sizeof(sin)) < 0) {
	printf("bind: port %d already in use.", webPort);
	closeNwSocket(&sock_ssl);
	exit(-1);
      }
    }
#endif


    if(listen(sock, 5) < 0) {
      printf("listen error.\n");
      closeNwSocket(&sock);
      exit(-1);
    } else {
#ifdef HAVE_OPENSSL
      if(sslInitialized) 
	if(listen(sock_ssl, 5) < 0) {
	  printf("listen error.\n");
	  closeNwSocket(&sock_ssl);
	  exit(-1);
	}
#endif

      /* Courtesy of Daniel Savard <daniel.savard@gespro.com> */
      if (webAddr) {
	printf("Waiting for HTTP connections on %s port %d...\n",
		webAddr, webPort);
      } else {
	printf("Waiting for HTTP connections on port %d...\n",
		webPort);
      }

#ifdef HAVE_OPENSSL
      if(sslInitialized) 
	printf("Waiting for HTTPS (SSL) connections on port %d...\n",
	       webPort+1);
#endif
    }

#ifdef MULTITHREADED
    createThread(&handleWebConnectionsThreadId, handleWebConnections, NULL);
#endif
}

/* ******************************* */

char* makeHostLink(HostTraffic *el, short mode,
		   short cutName, short addCountryFlag) {
  static char buf[5][384];
  char symIp[256], *tmpStr, linkName[256], flag[128];
  char *blinkOn, *blinkOff;
  short specialMacAddress = 0;
  static short bufIdx=0;
  short usedEthAddress=0;

  if(el == NULL)
    return("&nbsp;");

  if(broadcastHost(el)) {
    if(mode == LONG_FORMAT)
      return("<TH ALIGN=LEFT>&lt;broadcast&gt;</TH>");
    else
      return("&lt;broadcast&gt;");
  }


  if(subnetLocalHost(el)
     && FD_ISSET((unsigned long)(el->hostIpAddress.s_addr) % 256 /* C-class */,
		 &ipTrafficMatrixPromiscHosts)) {
    /* Promiscuous mode */
    blinkOn = "<BLINK><FONT COLOR=#FF0000>", blinkOff = "</FONT></BLINK>";
  } else {
    blinkOn = "", blinkOff = "";
  }

  bufIdx = (bufIdx+1)%5;

#ifdef MULTITHREADED
  accessMutex(&addressResolutionMutex, "makeHostLink");
#endif

  switch(numericFlag) {
  case 0: /* symbolic */
    tmpStr = el->hostSymIpAddress;

    if(tmpStr == NULL) {
      /* The DNS is still getting the entry name */
      if(el->hostNumIpAddress[0] != '\0')
	strcpy(symIp, el->hostNumIpAddress);
      else {
	strcpy(symIp, el->ethAddressString);
	usedEthAddress = 1;
      }
    } else if(tmpStr[0] != '\0') {
      strcpy(symIp, tmpStr);
      if(tmpStr[strlen(tmpStr)-1] == ']') /* No "... [MAC]" */ {
	usedEthAddress = 1;
	specialMacAddress = 1;
      } else {
	if(cutName && (symIp[0] != '*')
	   && strcmp(symIp, el->hostNumIpAddress)) {
	  int i;

	  for(i=0; symIp[i] != '\0'; i++)
	    if(symIp[i] == '.') {
	      symIp[i] = '\0';
	      break;
	    }
	}
      }
    } else {
      strcpy(symIp, el->ethAddressString);
      usedEthAddress = 1;
    }
    break;
  case 1:   /* numeric */
    if(el->hostNumIpAddress[0] != '\0')
      strcpy(symIp, el->hostNumIpAddress);
    else {
      strcpy(symIp, el->ethAddressString);
      usedEthAddress = 1;
    }
    break;
  case 2: /* ethernet address */
    strcpy(symIp, el->ethAddressString);
    usedEthAddress = 1;
    if(symIp[0] == '\0') strcpy(symIp, separator);
    break;
  case 3: /* ethernet constructor */
    strcpy(symIp, getVendorInfo(el->ethAddress, 1));
    usedEthAddress = 1;
    if(symIp[0] == '\0') strcpy(symIp, el->ethAddressString);
    if(symIp[0] == '\0') strcpy(symIp, separator);
    break;
  }

#ifdef MULTITHREADED
    releaseMutex(&addressResolutionMutex);
#endif

  if(specialMacAddress) {
    tmpStr = el->ethAddressString;
#ifdef DEBUG
    printf("->'%s/%s'\n", symIp, el->ethAddressString);
#endif
  } else {
    if(el->hostNumIpAddress[0] != '\0')
      tmpStr = el->hostNumIpAddress;
    else
      tmpStr = symIp;
  }

  strcpy(linkName, tmpStr);

  if(usedEthAddress) {
    /* Patch for ethernet addresses and MS Explorer */
    int i;

    for(i=0; linkName[i] != '\0'; i++)
      if(linkName[i] == ':')
	linkName[i] = '_';
  }

  if(addCountryFlag == 0)
    flag[0] = '\0';
  else {
    sprintf(flag, "<TD ALIGN=CENTER>%s</TD>",
	    getHostCountryIconURL(el));
  }

  if(mode == LONG_FORMAT)
    sprintf(buf[bufIdx], "<TH ALIGN=LEFT>%s<A HREF=\"/%s.html\">%s</A>%s</TH>%s",
	    blinkOn, linkName, symIp, blinkOff, flag);
  else
    sprintf(buf[bufIdx], "%s<A HREF=\"/%s.html\">%s</A>%s%s",
	    blinkOn, linkName, symIp, blinkOff, flag);

  return(buf[bufIdx]);
}

/* ******************************* */

char* getHostName(HostTraffic *el, short cutName) {
  static char buf[5][80];
  char *tmpStr;
  static short bufIdx=0;

  if(broadcastHost(el))
    return("broadcast");

  bufIdx = (bufIdx+1)%5;

#ifdef MULTITHREADED
  accessMutex(&addressResolutionMutex, "getHostName");
#endif

  switch(numericFlag) {
  case 0: /* symbolic */
    tmpStr = el->hostSymIpAddress;

    if(tmpStr == NULL) {
      /* The DNS is still getting the entry name */
      if(el->hostNumIpAddress[0] == '\0')
	strcpy(buf[bufIdx], el->hostNumIpAddress);
      else
	strcpy(buf[bufIdx], el->ethAddressString);
    } else if(tmpStr[0] != '\0') {
      strcpy(buf[bufIdx], tmpStr);
      if(cutName) {
	int i;

	for(i=0; buf[bufIdx][i] != '\0'; i++)
	  if((buf[bufIdx][i] == '.')
	     && (!(isdigit(buf[bufIdx][i-1])
		    && isdigit(buf[bufIdx][i+1]))
		 )
	     ) {
	    buf[bufIdx][i] = '\0';
	    break;
	  }
      }
    } else
      strcpy(buf[bufIdx], el->ethAddressString);
    break;
  case 1:   /* numeric */
    if(el->hostNumIpAddress[0] != '\0')
      strcpy(buf[bufIdx], el->hostNumIpAddress);
    else
      strcpy(buf[bufIdx], el->ethAddressString);
    break;
  case 2: /* ethernet address */
    if(el->ethAddressString[0] != '\0')
      strcpy(buf[bufIdx], el->ethAddressString);
    else
      strcpy(buf[bufIdx], el->hostNumIpAddress);
    break;
  case 3: /* ethernet constructor */
    if(el->ethAddressString[0] != '\0')
      strcpy(buf[bufIdx], getVendorInfo(el->ethAddress, 1));
    else
      strcpy(buf[bufIdx], el->hostNumIpAddress);
    break;
  }

#ifdef MULTITHREADED
  releaseMutex(&addressResolutionMutex);
#endif

  return(buf[bufIdx]);
}

/* ********************************** */

char* calculateCellColor(TrafficCounter actualValue,
			 TrafficCounter avgTrafficLow,
			 TrafficCounter avgTrafficHigh) {

  if(actualValue < avgTrafficLow)
    return("BGCOLOR=#AAAAAAFF"); /* light blue */
  else if(actualValue < avgTrafficHigh)
    return("BGCOLOR=#00FF75"); /* light green */
  else
    return("BGCOLOR=#FF7777"); /* light red */
}


/* ************************ */

char* getCountryIconURL(char* domainName) {
  if((domainName == NULL) || (domainName[0] == '\0')) {
    /* Courtesy of Roberto De Luca <deluca@tandar.cnea.gov.ar> */
    return("&nbsp;");
  } else {
    static char flagBuf[128];
    char path[256];
    struct stat buf;

    sprintf(path, "%s/html/statsicons/flags/%s.gif", dbPath, domainName);

    if(stat(path, &buf) != 0)
      return("&nbsp;");

    sprintf(flagBuf, "<IMG ALIGN=ABSMIDDLE SRC=/statsicons/flags/%s.gif BORDER=0>",
	    domainName);

    return(flagBuf);
  }
}

/* ************************ */

char* getHostCountryIconURL(HostTraffic *el) {
  char path[128], *ret;
  struct stat buf;

  fillDomainName(el);

  sprintf(path, "%s/html/statsicons/flags/%s.gif", dbPath, el->fullDomainName);

  if(stat(path, &buf) == 0)
    ret = getCountryIconURL(el->fullDomainName);
    else
    ret = getCountryIconURL(el->dotDomainName);

  if(ret == NULL)
    ret = "&nbsp;";

  return(ret);
}

/* ******************************* */

char* getRowColor() {
#define USE_COLOR

#ifdef USE_COLOR
  if(alternateColor == 0) {
    alternateColor = 1;
    /* return("BGCOLOR=#FFFFCC"); */
    return("BGCOLOR=#EEEEEE");
  } else {
    alternateColor = 0;
    return("");
  }
#else
  return("");
#endif
}

/* ******************************* */

char* getActualRowColor() {
#define USE_COLOR

#ifdef USE_COLOR
  if(alternateColor == 1) {
    /* return("BGCOLOR=#FFFFCC"); */
    return("BGCOLOR=#EEEEEE");
  } else
    return("");
#else
  return("");
#endif
}


/* ******************************* */

void switchNetworkInterface(int _interface) {
  int i, interface=_interface-1;
  char buf[BUF_SIZE], *selected;

  sendString("<html>\n<body bgcolor=#FFFFFF><CENTER><FONT FACE=Helvetica><H1>"
	     "Network Interface Switch"
	     "</H1></center><hr><p><b>");

  if(mergeInterfaces) {
    sprintf(buf, "You can switch among different inferfaces if the -M command line switch is not used. Sorry.\n", device[actualReportDeviceId].name);
    sendString(buf);
  } else if(numDevices == 1) {
    sprintf(buf, "You're currently capturing traffic from one interface [%s]. The interface switch feature is active only when you active ntop with multiple interfaces (-i command line switch). Sorry.\n", device[actualReportDeviceId].name);
    sendString(buf);
  } else if(interface >= 0) {
    actualReportDeviceId = (interface)%numDevices;
    sprintf(buf, "The current interface is now [%s].\n", device[actualReportDeviceId].name);
    sendString(buf);
  } else {
      sendString("Available Network Interfaces:</B><P>\n<FORM ACTION=switch.html>\n");

      for(i=0; i<numDevices; i++) {

	if(actualReportDeviceId == i)
	  selected="CHECKED";
	else
	  selected = "";

	sprintf(buf, "<INPUT TYPE=radio NAME=interface VALUE=%d %s>&nbsp;%s<br>\n",
		i, selected, device[i].name);

	sendString(buf);
      }


      sendString("<p><INPUT TYPE=submit>&nbsp;<INPUT TYPE=reset>\n</FORM>\n");
    }

    sendString("</font><p>\n");
}

/* **************************************** */

void usage()
{
  char buf[80];

  sprintf(buf, "%s v.%s %s for %s", program_name, version, THREAD_MODE, osName);
  printf("%s\n", buf);

  printf("Copyright 1998-2000 by %s\n", author);
  printf("Get the freshest ntop from http://www.ntop.org/\n");
  sprintf(buf, "Written by %s.", author);

  printf("%s\n\n", buf);

  sprintf(buf, "Usage: %s", program_name);

  printf("%s\n", buf);

#ifdef WIN32
    printf("    [-r <refresh time (web = %d sec)>]\n", REFRESH_TIME);
#else
    printf("    [-r <refresh time (interactive = %d sec/web = %d sec)>]\n",
	    ALARM_TIME, REFRESH_TIME);
#endif
    printf("    %s\n",   "[-f <traffic dump file (see tcpdump)>]");
    printf("    %s\n",   "[-n (numeric IP addresses)]");
    printf("    %s\n",   "[-p <IP protocols to monitor> (see man page)]");
#ifdef WIN32
    printf("    %s%d Kb)>]\n", "[-B <NDIS buffer in Kbytes (default ", (int)(SIZE_BUF/1024));
#endif
#ifndef WIN32
    printf("    %s\n",   "[-i <interface>]");
#endif
    printf("    %s\n",   "[-w <HTTP port>]");
    printf("    %s\n",   "[-B <Internet domain name>]");
    printf("    %s\n",   "[-e <max # table rows"
#ifndef WIN32
		" (use only with -w)>"
#endif
		);
#ifndef WIN32
    printf("    %s\n",   "[-d (daemon mode (use only with -w))]");
#endif
    printf("    %s\n",   "[-m <local addresses (see man page)>]");
    printf("    %s\n",   "[-l <log period (seconds)>]");
    printf("    %s\n",   "[-s <hash size (values: 1024-4096, default is 4096)>]");
    printf("    %s\n",   "[-F <flow specs (see man page)>]");
    printf("    %s\n",   "[-b <client:port (ntop DB client)>]");
    printf("    %s\n",   "[-R <matching rules file>]");
    printf("    %s\n",   "[-N <don't use nmap if installed>]");
    printf("    %s\n",   "[-M <don't merge network interfaces (see man page)>]");
    printf("    %s\n",   "[-P <path for db-files>]");
    printf("    %s\n\n", "[ <filter expression (like tcpdump)>]");
}

/* **************************************** */

void shutdownNtop() {
  cleanup(0);

  termReports();
}
