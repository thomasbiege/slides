
/*
 *  Copyright (C) 1998-2000 Luca Deri <deri@ntop.org>
 *                          Portions by Stefano Suin <stefano@ntop.org>
 *
 *		  	  Centro SERRA, University of Pisa
 *		 	  http://www.ntop.org/
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "ntop.h"



char* formatKBytes(float numKBytes) {
#define BUFFER_SIZE   24
  static char outStr[BUFFER_SIZE][32];
  static short bufIdx=0;

  if(numKBytes < 0) return(""); /* It shouldn't happen */

  bufIdx = (bufIdx+1)%BUFFER_SIZE;

  if(numKBytes < 1024)
    sprintf(outStr[bufIdx], "%.1f%sKB", numKBytes, separator);
  else {
    float tmpKBytes = numKBytes/1024;

    if(tmpKBytes < 1024)
      sprintf(outStr[bufIdx], "%.1f%sMB",  tmpKBytes, separator);
    else {
      float tmpGBytes = tmpKBytes/1024;

      if(tmpGBytes < 1024)
	sprintf(outStr[bufIdx], "%.1f%sGB", tmpGBytes, separator);
      else
	sprintf(outStr[bufIdx], "%.1f%sTB", ((float)(tmpGBytes)/1024), separator);

    }
  }

  return(outStr[bufIdx]);
}


/* ******************************* */

char* formatBytes(TrafficCounter numBytes, short encodeString) {
#define BUFFER_SIZE   24
  static char outStr[BUFFER_SIZE][32];
  static short bufIdx=0;
  char* locSeparator;

  if(encodeString)
    locSeparator = separator;
  else
    locSeparator = " ";

  bufIdx = (bufIdx+1)%BUFFER_SIZE;

  if(numBytes < 1024)
    sprintf(outStr[bufIdx], "%lu", (unsigned long)numBytes);
  else if (numBytes < 1048576)
    sprintf(outStr[bufIdx], "%.1f%sKb",
	    ((float)(numBytes)/1024), locSeparator);
  else {
    float tmpMBytes = ((float)numBytes)/1048576;

    if(tmpMBytes < 1024)
      sprintf(outStr[bufIdx], "%.1f%sMB",
	      tmpMBytes, locSeparator);
    else {
      tmpMBytes /= 1024;

      if(tmpMBytes < 1024)
	sprintf(outStr[bufIdx], "%.1f%sGB", tmpMBytes, locSeparator);
      else
	sprintf(outStr[bufIdx], "%.1f%sTB",
		((float)(tmpMBytes)/1024), locSeparator);
    }
  }

  return(outStr[bufIdx]);
}

/* ******************************* */

char* formatSeconds(unsigned long sec) {
  static char outStr[5][32];
  static short bufIdx=0;
  unsigned int hour=0, min=0, days=0;

  bufIdx = (bufIdx+1)%5;

  if(sec >= 3600) {
    hour = (sec / 3600);

    if(hour > 0) {
      if(hour > 24) {
	days = (hour / 24);
	hour = hour % 24;
	sec -= days*86400;
      }
      sec -= hour*3600;
    } else
      hour = 0;
  }

  min = (sec / 60);
  if(min > 0) sec -= min*60;

  if(days > 0)
    sprintf(outStr[bufIdx], "%u day(s) %u:%02u:%02lu", days, hour, min, sec);
  else if(hour > 0)
    sprintf(outStr[bufIdx], "%u:%02u:%02lu", hour, min, sec);
  else if(min > 0)
    sprintf(outStr[bufIdx], "%u:%02lu", min, sec);
  else
    sprintf(outStr[bufIdx], "%lu sec", sec);

  return(outStr[bufIdx]);
}

/* ******************************* */

char* formatThroughput(float numBytes) {
  static char outStr[5][32];
  static short bufIdx=0;
  float numBits;

  bufIdx = (bufIdx+1)%5;

  if(numBytes < 0) numBytes = 0; /* Sanity check */
  numBits = numBytes*8;

  if (numBits < 100)
    numBits = 0; /* Avoid very small decimal values */

  if (numBits < 1024) {
    sprintf(outStr[bufIdx], "%.1f%sbps", numBits, separator);
  } else if (numBits < 1048576) {
    sprintf(outStr[bufIdx], "%.1f%sKbps", ((float)(numBits)/1024), separator);
  } else {
    sprintf(outStr[bufIdx], "%.1f%sMbps", ((float)(numBits)/1048576), separator);
  }

#ifdef DEBUG
  printf("%.2f = %s\n", numBytes, outStr[bufIdx]);
#endif

  return(outStr[bufIdx]);
}

/* ******************************* */

char formatStatus(HostTraffic *el) {
  if((el->lastBytesSent == el->bytesSent)
     && (el->lastBytesReceived == el->bytesReceived))
    return('I'); /* Idle */
  else if ((el->lastBytesSent != el->bytesSent)
	   && (el->lastBytesReceived != el->bytesReceived))
    return('B'); /* Both */
  else if (el->lastBytesSent != el->bytesSent)
    return('S'); /* Send */
  else
    return('R'); /* Receive */
}

/* ************************ */

char* formatTimeStamp(unsigned int ndays,
		      unsigned int nhours,
		      unsigned int nminutes) {
#define TIME_STAMP_BUFFER_SIZE   2
  time_t theTime;

  /* printf("%u - %u - %u\n", ndays, nhours, nminutes); */

  if((ndays == 0)
     && (nhours == 0)
     && (nminutes == 0))
    return("now");
  else {
    static char timeBuffer[TIME_STAMP_BUFFER_SIZE][32];
    static short bufIdx=0;

    bufIdx = (bufIdx+1)%TIME_STAMP_BUFFER_SIZE;
    theTime = actTime-(ndays*86500)-(nhours*3600)-(nminutes*60);
    strcpy(timeBuffer[bufIdx], ctime(&theTime));
    timeBuffer[bufIdx][strlen(timeBuffer[bufIdx])-1] = '\0'; /* Remove trailer '\n' */
    return(timeBuffer[bufIdx]);
  }
}


/* ************************ */

char* formatPkts(TrafficCounter pktNr) {
  static short bufIdx=0;
  static char staticBuffer[5][32];

  bufIdx = (bufIdx+1)%5;

  if(pktNr < 1000)
    sprintf(staticBuffer[bufIdx], "%lu", (unsigned long)pktNr);
  else if(pktNr < 1000000)
    sprintf(staticBuffer[bufIdx], "%lu,%03lu",
	    (unsigned long)(pktNr/1000),
	    ((unsigned long)pktNr)%1000);
  else {
    unsigned long a, b, c;
    a = (unsigned long)(pktNr/1000000);
    b = (unsigned long)((pktNr-a*1000000)/1000);
    c = ((unsigned long)pktNr)%1000;
    sprintf(staticBuffer[bufIdx], "%lu,%03lu,%03lu", a, b, c);
  }

  return(staticBuffer[bufIdx]);
}


