/*
 *  Copyright (C) 1998-2000 Luca Deri <deri@ntop.org>
 *                          Portions by Stefano Suin <stefano@ntop.org>
 *
 *  			  Centro SERRA, University of Pisa
 *  			  http://www.ntop.org/
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */


#include "ntop.h"


#ifdef STATIC_PLUGIN
extern PluginInfo* icmpPluginEntryFctn();
extern PluginInfo* arpPluginEntryFctn();
extern PluginInfo* nfsPluginEntryFctn();
extern PluginInfo* wapPluginEntryFctn();
#endif

/* ******************* */

int handlePluginHTTPRequest(char* url) {
  FlowFilterList *flows = flowsList;

  while(flows != NULL)
    if((flows->pluginPtr != NULL)
       && (flows->pluginPtr->pluginURLname != NULL)
       && (flows->pluginPtr->httpFunct != NULL)
       && (strncmp(flows->pluginPtr->pluginURLname,
		   url, strlen(flows->pluginPtr->pluginURLname)) == 0)) {
	void (*httpFunc)(char*);
	char *arg;

	httpFunc = (void(*)(char*))flows->pluginPtr->httpFunct;

	if(strlen(url) == strlen(flows->pluginPtr->pluginURLname))
	  arg = "";
	else
	  arg = &url[strlen(flows->pluginPtr->pluginURLname)+1];

	/* printf("Found %s [%s]\n", flows->pluginPtr->pluginURLname, arg); */
	httpFunc(arg);
	return(1);
    } else
      flows = flows->next;

  return(0); /* Plugin not found */
}

/* ******************* */

#if (defined(HAVE_DIRENT_H) && defined(HAVE_DLFCN_H)) || defined(WIN32) || defined(HPUX) || defined(AIX)
void loadPlugin(char* dirName, char* pluginName) {
  char pluginPath[256];
  char tmpBuf[BUF_SIZE];
  int i;
#ifdef HPUX /* Courtesy Rusetsky Dmitry <dimania@mail.ru> */
  shl_t pluginPtr;
#else
#ifndef WIN32
  void *pluginPtr;
#endif
#endif
#ifndef WIN32
  void *pluginEntryFctnPtr;
#endif
  PluginInfo* pluginInfo;
  
  int rc;
#ifndef WIN32
  PluginInfo* (*pluginJumpFunc)();
#endif
  FlowFilterList *newFlow;


  sprintf(pluginPath, "%s/%s", dirName, pluginName);

#ifdef DEBUG
  printf("Loading plugin '%s'...\n", pluginPath);
#endif

#ifndef STATIC_PLUGIN
#ifdef HPUX /* Courtesy Rusetsky Dmitry <dimania@mail.ru> */
  /* Load the library */
  pluginPtr = shl_load(pluginPath, BIND_IMMEDIATE|BIND_VERBOSE|BIND_NOSTART ,0L);
#else
#ifdef AIX
  pluginPtr = load(pluginName, 1, dirName); /* Load the library */
#else
  pluginPtr = dlopen(pluginPath, RTLD_NOW /* RTLD_LAZY */); /* Load the library */
#endif /* AIX */
#endif /* HPUX  */

  if(pluginPtr == NULL) {
#if HPUX /* Courtesy Rusetsky Dmitry <dimania@mail.ru> */
    printf("WARNING: unable to load plugin '%s'\n[%s]\n", pluginPath,strerror(errno) );
#else
    printf("WARNING: unable to load plugin '%s'\n[%s]\n", pluginPath, dlerror());
#endif /* HPUX */
    return;
  }

#ifdef HPUX /* Courtesy Rusetsky Dmitry <dimania@mail.ru> */
  if(shl_findsym(&pluginPtr ,PLUGIN_ENTRY_FCTN_NAME,
		 TYPE_PROCEDURE, &pluginEntryFctnPtr) == -1)
    pluginEntryFctnPtr = NULL;
#else
#ifdef AIX
  pluginEntryFctnPtr = pluginPtr;
#else
  pluginEntryFctnPtr = dlsym(pluginPtr, PLUGIN_ENTRY_FCTN_NAME);
#endif /* AIX */
#endif /* HPUX */

  if(pluginEntryFctnPtr == NULL) {
#ifdef HPUX /* Courtesy Rusetsky Dmitry <dimania@mail.ru> */
    printf("\nWARNING: unable to local plugin '%s' entry function [%s] \n",pluginPath,
	   strerror(errno));
#else
#ifdef WIN32
    printf("WARNING: unable to local plugin '%s' entry function [%li]\n", pluginPath, GetLastError());
#else
    printf("WARNING: unable to local plugin '%s' entry function [%s]\n", pluginPath, dlerror());
#endif /* WIN32 */
#endif /* HPUX */
    return;
  }

  pluginJumpFunc = (PluginInfo*(*)())pluginEntryFctnPtr;
  pluginInfo = pluginJumpFunc();
#else /* STATIC_PLUGIN */

  if(strcmp(pluginName, "icmpPlugin") == 0)
    pluginInfo = icmpPluginEntryFctn();
  else if(strcmp(pluginName, "arpPlugin") == 0)
    pluginInfo = arpPluginEntryFctn();
  else if(strcmp(pluginName, "nfsPlugin") == 0)
    pluginInfo = nfsPluginEntryFctn();
  else if(strcmp(pluginName, "wapPlugin") == 0)
    pluginInfo = wapPluginEntryFctn();
  else
    pluginInfo = NULL;

#endif /* STATIC_PLUGIN */


  if(pluginInfo == NULL) {
    printf("WARNING: %s call of plugin '%s' failed.\n",
	   PLUGIN_ENTRY_FCTN_NAME, pluginPath);
    return;
  }

  newFlow = (FlowFilterList*)calloc(1, sizeof(FlowFilterList));

  if(newFlow == NULL) {
    printf("Fatal error: not enough memory. Bye!\n");
    exit(-1);
  } else {
    newFlow->flowName = strdup(pluginInfo->pluginName);

    if((pluginInfo->bpfFilter == NULL)
       || (pluginInfo->bpfFilter[0] == '\0')) {
      /*
	printf("WARNING: plugin '%s' has an empty BPF filter.\n", pluginPath);
      */
      for(i=0; i<numDevices; i++)
	newFlow->fcode[i].bf_insns = NULL;
    } else {
      strcpy(tmpBuf, pluginInfo->bpfFilter);

      for(i=0; i<numDevices; i++) {
#ifdef DEBUG
	printf("Compiling filter '%s' on device %s\n", tmpBuf, device[i].name);
#endif
	rc = pcap_compile(device[i].pcapPtr, 
			  &newFlow->fcode[i], tmpBuf, 1, 
			  device[i].netmask.s_addr);
      
	if(rc < 0) {
	  printf("WARNING: plugin '%s' contains a wrong filter specification\n"
		 "         \"%s\" on interface %s (%s).\n"
		 "         This plugin has been discarded.\n",
		 pluginPath, 
		 pluginInfo->bpfFilter, 
		 device[i].name,
		 pcap_geterr((device[i].pcapPtr)));
	  free(newFlow);
	  return;
	}
      }
    }

    newFlow->pluginPtr  = pluginInfo;
    newFlow->next = flowsList;
    flowsList = newFlow;
    /* printf("Adding: %s\n", pluginInfo->pluginName); */
  }

#ifdef DEBUG
  printf("Plugin '%s' loaded succesfully.\n", pluginPath);
#endif
}

/* ******************* */

void loadPlugins() {
#ifndef WIN32
  char dirPath[256];
  struct dirent* dp;
  int idx;
  DIR* directoryPointer=NULL;
#else
#ifndef WIN32
  char tmpStr[512], _tmpnam[255];
  FILE *fd;
  int rc;
#endif
#endif

  printf("Loading plugins (if any)...\n");


#ifndef STATIC_PLUGIN
  for(idx=0; dirs[idx] != NULL; idx++) {
    sprintf(dirPath, "%s/plugins", dirs[idx]);

    directoryPointer = opendir(dirPath);

    if(directoryPointer != NULL)
      break;
  }

  if(directoryPointer == NULL) {
    printf("WARNING: Unable to find the plugins/ directory.\n");
    return;
  }

  while((dp = readdir(directoryPointer)) != NULL)
    {
      if(dp->d_name[0] == '.')
	continue;
      else if(strlen(dp->d_name) < strlen(PLUGIN_EXTENSION))
	continue;
      else if(strcmp(&dp->d_name[strlen(dp->d_name)-strlen(PLUGIN_EXTENSION)], PLUGIN_EXTENSION))
	continue;

      loadPlugin(dirPath, dp->d_name);
    }

  closedir(directoryPointer);
#else /* STATIC_PLUGIN */

  loadPlugin(NULL, "icmpPlugin");
  loadPlugin(NULL, "arpPlugin");
  loadPlugin(NULL, "nfsPlugin");
  loadPlugin(NULL, "wapPlugin");

#endif /* STATIC_PLUGIN */
}

/* ******************* */

void unloadPlugins() {
  FlowFilterList *flows = flowsList;

  printf("\nUnloading plugins (if any)...\n");

  while(flows != NULL) {
    if(flows->pluginPtr != NULL) {
#ifdef DEBUG
      printf("Unloading plugin '%s'...\n", flows->pluginPtr->pluginName);
#endif
      if(flows->pluginPtr->termFunc != NULL) {
	void (*termFunc)();

	termFunc = (void(*)())flows->pluginPtr-> termFunc;
	termFunc();
      }

#ifdef HPUX /* Courtesy Rusetsky Dmitry <dimania@mail.ru> */
      shl_unload((shl_t)flows->pluginPtr);
#else
#ifdef WIN32
      FreeLibrary((HANDLE)flows->pluginPtr);
#else
#ifdef AIX
      unload(flows->pluginPtr);
#else
      dlclose(flows->pluginPtr);
#endif /* AIX */
#endif /* WIN32 */
#endif /* HPUX */
      flows->pluginPtr = NULL;
    }
    flows = flows->next;
  }
}

#endif /* defined(HAVE_DIRENT_H) && defined(HAVE_DLFCN_H) */

/* ************************************* */

#ifdef AIX

char* dlerror() {
  char *errMsg[768];
  static char tmpStr[256];

  if(loadquery(L_GETMESSAGES, &errMsg, 768) != -1)
    {
      int i, j, errCode;
      char* errName;

      for(i=0; errMsg[i] != NULL; i++)
	{
	  errCode=atoi(errMsg[i]);
	  errName = "";

	  for(j=1; errMsg[i][j] != '\0'; j++)
	    if(errMsg[i][j] != ' ')
	      {
		errName = &errMsg[i][j];
		break;
	      }

	  switch(errCode) /* sys/ldr.h */
	    {
	    case 1:
	      return("Too many errors, rest skipped");
	      break;
	    case 2:
	      sprintf(tmpStr, "Can't load library [%s]", errName);
	      break;
	    case 3:
	      sprintf(tmpStr, "Can't find symbol in library [%s]", errName);
	      break;
	    case 4:
	      return("Rld data offset or symbol index out of range or bad relocation type");
	      break;
	    case 5:
	      sprintf(tmpStr, "File not valid, executable xcoff [%s]", errName);
	      return(tmpStr);
	      break;
	    case 6:
	      sprintf(tmpStr, "The errno associated with the failure if not ENOEXEC,"
		      " it indicates the underlying error, such as no memory [%s][errno=%d]", errName, errno);
	      return(tmpStr);
	      break;
	    case 7:
	      sprintf(tmpStr, "Member requested from a file which is not an archive or does not"
		      "contain the member [%s]", errName);
	      return(tmpStr);
	      break;
	    case 8:
	      sprintf(tmpStr, "Symbol type mismatch [%s]", errName);
	      return(tmpStr);
	      break;
	    case 9:
	      return("Text alignment in file is wrong");
	      break;
	    case 10:
	      return("Insufficient permission to create a loader domain");
	      break;
	    case 11:
	      return("Insufficient permission to add entries to a loader domain");
	      break;
	    default:
	      sprintf(tmpStr, "Unknown error [%d]", errCode);
	      return(tmpStr);
	    }
	}
    }
}

#endif /* AIX */
