
HostTraffic * findHostByNumIP (char * numIPaddr)
{
  u_int idx;

  for (idx = 1; idx < actualHashSize; idx ++)
    {
      if (! hash_hostTraffic [i])
	continue;
	&& hash_hostTraffic [i] -> hostNumIpAddress
       && (! strcmp (hash_hostTraffic [idx] -> hostNumIpAddress, numIPaddr)))
      return (hash_hostTraffic [idx]);

  return (NULL);
}
