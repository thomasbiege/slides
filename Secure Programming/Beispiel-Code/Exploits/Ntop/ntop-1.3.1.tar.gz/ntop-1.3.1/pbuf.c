/*
 *  Copyright (C) 1998-2000 Luca Deri <deri@ntop.org>
 *                          Portions by Stefano Suin <stefano@ntop.org>
 *
 *  			  Centro SERRA, University of Pisa
 *  			  http://www.ntop.org/
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/*
 * Copyright (c) 1994, 1996
 *	The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that: (1) source code distributions
 * retain the above copyright notice and this paragraph in its entirety, (2)
 * distributions including binary code include the above copyright notice and
 * this paragraph in its entirety in the documentation or other materials
 * provided with the distribution, and (3) all advertising materials mentioning
 * features or use of this software display the following acknowledgement:
 * ``This product includes software developed by the University of California,
 * Lawrence Berkeley Laboratory and its contributors.'' Neither the name of
 * the University nor the names of its contributors may be used to endorse
 * or promote products derived from this software without specific prior
 * written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */

/*
#define DNS_SNIFF_DEBUG
#define DNS_DEBUG
#define GDBM_DEBUG
#define PURGE_DEBUG
*/

#define SESSION_PATCH /* Experimental (L.Deri) */

/* #define PRINT_UNKNOWN_PACKETS */

#include "ntop.h"


/* Static */
static void freeHostInfo(u_int host);

/* ************************************ */

u_int checkSessionIdx(u_int idx) {

  if(idx > actualHashSize)
    printf("Index error (idx=%u)!!!!\n", idx);

  return(idx);
}

/* ******************************* */

int getPortByName(ServiceEntry **theSvc, char* portName) {
  int idx;

  for(idx=0; idx<SERVICE_HASH_SIZE; idx++) {

#ifdef DEBUG
    if(theSvc[idx] != NULL)
      printf("%d/%s [%s]\n",
	     theSvc[idx]->port,
	     theSvc[idx]->name, portName);
#endif

    if((theSvc[idx] != NULL)
       && (strcmp(theSvc[idx]->name, portName) == 0))
      return(theSvc[idx]->port);
  }

  return(-1);
}

/* ******************************* */

char* getPortByNumber(ServiceEntry **theSvc, int port) {
  int idx = port % SERVICE_HASH_SIZE;
  ServiceEntry *scan;

  for(;;) {
    scan = theSvc[idx];

    if((scan != NULL) && (scan->port == port))
      return(scan->name);
    else if(scan == NULL)
      return(NULL);
    else
      idx = (idx+1) % SERVICE_HASH_SIZE;
  }
}

/* ******************************* */

char* getPortByNum(int port, int type) {
  char* rsp;

  if(type == IPPROTO_TCP) {
    rsp = getPortByNumber(tcpSvc, port);
  } else {
    rsp = getPortByNumber(udpSvc, port);
  }

  return(rsp);
}

/* ******************************* */

char* getAllPortByNum(int port) {
  char* rsp;
  static char staticBuffer[2][16];
  static short portBufIdx=0;

  rsp = getPortByNumber(tcpSvc, port); /* Try TCP first... */
  if(rsp == NULL)
    rsp = getPortByNumber(udpSvc, port);  /* ...then UDP */

  if(rsp != NULL)
    return(rsp);
  else {
    portBufIdx = (portBufIdx+1)%2;
    sprintf(staticBuffer[portBufIdx], "%d", port);
    return(staticBuffer[portBufIdx]);
  }
}

/* ******************************* */

int getAllPortByName(char* portName) {
  int rsp;

  rsp = getPortByName(tcpSvc, portName); /* Try TCP first... */
  if(rsp == -1)
    rsp = getPortByName(udpSvc, portName);  /* ...then UDP */

  return(rsp);
}


/* ******************************* */

void addPortHashEntry(ServiceEntry **theSvc, int port, char* name) {
  int idx = port % SERVICE_HASH_SIZE;
  ServiceEntry *scan;

  for(;;) {
    scan = theSvc[idx];

    if(scan == NULL) {
      theSvc[idx] = (ServiceEntry*)malloc(sizeof(ServiceEntry));
      theSvc[idx]->port = (u_short)port;
      theSvc[idx]->name = strdup(name);
      break;
    } else
      idx = (idx+1) % SERVICE_HASH_SIZE;
  }
}

/* ******************************* */

int findHostInfo(struct in_addr *hostIpAddress)
{
  u_int i = 0;

  for(i=0; i<actualHashSize; i++)
    if(device[actualDeviceId].hash_hostTraffic[i] != NULL)
      if(device[actualDeviceId].hash_hostTraffic[i]->hostIpAddress.s_addr == hostIpAddress->s_addr)
	return i;

  return(-1);
}

/* ******************************* */

u_int getHostInfo(struct in_addr *hostIpAddress,
		  u_char *ether_addr)
{
  u_int idx, i, run=0;
  HostTraffic *el=NULL;
  short numCmp;
  char* symEthName = NULL;

  if (hostIpAddress == NULL) {
    /* No IP, take the ethernet-address as index */
    memcpy(&idx, &ether_addr[ETHERNET_ADDRESS_LEN-sizeof(u_int)], sizeof(u_int));
    numCmp = 0;
  } else if (!isLocalAddress(hostIpAddress)) {
    /* the MAC address is meaningless because isn't local */
    idx = 0;
    memcpy(&idx, &hostIpAddress->s_addr, 4);
    numCmp = 1;
    /* printf("-> %s\n", intoa(*hostIpAddress)); */
  } else if(isBroadcastAddress(hostIpAddress)) {
    return(broadcastEntryIdx);
  } else { /* local IP-Address, no Broadcast address */
    memcpy(&idx, &ether_addr[ETHERNET_ADDRESS_LEN-sizeof(u_int)], sizeof(u_int));
    numCmp = 0;
  }

  idx = (u_int)((idx*3) % actualHashSize);

  for(i=0; i<actualHashSize; i++) {
  HASH_SLOT_FOUND:
    el = device[actualDeviceId].hash_hostTraffic[idx]; /* (**) */

    if(el != NULL) {
      if(numCmp == 0) {
	/* compare with the ethernet-address */
	if (memcmp(el->ethAddress, ether_addr, ETHERNET_ADDRESS_LEN) == 0) {
	    if(hostIpAddress != NULL) {
	      int i;

	      for(i=0; i<MAX_MULTIHOMING_ADDRESSES; i++) {
		if(el->hostIpAddresses[i].s_addr == 0x0) {
		  el->hostIpAddresses[i].s_addr = hostIpAddress->s_addr;
		  break;
		} else if(el->hostIpAddresses[i].s_addr == hostIpAddress->s_addr)
		  break;
		else {
		  el->hostIpAddresses[i].s_addr = hostIpAddress->s_addr;
		  break;
		}
	      }

	      if(el->hostNumIpAddress[0] == '\0') {
		/* This entry didn't have IP fields set: let's set them now */
		el->hostIpAddress.s_addr = hostIpAddress->s_addr;
		strcpy(el->hostNumIpAddress, intoa(*hostIpAddress));
		
		if(numericFlag == 0)
		  el->hostSymIpAddress = ipaddr2str(el->hostIpAddress);
		
		/* else el->hostSymIpAddress = el->hostNumIpAddress;
		   The line below isn't necessary because (**) has
		   already set the pointer */
		if(isBroadcastAddress(&el->hostIpAddress)) FD_SET(BROADCAST_HOST_FLAG, &el->flags);
	      }
	    }
	    break;
	}
      } else {
	if (el->hostIpAddress.s_addr == hostIpAddress->s_addr)
	  break;
      }
    } else {
      /* New table entry */
      int len = (size_t)numIpProtosToMonitor*sizeof(ProtoTrafficInfo);

      el = (HostTraffic*)malloc(sizeof(HostTraffic));
      memset(el, 0, sizeof(HostTraffic));
      FD_ZERO(&(el->flags));
      for(i=0; i<MAX_NUM_CONTACTED_PEERS; i++) el->contactedSentPeersIndexes[i] = NO_PEER;
      for(i=0; i<MAX_NUM_CONTACTED_PEERS; i++) el->contactedRcvdPeersIndexes[i] = NO_PEER;
      for(i=0; i<MAX_NUM_HOST_ROUTERS; i++) el->contactedRouters[i] = NO_PEER;

      /* NOTE: el->nextDBupdate = 0 */

      el->protoIPTrafficInfos = (ProtoTrafficInfo*)malloc(len);
      memset(el->protoIPTrafficInfos, 0, len);

      device[actualDeviceId].hash_hostTraffic[idx] = el; /* Insert a new entry */
      device[actualDeviceId].hostsno++;

#ifdef DEBUG
      printf("Adding idx=%d on device=%d\n", idx, actualDeviceId);
#endif

      device[actualDeviceId].hostsno = 0;

      if((hostIpAddress == NULL)
	 || ((hostIpAddress != NULL) && isLocalAddress(hostIpAddress))) {
	/* This is a local address and then the
	   ethernet address does make sense */
	memcpy(el->ethAddress, ether_addr, ETHERNET_ADDRESS_LEN);
	symEthName = getSpecialMacInfo(el->ethAddress,
				       ! (strcmp (separator, "&nbsp")) ? 1 : 0);
	el->ethAddressString = strdup(etheraddr_string(ether_addr));
	FD_SET(SUBNET_LOCALHOST_FLAG, &el->flags);
	FD_SET(SUBNET_PSEUDO_LOCALHOST_FLAG, &el->flags);
      } else if(hostIpAddress != NULL) {
	/* This is packet that's being routed */
	memcpy(el->ethAddress, &hostIpAddress->s_addr, 4); /* Dummy/unique eth address */
	FD_CLR(SUBNET_LOCALHOST_FLAG, &el->flags);
	if(isPseudoLocalAddress(hostIpAddress))
	  FD_SET(SUBNET_PSEUDO_LOCALHOST_FLAG, &el->flags);
	else
	  FD_CLR(SUBNET_PSEUDO_LOCALHOST_FLAG, &el->flags);
      } else {
	FD_CLR(SUBNET_LOCALHOST_FLAG, &el->flags);
	FD_CLR(SUBNET_PSEUDO_LOCALHOST_FLAG, &el->flags);
      }

      if(el->ethAddressString == NULL)
	el->ethAddressString = strdup("");

      if(strncmp(el->ethAddressString, "FF:", 3) == 0) {
	/*
	   The trick below allows me not to duplicate the
	   "<broadcast>" string in the code
	*/
	el->hostIpAddress.s_addr = INADDR_BROADCAST;
	FD_SET(BROADCAST_HOST_FLAG, &el->flags);
	if(isMulticastAddress(&el->hostIpAddress)) FD_SET(MULTICAST_HOST_FLAG, &el->flags);
	strcpy(el->hostNumIpAddress, intoa(el->hostIpAddress));
	el->hostSymIpAddress = el->hostNumIpAddress;
      } else if(hostIpAddress != NULL) {
	el->hostIpAddress.s_addr = hostIpAddress->s_addr;
	strcpy(el->hostNumIpAddress, intoa(*hostIpAddress));
	if(isBroadcastAddress(&el->hostIpAddress)) FD_SET(BROADCAST_HOST_FLAG, &el->flags);
	if(isMulticastAddress(&el->hostIpAddress)) FD_SET(MULTICAST_HOST_FLAG, &el->flags);

	/* Trick to fill up the address cache */
	if(numericFlag == 0)
	  el->hostSymIpAddress = ipaddr2str(el->hostIpAddress);
	else
	  el->hostSymIpAddress = el->hostNumIpAddress;
      } else {
	/* el->hostNumIpAddress == "" */
	if(symEthName[0] != '\0') {
	  char buf[255];

	  sprintf(buf, "%s [MAC]", symEthName);
	  el->hostSymIpAddress = strdup(buf);
	} else
	  el->hostSymIpAddress = el->hostNumIpAddress; /* (**) */
      }

#ifdef PURGE_DEBUG
      if((strcmp(etheraddr_string(ether_addr), "08:00:20:89:79:D7") == 0)
	 || (strcmp(el->hostSymIpAddress, "more") == 0))
	printf("Added a new hash_hostTraffic entry [%s/%s/%s/%d]\n",
	       etheraddr_string(ether_addr), el->hostSymIpAddress,
	       el->hostNumIpAddress, device[actualDeviceId].hostsno);
#endif

      el->lastSeen = actTime;

      checkSpoofing(idx);
      break;
    }

    idx = (idx+1) % actualHashSize;
  }

  if(i == actualHashSize) {
    /* The hashtable is full */
    if(run == 0) {
      purgeIdleHosts(1);
    } else {
      /* No space yet: let's delete the oldest table entry */
      int candidate = 0;
      time_t lastSeenCandidate=0;
      HostTraffic* hostToFree;

      for(i=0; i<actualHashSize; i++)
	if(device[actualDeviceId].hash_hostTraffic[i] != NULL) {
	  if((candidate == 0)
	     || (device[actualDeviceId].hash_hostTraffic[idx]->lastSeen < lastSeenCandidate)) {
	    candidate = i;
	    lastSeenCandidate = device[actualDeviceId].hash_hostTraffic[idx]->lastSeen;
	  }
	}

      hostToFree = device[actualDeviceId].hash_hostTraffic[candidate];
      freeHostInfo(candidate);
      idx = candidate; /* this is a hint for (**) */
    }

    run++;
    goto HASH_SLOT_FOUND;
  }

  el->lastSeen = actTime;

#ifdef DEBUG
  printf("getHostInfo(idx=%d/actualDeviceId=%d) [%s/%s/%s/%d]\n", 
	 idx, actualDeviceId,
	 etheraddr_string(ether_addr), el->hostSymIpAddress,
	 el->hostNumIpAddress, device[actualDeviceId].hostsno);
#endif

  return(idx);
}

/* ************************************ */

char* getNamedPort(int port) {
  static char outStr[2][8];
  static short portBufIdx=0;
  char* svcName;

  portBufIdx = (portBufIdx+1)%2;

  svcName = getPortByNum(port, IPPROTO_TCP);
  if(svcName == NULL)
    svcName = getPortByNum(port, IPPROTO_UDP);

  if(svcName == NULL)
    sprintf(outStr[portBufIdx], "%d", port);
  else
    strcpy(outStr[portBufIdx], svcName);

  return(outStr[portBufIdx]);
}

/* ************************************ */

void updateHostSessionsList(u_int theHostIdx,
			    u_short port,
			    u_int remotePeerIdx,
			    IPSession *theSession,
			    u_short sessionType,
			    u_char initiator,
			    int role)
{
  /* This is a known port hence we're interested in */
  IpGlobalSession *scanner=NULL, *prevScanner;
  HostTraffic* theHost;
  int i;

  if((theHostIdx == broadcastEntryIdx)
     || (remotePeerIdx == broadcastEntryIdx))
    return;

  if(remotePeerIdx == NO_PEER) {
    printf("WARNING (internal error): wrong index value\n");
    return;
  } else
    theHost = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(theHostIdx)];

  if((theHost == NULL) /* Probably the host has been deleted */
     || broadcastHost(theHost) /* We could't care less of junk traffic */
     )
    return;

  switch(sessionType) {
  case IPPROTO_TCP: /* 6 */
    scanner = device[actualDeviceId].hash_hostTraffic[theHostIdx]->tcpSessionList;
    break;
  case IPPROTO_UDP: /* 17 */
    scanner = device[actualDeviceId].hash_hostTraffic[theHostIdx]->udpSessionList;
    break;
  }

  prevScanner = scanner;

  while(scanner != NULL) {
    if(scanner->magic != MAGIC_NUMBER) {
      printf("Magic assertion failed (2)!\n");
      scanner = NULL;
      if(prevScanner != NULL) {
	prevScanner->next = NULL;
      }
      break;
    }

    if((scanner->port == port) && (scanner->initiator == role))
      break;

    prevScanner = scanner;
    scanner = (IpGlobalSession*)(scanner->next);
  }

  if(scanner == NULL) {
    scanner = (IpGlobalSession*)malloc(sizeof(IpGlobalSession));
    memset(scanner, 0, sizeof(IpGlobalSession));
    scanner->magic = MAGIC_NUMBER;
    scanner->port = port;
    scanner->initiator = role;
    scanner->firstSeen = actTime;

    for(i=0; i<MAX_NUM_SESSION_PEERS; i++) scanner->peersIdx[i] = NO_PEER;

    /* Add the session to the session list */
    switch(sessionType) {
    case IPPROTO_TCP:
      scanner->next = (IpGlobalSession*)(device[actualDeviceId].hash_hostTraffic[theHostIdx]->tcpSessionList);
      device[actualDeviceId].hash_hostTraffic[theHostIdx]->tcpSessionList = scanner; /* list head */
      break;
    case IPPROTO_UDP:
      scanner->next = (IpGlobalSession*)(device[actualDeviceId].hash_hostTraffic[theHostIdx]->udpSessionList);
      device[actualDeviceId].hash_hostTraffic[theHostIdx]->udpSessionList = scanner; /* list head */
      break;
    }
  }

  scanner->lastSeen = actTime;
  scanner->sessionCounter++;

#ifdef DEBUG
    printSession(theSession, sessionType, scanner->sessionCounter);
#endif

  for(i=0; i<MAX_NUM_SESSION_PEERS; i++)
    if((scanner->peersIdx[i] == NO_PEER) || (scanner->peersIdx[i] == remotePeerIdx))
      break;

  if((i<MAX_NUM_SESSION_PEERS)
     && (((scanner->peersIdx[i] != NO_PEER)
	 && (scanner->peersIdx[i] != remotePeerIdx)
	 && (strcmp(device[actualDeviceId].hash_hostTraffic[checkSessionIdx(scanner->peersIdx[i])]->hostNumIpAddress,
		    device[actualDeviceId].hash_hostTraffic[checkSessionIdx(remotePeerIdx)]->hostNumIpAddress)))
     || (scanner->peersIdx[i] == NO_PEER))) {
    scanner->peersIdx[scanner->lastPeer] = remotePeerIdx;
    scanner->lastPeer = (scanner->lastPeer+1) % MAX_NUM_SESSION_PEERS;
  }

  switch(sessionType) {
  case IPPROTO_TCP:
    if(role == SERVER_ROLE) {
      scanner->bytesSent += theSession->bytesSent;
      scanner->bytesReceived += theSession->bytesReceived;
    } else {
      scanner->bytesSent += theSession->bytesReceived;
      scanner->bytesReceived += theSession->bytesSent;
    }
    break;
  case IPPROTO_UDP:
    scanner->bytesSent += theSession->bytesSent;
    scanner->bytesReceived += theSession->bytesReceived;
    break;
  }
}

/* ************************************ */

static void purgeIdleHostSessions(u_int hostIdx,
				  IpGlobalSession *sessionScanner)
{
  int i;
  u_int *scanner;

  while(sessionScanner != NULL) {
    scanner = sessionScanner->peersIdx;
    for(i=0; i<MAX_NUM_SESSION_PEERS; i++)
      if(scanner[i] == hostIdx)
	scanner[i] = NO_PEER;

    sessionScanner = sessionScanner->next;
  }

}

/* ************************************ */

/* Delayed free */
static void freeHostInfo(u_int hostIdx) {
  int i, j;
  u_int idx;
#define FREE_LIST_LEN   32
  static HostTraffic *freeHostList[FREE_LIST_LEN];
  static int nextIdxToFree=0, freeListLen=0;

  HostTraffic *host = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(hostIdx)];

  updateHostTraffic(host);

  device[actualDeviceId].hash_hostTraffic[hostIdx] = NULL;
  device[actualDeviceId].hostsno--;

#ifdef PURGE_DEBUG
  printf("Deleted a hash_hostTraffic entry [%s/%d]\n",
	 host->hostSymIpAddress, device[actualDeviceId].hostsno);
#endif

  free(host->protoIPTrafficInfos);
  free(host->ethAddressString);
  if(host->nbHostName != NULL)   free(host->nbHostName);
  if(host->nbDomainName != NULL) free(host->nbDomainName);
  if(host->atNodeName != NULL)   free(host->atNodeName);
  if(host->ipxHostName != NULL)  free(host->ipxHostName);

  if(host->osName != NULL)
    free(host->osName);

  for(i=0; i<2; i++) {
    IpGlobalSession *nextElement, *element;

    if(i == 0)
      element = host->tcpSessionList;
    else
      element = host->udpSessionList;

    while(element != NULL) {
      nextElement = element->next;
      /*
	 The 'peers' field shouldn't be a problem because an idle host
	 isn't supposed to have any session
      */
      free(element);
      element = nextElement;
    }
  }

  for(i=0; i<TOP_ASSIGNED_IP_PORTS; i++)
    if(host->portsUsage[i] != NULL)
      free(host->portsUsage[i]);

  for(i=0; i<MAX_NUM_PROCESSES; i++) {
    if(processes[i] != NULL) {
      for(j=0; j<MAX_NUM_CONTACTED_PEERS; j++)
	if(processes[i]->contactedIpPeersIndexes[j] == hostIdx)
	  processes[i]->contactedIpPeersIndexes[j] = NO_PEER;
    }
  }

  /* Check whether there are hosts that have the host being purged
     as peer */
  for(idx=0; idx<actualHashSize; idx++)
    if(device[actualDeviceId].hash_hostTraffic[idx] != NULL) {
      if(device[actualDeviceId].hash_hostTraffic[idx]->tcpSessionList != NULL)
	purgeIdleHostSessions(hostIdx, device[actualDeviceId].hash_hostTraffic[idx]->tcpSessionList);

      if(device[actualDeviceId].hash_hostTraffic[idx]->udpSessionList != NULL)
	purgeIdleHostSessions(hostIdx, device[actualDeviceId].hash_hostTraffic[idx]->udpSessionList);

      for(j=0; j<MAX_NUM_CONTACTED_PEERS; j++)
	if(device[actualDeviceId].hash_hostTraffic[idx]->contactedSentPeersIndexes[j] == hostIdx)
	  device[actualDeviceId].hash_hostTraffic[idx]->contactedSentPeersIndexes[j] = NO_PEER;

      for(j=0; j<MAX_NUM_CONTACTED_PEERS; j++)
	if(device[actualDeviceId].hash_hostTraffic[idx]->contactedRcvdPeersIndexes[j] == hostIdx)
	  device[actualDeviceId].hash_hostTraffic[idx]->contactedRcvdPeersIndexes[j] = NO_PEER;

      for(j=0; j<MAX_NUM_HOST_ROUTERS; j++)
	if(device[actualDeviceId].hash_hostTraffic[idx]->contactedRouters[j] == hostIdx)
	  device[actualDeviceId].hash_hostTraffic[idx]->contactedRouters[j] = NO_PEER;
    }

  if(freeListLen == FREE_LIST_LEN) {
    free(freeHostList[nextIdxToFree]); /* This is the real free */
    freeHostList[nextIdxToFree] = host;
    nextIdxToFree = (nextIdxToFree+1)%FREE_LIST_LEN;
  } else
    freeHostList[freeListLen++] = host;
}

/* ************************************ */

void purgeIdleHosts(int ignoreIdleTime) {
  u_int idx, numFreedBuckets=0;

#ifdef PURGE_DEBUG
  printf("Purging (%d)....\n", ignoreIdleTime);
#endif

  purgeOldFragmentEntries(); /* let's do this too */

  for(idx=0; idx<actualHashSize; idx++)
    if((idx != broadcastEntryIdx /* This entry isn't purgeable */)
       && (device[actualDeviceId].hash_hostTraffic[idx] != NULL)
       && (device[actualDeviceId].hash_hostTraffic[idx]->instanceInUse == 0)
       && (!subnetLocalHost(device[actualDeviceId].hash_hostTraffic[idx]))) {

      if((ignoreIdleTime == 0)
	 && ((device[actualDeviceId].hash_hostTraffic[idx]->lastSeen+IDLE_HOST_PURGE_TIMEOUT) > actTime)) {
	continue;
      } else {
	updateHostTraffic(device[actualDeviceId].hash_hostTraffic[idx]);
	freeHostInfo(idx);
	numFreedBuckets++;

	if((device[actualDeviceId].hostsno < hashThreshold)
	   || (numFreedBuckets > MIN_NUM_FREED_BUCKETS))
	  break; /* We freed enough space */
      }
    }
}

/* ************************************ */

void scanTimedoutTCPSessions() {
  u_int idx;

#ifdef DEBUG
  printf("Called scanTimedoutTCPSessions\n");
#endif

  for(idx=0; idx<actualHashSize; idx++) {
    if(tcpSession[idx] != NULL) {

      if(tcpSession[idx]->magic != MAGIC_NUMBER) {
	tcpSession[idx] = NULL;
	numTcpSessions--;
	printf("Magic assertion failed!\n");
	continue;
      }

#ifdef DEBUG
      printf("Session to scan (%d): %s:%d <--> %s:%d (%lu/%lu)\n", idx,
	     ipaddr2str(device[actualDeviceId].hash_hostTraffic[checkSessionIdx(tcpSession[idx]->initiatorIdx)]->hostIpAddress),
	     tcpSession[idx]->sport,
	     ipaddr2str(device[actualDeviceId].hash_hostTraffic[checkSessionIdx(tcpSession[idx]->remotePeerIdx)]->hostIpAddress),
	     tcpSession[idx]->dport,
	     tcpSession[idx]->lastSeen+TWO_MSL_TIMEOUT,
	     actTime);
#endif
      if(
	 ((tcpSession[idx]->sessionState == STATE_TIMEOUT)
	  && ((tcpSession[idx]->lastSeen+TWO_MSL_TIMEOUT) < actTime))
	 || /* The branch below allows to flush sessions which have not been
	       terminated properly (we've received just one FIN (not two). It might be
	       that we've lost some packets (hopefully not). */
	 ((tcpSession[idx]->sessionState >= STATE_FIN1_ACK0)
	  && ((tcpSession[idx]->lastSeen+DOUBLE_TWO_MSL_TIMEOUT) < actTime))
	 /* The line below allows to avoid keeping very old sessions that
	    might be still open, but that are probably closed and we've
	    lost some packets */
	 || ((tcpSession[idx]->lastSeen+IDLE_HOST_PURGE_TIMEOUT) < actTime)
	 )
	{
	  IPSession *sessionToPurge = tcpSession[idx];

 	  tcpSession[idx] = NULL;
	  numTcpSessions--;

	  /* Session to purge */

	  if(sessionToPurge->sport < sessionToPurge->dport) { /* Server -> Client */
	    if(getPortByNum(sessionToPurge->sport, IPPROTO_TCP) != NULL) {
	      updateHostSessionsList(sessionToPurge->initiatorIdx, sessionToPurge->sport,
				     sessionToPurge->remotePeerIdx, sessionToPurge,
				     IPPROTO_TCP, SERVER_TO_CLIENT, SERVER_ROLE);
	      updateHostSessionsList(sessionToPurge->remotePeerIdx, sessionToPurge->sport,
				     sessionToPurge->initiatorIdx, sessionToPurge,
				     IPPROTO_TCP, CLIENT_FROM_SERVER, CLIENT_ROLE);
	    }
	  } else { /* Client -> Server */
	    if(getPortByNum(sessionToPurge->dport, IPPROTO_TCP) != NULL) {
	      updateHostSessionsList(sessionToPurge->remotePeerIdx, sessionToPurge->dport,
				     sessionToPurge->initiatorIdx, sessionToPurge,
				     IPPROTO_TCP, SERVER_FROM_CLIENT, SERVER_ROLE);
	      updateHostSessionsList(sessionToPurge->initiatorIdx, sessionToPurge->dport,
				     sessionToPurge->remotePeerIdx, sessionToPurge,
				     IPPROTO_TCP, CLIENT_TO_SERVER, CLIENT_ROLE);
	    }
	  }

	  /*
	   * Having updated the session information, 'theSession'
	   * can now be purged.
	   */
	  sessionToPurge->magic = 0;

	  notifyTCPSession(sessionToPurge);
	  free(sessionToPurge); /* No inner pointers to free */
	}
    }
  } /* end for */

}

/* ************************************ */

void updateUsedPorts(HostTraffic *srcHost,
		     u_int srcHostIdx,
		     HostTraffic *dstHost,
		     u_int dstHostIdx,
		     u_short sport,
		     u_short dport,
		     u_int length) {

  /* printf("%d\n", length); */

  if(srcHostIdx != broadcastEntryIdx) {
    if(sport < TOP_ASSIGNED_IP_PORTS) {
      if(srcHost->portsUsage[sport] == NULL) {
	srcHost->portsUsage[sport] = (PortUsage*)malloc(sizeof(PortUsage));
	memset(srcHost->portsUsage[sport], 0, sizeof(PortUsage));
    }
      if(dstHost->portsUsage[sport] == NULL) {
	dstHost->portsUsage[sport] = (PortUsage*)malloc(sizeof(PortUsage));
	memset(dstHost->portsUsage[sport], 0, sizeof(PortUsage));
      }
      
      srcHost->portsUsage[sport]->serverTraffic += length;
      srcHost->portsUsage[sport]->serverUses++;
      srcHost->portsUsage[sport]->serverUsesLastPeer = dstHostIdx;

      if(dstHostIdx != broadcastEntryIdx) {
	dstHost->portsUsage[sport]->clientTraffic += length;
	dstHost->portsUsage[sport]->clientUses++;
	dstHost->portsUsage[sport]->clientUsesLastPeer = srcHostIdx;
      }
    }
  }

  if(dstHostIdx != broadcastEntryIdx) {
    if(dport < TOP_ASSIGNED_IP_PORTS) {
      if(srcHost->portsUsage[dport] == NULL) {
	srcHost->portsUsage[dport] = (PortUsage*)malloc(sizeof(PortUsage));
	memset(srcHost->portsUsage[dport], 0, sizeof(PortUsage));
      }
      if(dstHost->portsUsage[dport] == NULL) {
	dstHost->portsUsage[dport] = (PortUsage*)malloc(sizeof(PortUsage));
	memset(dstHost->portsUsage[dport], 0, sizeof(PortUsage));
      }
      
      if(srcHostIdx != broadcastEntryIdx) {
	srcHost->portsUsage[dport]->clientTraffic += length;
	srcHost->portsUsage[dport]->clientUses++;
	srcHost->portsUsage[dport]->clientUsesLastPeer = dstHostIdx;
      }
      
      dstHost->portsUsage[dport]->serverTraffic += length;
      dstHost->portsUsage[dport]->serverUses++;
      dstHost->portsUsage[dport]->serverUsesLastPeer = srcHostIdx;
    }
  }
}

/* ************************************ */

void handleSession(IPSession *sessions[],
		   u_short *numSessions,
		   u_int srcHostIdx,
		   u_short sport,
		   u_int dstHostIdx,
		   u_short dport,
		   u_int length,
		   struct tcphdr *tp,
		   u_int tcpDataLength)
{
  u_int idx, initialIdx;
  IPSession *theSession = NULL;
  short flowDirection;
  u_short sessionType, check;
  u_short sessSport, sessDport;
  HostTraffic *srcHost = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(srcHostIdx)];
  HostTraffic *dstHost = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(dstHostIdx)];

  if(broadcastHost(srcHost) || broadcastHost(dstHost))
    return;

#ifdef DEBUG
  printf("%8x/%8x %8x\n",
	 srcHost->hostIpAddress.s_addr,
	 dstHost->hostIpAddress.s_addr,
	 localHostAddress.s_addr);
#endif

  if(tp == NULL)
    sessionType = IPPROTO_UDP;
  else {
    sessSport = ntohs(tp->th_sport);
    sessDport = ntohs(tp->th_dport);
    sessionType = IPPROTO_TCP;
  }

  /*
   * The hash key has to be calculated in a specular
   * way: its value has to be the same regardless
   * of the flow direction.
   *
   * Patch on the line below courtesy of
   * Paul Chapman <pchapman@fury.bio.dfo.ca>
   */
  initialIdx = idx = (u_int)(((u_long)srcHost+(u_long)dstHost+
			      (u_long)sport+(u_long)dport) % actualHashSize);

  if(sessionType == IPPROTO_TCP) {
    for(;;) {
      theSession = sessions[idx];
      if(theSession != NULL) {

	if((theSession->initiatorIdx == srcHostIdx) && (theSession->remotePeerIdx == dstHostIdx)
	   && (theSession->sport == sport) && (theSession->dport == dport)) {
	  flowDirection = CLIENT_TO_SERVER;
	  break;
	} else if((theSession->initiatorIdx == dstHostIdx) && (theSession->remotePeerIdx == srcHostIdx)
		  && (theSession->sport == dport) && (theSession->dport == sport)) {
	  flowDirection = SERVER_TO_CLIENT;
	  break;
	}
      } else if(theSession == NULL) {
	/* New Session */

	if(tp->th_flags & TH_FIN) {
	  /* We've received a FIN for a session that
	     we've not seen (ntop started when the session completed).
	  */
#ifdef DEBUG
	  printf("Received FIN %u for unknown session\n",  ntohl(tp->th_seq)+tcpDataLength);
#endif
	  return; /* Nothing else to do */
	}

	if((*numSessions) > (actualHashSize/2)) {
	  /* The hash table is getting large: let's replace the oldest session
	     with this one we're allocating */
	  u_int usedIdx=0;

	  for(idx=0; idx<actualHashSize; idx++) {
	    if(sessions[idx] != NULL) {
	      if(theSession == NULL) {
		theSession = sessions[idx];
		usedIdx = idx;
	      }
	      else if(theSession->lastSeen > sessions[idx]->lastSeen) {
		theSession = sessions[idx];
		usedIdx = idx;
	      }
	    }
	  }

	  sessions[usedIdx] = NULL;
	} else {
	  /* There's enough space left in the hashtable */
	  theSession = (IPSession*)malloc(sizeof(IPSession));
	  memset(theSession, 0, sizeof(IPSession));
	  theSession->magic = MAGIC_NUMBER;
	  (*numSessions)++;
	}

	while(sessions[initialIdx] != NULL)
	  initialIdx = ((initialIdx+1) % actualHashSize);

	sessions[initialIdx] = theSession;

	theSession->initiatorIdx = checkSessionIdx(srcHostIdx);
	theSession->remotePeerIdx = checkSessionIdx(dstHostIdx);
	theSession->sport = sport;
	theSession->dport = dport;
	theSession->firstSeen = actTime;
	flowDirection = CLIENT_TO_SERVER;

#ifdef DEBUG
	printSession(theSession, sessionType, 0);
#endif
	break;
      }

      idx = ((idx+1) % actualHashSize);
    }

    theSession->lastSeen = actTime;

    if(flowDirection == CLIENT_TO_SERVER)
      theSession->bytesSent += length;
    else
      theSession->bytesReceived += length;

    /*
     *
     * In this case the session is over hence the list of
     * sessions initiated/received by the hosts can be updated
     *
     */

    if(tp->th_flags & TH_FIN) {
      u_int32_t fin = ntohl(tp->th_seq)+tcpDataLength;

      if(sport < dport) /* Server -> Client */
	check = (fin != theSession->lastSCFin);
      else /* Client -> Server */
	check = (fin != theSession->lastCSFin);

      if(check) {
	/* This is not a duplicated (retransmitted) FIN */
	theSession->finId[theSession->numFin] = fin;
	theSession->numFin = (theSession->numFin+1)%MAX_NUM_FIN;;

	if(sport < dport) /* Server -> Client */
	  theSession->lastSCFin = fin;
	else /* Client -> Server */
	  theSession->lastCSFin = fin;
	switch(theSession->sessionState) {
	case STATE_BEGIN:
	  theSession->sessionState = STATE_FIN1_ACK0;
	  break;
	case STATE_FIN1_ACK0:
	  theSession->sessionState = STATE_FIN1_ACK1;
	  break;
	case STATE_FIN1_ACK1:
	  theSession->sessionState = STATE_FIN2_ACK1;
	  break;
#ifdef DEBUG
	default:
	  printf("ERROR: unable to handle received FIN (%u) !\n", fin);
#endif
	}
      } else {
#ifdef DEBUG
	printf("Rcvd Duplicated FIN %u\n", fin);
#endif
      }
    } else if(tp->th_flags & TH_ACK) {
      u_int32_t ack = ntohl(tp->th_ack);

      if((ack == theSession->lastAckIdI2R)
	 && (ack == theSession->lastAckIdR2I)) {
	if(theSession->initiatorIdx == srcHostIdx) {
	  theSession->numDuplicatedAckI2R++;
	  theSession->bytesRetranI2R += length;
	  device[actualDeviceId].hash_hostTraffic[theSession->initiatorIdx]->pktDuplicatedAckSent++;
	  device[actualDeviceId].hash_hostTraffic[theSession->remotePeerIdx]->pktDuplicatedAckRcvd++;

#ifdef DEBUG
	  printf("Duplicated ACK %ld [ACKs=%d/bytes=%d]: ",
		 ack, theSession->numDuplicatedAckI2R,
		 (int)theSession->bytesRetranI2R);
#endif
	} else {
	  theSession->numDuplicatedAckR2I++;
	  theSession->bytesRetranR2I += length;
	  device[actualDeviceId].hash_hostTraffic[theSession->remotePeerIdx]->pktDuplicatedAckSent++;
	  device[actualDeviceId].hash_hostTraffic[theSession->initiatorIdx]->pktDuplicatedAckRcvd++;
#ifdef DEBUG
	  printf("Duplicated ACK %ld [ACKs=%d/bytes=%d]: ",
		 ack, theSession->numDuplicatedAckR2I,
		 (int)theSession->bytesRetranR2I);
#endif
	}

#ifdef DEBUG
	printf("%s:%d -> ",
	       device[actualDeviceId].hash_hostTraffic[theSession->initiatorIdx]->hostSymIpAddress,
	       theSession->sport);
   	printf("%s:%d\n",
	       device[actualDeviceId].hash_hostTraffic[theSession->remotePeerIdx]->hostSymIpAddress,
	       theSession->dport);
#endif
      }

	if(theSession->initiatorIdx == srcHostIdx)
	  theSession->lastAckIdI2R = ack;
	else
	  theSession->lastAckIdR2I = ack;

      if(theSession->numFin > 0) {
	int i;

	if(sport < dport) /* Server -> Client */
	  check = (ack != theSession->lastSCAck);
	else /* Client -> Server */
	  check = (ack != theSession->lastCSAck);

	if(check) {
	  /* This is not a duplicated ACK */

	  if(sport < dport) /* Server -> Client */
	    theSession->lastSCAck = ack;
	  else /* Client -> Server */
	    theSession->lastCSAck = ack;

	  for(i=0; i<theSession->numFin; i++) {
	    if((theSession->finId[i]+1) == ack) {
	      theSession->numFinAcked++;
	      theSession->finId[i] = 0;

	      switch(theSession->sessionState) {
	      case STATE_FIN1_ACK0:
		theSession->sessionState = STATE_FIN1_ACK1;
		break;
	      case STATE_FIN2_ACK0:
		theSession->sessionState = STATE_FIN2_ACK1;
		break;
	      case STATE_FIN2_ACK1:
		theSession->sessionState = STATE_FIN2_ACK2;
		break;
#ifdef DEBUG
	      default:
		printf("ERROR: unable to handle received ACK (%u) !\n", ack);
#endif
	      }
	      break;
	    }
	  }
	} else {
	}
      }
    }

    theSession->lastFlags = tp->th_flags;

    if((theSession->sessionState == STATE_FIN2_ACK2)
       || ((tp->th_flags & TH_RST) != 0)) /* abortive release */ {
      theSession->sessionState = STATE_TIMEOUT;
      updateUsedPorts(srcHost, srcHostIdx, dstHost, dstHostIdx, sport, dport,
		      (u_int)(theSession->bytesSent+theSession->bytesReceived));
    }
  } else if(sessionType == IPPROTO_UDP) {
    IPSession tmpSession;

    memset(&tmpSession, 0, sizeof(IPSession));

    updateUsedPorts(srcHost, srcHostIdx, dstHost, dstHostIdx, sport, dport, length);

    tmpSession.lastSeen = actTime;
    tmpSession.initiatorIdx = checkSessionIdx(srcHostIdx),
      tmpSession.remotePeerIdx = checkSessionIdx(dstHostIdx);
    tmpSession.bytesSent = (TrafficCounter)length, tmpSession.bytesReceived = 0;
    tmpSession.sport = sport, tmpSession.dport = dport;

#ifdef DEBUG
    printSession(&tmpSession, sessionType, 0);
#endif

    if(getPortByNum(sport, sessionType) != NULL) {
      updateHostSessionsList(srcHostIdx, sport, dstHostIdx, &tmpSession,
			     sessionType, SERVER_TO_CLIENT, SERVER_ROLE);
      tmpSession.bytesSent = 0, tmpSession.bytesReceived = (TrafficCounter)length;
      updateHostSessionsList(dstHostIdx, sport, srcHostIdx, &tmpSession,
			     sessionType, CLIENT_FROM_SERVER, CLIENT_ROLE);
    } else {
#if defined(MULTITHREADED)
      accessMutex(&lsofMutex, "HandleSession-1");
#endif
      updateLsof = 1; /* Force lsof update */
#if defined(MULTITHREADED)
      releaseMutex(&lsofMutex);
#endif
    }

    if(getPortByNum(dport, sessionType) != NULL) {
      updateHostSessionsList(srcHostIdx, dport, dstHostIdx, &tmpSession,
			     sessionType, CLIENT_TO_SERVER, CLIENT_ROLE);
      tmpSession.bytesSent = 0, tmpSession.bytesReceived = (TrafficCounter)length;
      updateHostSessionsList(dstHostIdx, dport, srcHostIdx, &tmpSession,
			     sessionType, SERVER_FROM_CLIENT, SERVER_ROLE);
    } else {
#if defined(MULTITHREADED)
      accessMutex(&lsofMutex, "HandleSession-2");
#endif
      updateLsof = 1; /* Force lsof update */
#if defined(MULTITHREADED)
      releaseMutex(&lsofMutex);
#endif
    }
  }
}

/* ************************************ */


void addLsofContactedPeers(ProcessInfo *process, u_int peerHostIdx) {
  int i;

  if((process == NULL)
     || (peerHostIdx == NO_PEER)
     || broadcastHost(device[actualDeviceId].hash_hostTraffic[checkSessionIdx(peerHostIdx)]))
    return;

  for(i=0; i<MAX_NUM_CONTACTED_PEERS; i++)
    if(process->contactedIpPeersIndexes[i] == peerHostIdx)
      return;

  process->contactedIpPeersIndexes[process->contactedIpPeersIdx] = peerHostIdx;
  process->contactedIpPeersIdx = (process->contactedIpPeersIdx+1) % MAX_NUM_CONTACTED_PEERS;
}


/* ************************************ */

void handleLsof(u_int srcHostIdx,
		u_short sport,
		u_int dstHostIdx,
		u_short dport,
		u_int length) {
  HostTraffic *srcHost, *dstHost;

  srcHost = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(srcHostIdx)];
  dstHost = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(dstHostIdx)];

  if(subnetLocalHost(srcHost))
     if((sport < TOP_IP_PORT) && (localPorts[sport] != NULL)) {
      ProcessInfoList *scanner = localPorts[sport];

      while(scanner != NULL) {
	scanner->element->bytesSent += length;
	scanner->element->lastSeen   = actTime;
	addLsofContactedPeers(scanner->element, dstHostIdx);
	scanner = scanner->next;
      }
    }

  if(subnetLocalHost(dstHost))
    if((dport < TOP_IP_PORT) && (localPorts[dport] != NULL)) {
      ProcessInfoList *scanner = localPorts[dport];

      while(scanner != NULL) {
	  scanner->element->bytesReceived += length;
	  scanner->element->lastSeen   = actTime;
	  addLsofContactedPeers(scanner->element, srcHostIdx);
	  scanner = scanner->next;
	}
    }
}

/* *********************************** */

void handleTCPSession(u_int srcHostIdx,
		      u_short sport,
		      u_int dstHostIdx,
		      u_short dport,
		      u_int length,
		      struct tcphdr *tp,
		      u_int tcpDataLength) {

  if(
#ifdef SESSION_PATCH
     1
#else
     (tp->th_flags & TH_SYN) == 0
#endif
     ) {
    /* When we receive SYN it means that the client is trying to
       open a session with the server hence the session is NOT YET
       open. That's why we don't count this as a session in this
       case.
    */
    handleSession(tcpSession, &numTcpSessions,
		  srcHostIdx, sport,
		  dstHostIdx, dport,
		  length, tp, tcpDataLength);
  }

  if(isLsofPresent)
    handleLsof(srcHostIdx, sport, dstHostIdx, dport, length);
}

/* ************************************ */

void handleUDPSession(u_int srcHostIdx,
		      u_short sport,
		      u_int dstHostIdx,
		      u_short dport,
		      u_int length) {

  handleSession(udpSession, &numUdpSessions, srcHostIdx, sport,
		dstHostIdx, dport, length, NULL, 0);

  if(isLsofPresent)
    handleLsof(srcHostIdx, sport, dstHostIdx, dport, length);
}

/* ************************************ */

int handleIP(u_short port,
	     u_int srcHostIdx,
	     u_int dstHostIdx,
	     u_int length) {

  int idx = mapGlobalToLocalIdx(port);
  HostTraffic *srcHost, *dstHost;

  if(idx == -1)
    return(-1); /* Unable to locate requested index */

  srcHost = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(srcHostIdx)];
  dstHost = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(dstHostIdx)];

  if(idx != -1) {
    if(subnetPseudoLocalHost(srcHost)) {
      if(subnetPseudoLocalHost(dstHost)) {
	if((srcHostIdx != broadcastEntryIdx) && (!broadcastHost(srcHost)))
	  srcHost->protoIPTrafficInfos[idx].sentLocally += length;
	if((dstHostIdx != broadcastEntryIdx) && (!broadcastHost(dstHost)))
	  dstHost->protoIPTrafficInfos[idx].receivedLocally += length;
	ipProtoStats[idx].local += length;
      } else {
	if((srcHostIdx != broadcastEntryIdx) && (!broadcastHost(srcHost)))
	  srcHost->protoIPTrafficInfos[idx].sentRemotely += length;
	if((dstHostIdx != broadcastEntryIdx) && (!broadcastHost(dstHost)))
	  dstHost->protoIPTrafficInfos[idx].receivedLocally += length;
	ipProtoStats[idx].local2remote += length;
      }
    } else {
      /* srcHost is remote */
      if(subnetPseudoLocalHost(dstHost)) {
	if((srcHostIdx != broadcastEntryIdx) && (!broadcastHost(srcHost)))
	  srcHost->protoIPTrafficInfos[idx].sentLocally += length;
	if((dstHostIdx != broadcastEntryIdx) && (!broadcastHost(dstHost)))
	  dstHost->protoIPTrafficInfos[idx].receivedFromRemote += length;
	ipProtoStats[idx].remote2local += length;
      } else {
	if((srcHostIdx != broadcastEntryIdx) && (!broadcastHost(srcHost)))
	  srcHost->protoIPTrafficInfos[idx].sentRemotely += length;
	if((dstHostIdx != broadcastEntryIdx) && (!broadcastHost(dstHost)))
	  dstHost->protoIPTrafficInfos[idx].receivedFromRemote += length;
	ipProtoStats[idx].remote += length;
      }
    }
  }

  return(idx);
}

/* ************************************ */

void addContactedPeers(u_int senderIdx, u_int receiverIdx) {
  short i, found;
  HostTraffic *sender, *receiver;
  
  sender = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(senderIdx)];
  receiver = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(receiverIdx)];
  
  /* ******************************* */
  if(senderIdx != broadcastEntryIdx) {
    if(sender != NULL) {
      for(found=0, i=0; i<MAX_NUM_CONTACTED_PEERS; i++)
      if(sender->contactedSentPeersIndexes[i] != NO_PEER) {
	if((sender->contactedSentPeersIndexes[i] == receiverIdx)
	   || (((receiverIdx == broadcastEntryIdx) || broadcastHost(receiver))
	       && broadcastHost(device[actualDeviceId].hash_hostTraffic[checkSessionIdx(sender->contactedSentPeersIndexes[i])]))) {
	  found = 1;
	  break;
	}
      }
      
    if(found == 0) {
      sender->contactedSentPeersIndexes[sender->contactedSentPeersIdx] = receiverIdx;
      sender->contactedSentPeersIdx = (sender->contactedSentPeersIdx+1) % MAX_NUM_CONTACTED_PEERS;
    }
    }
  }


  /* ******************************* */
  if(receiverIdx != broadcastEntryIdx) {
    if(receiver != NULL) {
      for(found=0, i=0; i<MAX_NUM_CONTACTED_PEERS; i++)
      if(receiver->contactedRcvdPeersIndexes[i] != NO_PEER) {
	if((receiver->contactedRcvdPeersIndexes[i] == senderIdx)
	   || (((senderIdx == broadcastEntryIdx) || broadcastHost(sender))
	       && broadcastHost(device[actualDeviceId].hash_hostTraffic[checkSessionIdx(receiver->
								 contactedRcvdPeersIndexes[i])]))) {
	  found = 1;
	  break;
	}
      }
      
      if(found == 0) {
	receiver->contactedRcvdPeersIndexes[receiver->contactedRcvdPeersIdx] = senderIdx;
	receiver->contactedRcvdPeersIdx = (receiver->contactedRcvdPeersIdx+1) % MAX_NUM_CONTACTED_PEERS;
      }
    }
  }
}

/* ************************************ */

int addFragmentInfo(HostTraffic *srcHost,
		    HostTraffic *dstHost,
		    u_short sport,
		    u_short dport,
		    u_int fragmentId,
		    u_short checkTableFirst,
		    u_int dataLength) {
  IpFragment *fragment;
  u_int idx, startIdx, retry=0;
  u_int packetLen = 0;

ADD_FRAGMENT:
  startIdx = idx = ((u_int)((unsigned long)srcHost+
			    (unsigned long)dstHost)*fragmentId) % actualHashSize;


  if(checkTableFirst) {
    /* Some IP stacks send fragments before the real packet.
       In this case it is necessary to check first if the
       table contains the entry, and if this is an entry
       added before the packet, then adding the packet
       clears the entry bucket.
    */

      while(1) {
	fragment = fragmentTable[idx];

	if((fragment != NULL)
	   && (fragment->src == srcHost)
	   && (fragment->dest == dstHost)
	   && (fragment->fragmentId == fragmentId)) {
	  fragment->sport = sport;
	  fragment->dport = dport;

	  packetLen = fragment->totalLenght+dataLength;
	  free(fragment);
	  fragmentTable[idx] = NULL;
#ifdef DEBUG
	  printf("Removed fragmentId %u entry\n", fragmentId);
#endif
	  return(packetLen);
	} else if(startIdx == idx) {
#ifdef DEBUG
	  /* printf("ERROR: unable to find the expected fragment %u!\n", fragmentId); */
#endif
	  break;
	}

	idx = (idx+1) % actualHashSize;
      }

  }

#ifdef DEBUG
  printf("Added fragmentId %u\n", fragmentId);
#endif

  while(1) {
    fragment = fragmentTable[idx];

    if(fragment == NULL) {
      fragment = (IpFragment*)malloc(sizeof(IpFragment));
      memset(fragment, 0, sizeof(IpFragment));
      fragment->src = srcHost;
      fragment->dest = dstHost;
      fragment->fragmentId = fragmentId;
      fragment->sport = sport;
      fragment->dport = dport;
      fragment->firstSeen = actTime;
      fragment->totalLenght = dataLength;
      fragmentTable[idx] = fragment;
      packetLen = dataLength;
      return(packetLen);
    }

    idx = (idx+1) % actualHashSize;

    if(startIdx == idx) {
      if(retry == 0) {
	purgeOldFragmentEntries();
	retry++;
	goto ADD_FRAGMENT;
      } else {
#ifdef DEBUG
	printf("ERROR: the fragment table is full!\n");
#endif
	break;
      }
    }
  }

  return(packetLen);
}


/* ************************************ */

u_int getFragmentInfo(HostTraffic *srcHost,
		      HostTraffic *dstHost,
		      u_short *sport,
		      u_short *dport,
		      u_int fragmentId,
		      u_int fragmentOffset,
		      u_short fragmentAction,
		      u_int dataLength) {
  IpFragment *fragment;
  u_int idx, startIdx;
  u_int packetLen = 0;

  startIdx = idx = ((u_int)((unsigned long)srcHost+
			    (unsigned long)dstHost)*fragmentId) % actualHashSize;

  while(1) {
    fragment = fragmentTable[idx];

    if((fragment != NULL)
       && (fragment->src == srcHost)
       && (fragment->dest == dstHost)
       && (fragment->fragmentId == fragmentId)) {
      (*sport) = fragment->sport;
      (*dport) = fragment->dport;

#ifdef DEBUG
      printf("Found fragmentId %u\n", fragmentId);
#endif

      fragment->totalLenght += dataLength;
      packetLen = fragment->totalLenght;

      if(fragment->lastOffset > fragmentOffset) {
	char buf[BUF_SIZE];
	sprintf(buf, "Detected overlapping packet fragment [%s->%s]: "
		"fragment id=%d, actual offset=%d, previous offset=%d\n",
		srcHost->hostSymIpAddress,
		dstHost->hostSymIpAddress,
		fragmentId, fragmentOffset,
		fragment->lastOffset);

	logMessage(buf, WARNING_MSG);
      }

      fragment->lastOffset = fragmentOffset;

      if((fragmentAction == DELETE_FRAGMENT)
	 /* The check below makes sure that the entry is deleted if and
	    only if the main packet is arrived. If ports are still set
	    to 0 then such packet is not arrived yet */
	 && (fragment->sport != 0)
	 && (fragment->dport != 0)) {
	free(fragment);
	fragmentTable[idx] = NULL;
#ifdef DEBUG
	printf("Removed fragmentId %u entry\n", fragmentId);
#endif
      }

      break;
    }

    idx = (idx+1) % actualHashSize;

    if((fragment == NULL) || (startIdx == idx)) {
      /* It might be that the fragment is arrived before the
	 packet header. This happens on linux as shown below:

	 1) 18:14:44.359812 192.168.1.1 > 192.168.1.130: (frag 403:1244@2960)
	 2) 18:14:44.359934 192.168.1.1 > 192.168.1.130: (frag 403:1480@1480+)
	 3) 18:14:44.360062 192.168.1.1.2049 > 192.168.1.130.1093745289:
  	                    reply ok 1472 read [|nfs] (frag 403:1480@0+)

	 The two fragments (1) and (2) are arrived before
	 the packet (3). We now add a new entry that will be purged
	 when the packet arrives.
      */
      /* printf("sport=%d - dport = %d - fragmentId = %d\n", *sport, *dport, fragmentId); */
      addFragmentInfo(srcHost, dstHost, *sport, *dport, fragmentId, 0, dataLength);
      packetLen = dataLength;
      break;
    }
  }

  return(packetLen);
}
#undef DEBUG

/* ************************************ */

void purgeOldFragmentEntries() {
  u_int i;

  for(i=0; i<actualHashSize; i++) {
    if((fragmentTable[i] != NULL)
       && ((fragmentTable[i]->firstSeen+DOUBLE_TWO_MSL_TIMEOUT) > actTime)) {
      free(fragmentTable[i]);
      fragmentTable[i] = NULL;
    }
  }
}

/* ************************************ */

void processDNSPacket(const u_char *bp, u_int length, u_int hlen) {
  DNSHostInfo hostPtr;
  struct in_addr hostIpAddress;
#ifdef HAVE_GDBM_H
  datum key_data, data_data;
#endif

  memset(&hostPtr, 0, sizeof(DNSHostInfo));

  handleDNSpacket(bp, (u_short)(hlen+sizeof(struct udphdr)),
		  &hostPtr, (short)(length-(hlen+sizeof(struct udphdr))));

  if((hostPtr.name[0] != '\0') && (hostPtr.addrList[0] != 0)) {
    int i;

    hostIpAddress.s_addr = ntohl(hostPtr.addrList[0]);

#ifdef MULTITHREADED
    accessMutex(&gdbmMutex, "processDNSPacket");
#endif

    for(i=0; i<MAXALIASES; i++)
      if(hostPtr.aliases[i][0] != '\0') {
#ifdef DNS_SNIFF_DEBUG
	printf("%s alias of %s\n",
	       hostPtr.aliases[i], hostPtr.name);
#endif
#ifdef HAVE_GDBM_H
	key_data.dptr = intoa(hostIpAddress);
	key_data.dsize = strlen(key_data.dptr)+1;
	data_data.dptr = hostPtr.aliases[0]; /* Let's take the first one */
	data_data.dsize = strlen(data_data.dptr)+1;
	gdbm_store(gdbm_file, key_data, data_data, GDBM_REPLACE);
#endif
      } else
	break;

#ifdef HAVE_GDBM_H
    data_data.dptr = hostPtr.name;
    data_data.dsize = strlen(data_data.dptr)+1;
#endif

    for(i=0; i<MAXADDRS; i++)
      if(hostPtr.addrList[i] != 0){
	hostIpAddress.s_addr = ntohl(hostPtr.addrList[i]);
#ifdef DNS_SNIFF_DEBUG
	printf("%s <-> %s\n",
	       hostPtr.name, intoa(hostIpAddress));
#endif
#ifdef HAVE_GDBM_H
	key_data.dptr = intoa(hostIpAddress);
	key_data.dsize = strlen(key_data.dptr)+1;
	gdbm_store(gdbm_file, key_data, data_data, GDBM_REPLACE);
#endif
      }

#ifdef MULTITHREADED
    releaseMutex(&gdbmMutex);
#endif
  }
}

/* ************************************ */

void checkNetworkRouter(HostTraffic *srcHost,
			HostTraffic *dstHost,
			u_char *ether_dst) {

  if((!subnetLocalHost(dstHost))
     && (!broadcastHost(dstHost))
     && (!multicastHost(dstHost))) {
      u_int routerIdx, j;
      HostTraffic *router;

      routerIdx = getHostInfo(NULL, ether_dst);

      for(j=0; j<MAX_NUM_HOST_ROUTERS; j++)
	if(srcHost->contactedRouters[j] == routerIdx)
	  break;
	else if(srcHost->contactedRouters[j] == NO_PEER) {
	  srcHost->contactedRouters[j] = routerIdx;
	  break;
	}

      router = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(routerIdx)];

#ifdef DEBUG
      printf("router [%s/%s/%s] used by host [%s] for destination [%s]\n",
	     router->ethAddressString,
	     router->hostNumIpAddress,
	     router->hostSymIpAddress,
	     srcHost->hostSymIpAddress,
	     dstHost->hostNumIpAddress);
#endif
      FD_SET(GATEWAY_HOST_FLAG, &router->flags);
  }
}

/* ************************************ */

void processIpPkt(const u_char *bp,
		  u_int length,
		  u_char *ether_src,
		  u_char *ether_dst)
{
  u_short sport, dport;
  struct ip ip;
  struct tcphdr tp;
  struct udphdr up;
  struct icmp icmpPkt;
  u_int hlen, tcpDataLength, udpDataLength, off;
  char *proto;
  u_int srcHostIdx, dstHostIdx;
  HostTraffic *srcHost=NULL, *dstHost=NULL;
  u_char etherAddrSrc[ETHERNET_ADDRESS_LEN+1], etherAddrDst[ETHERNET_ADDRESS_LEN+1];


  /* Need to copy this over in case bp isn't properly aligned.
   * This occurs on SunOS 4.x at least.
   * Paul D. Smith <psmith@baynetworks.com>
   */
  memcpy(&ip, bp, sizeof(struct ip));
  hlen = (u_int)ip.ip_hl * 4;

  if((ether_src == NULL) && (ether_dst == NULL)) {
    /* Ethernet-less protocols (e.g. PPP/RAW IP) */

    memcpy(etherAddrSrc, &(ip.ip_src.s_addr), sizeof(ip.ip_src.s_addr));
    etherAddrSrc[ETHERNET_ADDRESS_LEN] = '\0';
    ether_src = etherAddrSrc;

    memcpy(etherAddrDst, &(ip.ip_dst.s_addr), sizeof(ip.ip_dst.s_addr));
    etherAddrDst[ETHERNET_ADDRESS_LEN] = '\0';
    ether_dst = etherAddrDst;
  }

  NTOHL(ip.ip_src.s_addr);
  srcHostIdx = getHostInfo(&ip.ip_src, ether_src);
  srcHost = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(srcHostIdx)];
  if(srcHost == NULL) {
    /* Sanity check */
    printf("Sanity check failed (1)\n");
  } else {
    /* Lock the instance so that the next call
       to getHostInfo won't purge it */
    srcHost->instanceInUse++;
  }

  NTOHL(ip.ip_dst.s_addr);
  dstHostIdx = getHostInfo(&ip.ip_dst, ether_dst);
  dstHost = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(dstHostIdx)];
  if(dstHost == NULL) {
    /* Sanity check */
    printf("Sanity check failed (2)\n");
  } else {
    /* Lock the instance so that the next call
       to getHostInfo won't purge it */
    dstHost->instanceInUse++;
  }

  checkNetworkRouter(srcHost, dstHost, ether_dst);
  updatePacketCount(srcHostIdx, dstHostIdx, (TrafficCounter)length);
  updateTrafficMatrix(srcHost, dstHost, (TrafficCounter)length);

  if(subnetPseudoLocalHost(srcHost)) {
    if(subnetPseudoLocalHost(dstHost)) {
      srcHost->bytesSentLocally += length;
      dstHost->bytesReceivedLocally += length;
    } else {
      srcHost->bytesSentRemotely += length;
      dstHost->bytesReceivedLocally += length;
    }
  } else {
    /* srcHost is remote */
    if(subnetPseudoLocalHost(dstHost)) {
      srcHost->bytesSentLocally += length;
      dstHost->bytesReceivedFromRemote += length;
    } else {
      srcHost->bytesSentRemotely += length;
      dstHost->bytesReceivedFromRemote += length;
    }
  }

  device[actualDeviceId].ipBytes += length;

#if (0)
  /*
   * Time to show the IP Packet Header (when enabled).
   */
  if (fd && device [actualDeviceId] . ipv)
    fprintf (fd, "IP:     ----- IP Header -----\n"),
      fprintf (fd, "IP:\n"),
      fprintf (fd, "IP:     Packet %ld arrived at %s\n", device [actualDeviceId] ,
	       timestamp (& lastPktTime, ABS_FMT)),
      fprintf (fd, "IP:     Total size  = %d : header = %d : data = %d\n",
	       ip_size, ip_hlen, ip_size - ip_hlen),
      fprintf (fd, "IP:     Source      = %s\n", inet_ntoa (ip -> ip_src)),
      fprintf (fd, "IP:     Destination = %s\n", inet_ntoa (ip -> ip_dst)),
      fflush (fd);
#endif

  off = ntohs(ip.ip_off);

  switch(ip.ip_p) {
  case IPPROTO_TCP:
    proto = "TCP";
    device[actualDeviceId].tcpBytes += length;
    memcpy(&tp, bp+hlen, sizeof(struct tcphdr));

    tcpDataLength = ntohs(ip.ip_len) - hlen - (tp.th_off * 4);

    sport = ntohs(tp.th_sport);
    dport = ntohs(tp.th_dport);

    if(tcpChain) {
      u_int displ;

      if (off & 0x3fff)
	displ = 0; /* Fragment */
      else
	displ = tp.th_off * 4;

      checkFilterChain(srcHost, srcHostIdx,
		       dstHost, dstHostIdx,
		       sport, dport,
		       tcpDataLength, /* packet length */
		       displ+sizeof(struct tcphdr), /* offset from packet header */
		       tp.th_flags, /* TCP flags */
		       IPPROTO_TCP,
		       (u_char)(off & 0x3fff), /* 1 = fragment, 0 = packet */
		       bp, /* pointer to packet content */
		       tcpChain, TCP_RULE);
    }

    if (off & 0x3fff) { /* Handle fragmented packets */
      u_int fragmentOffset = (off & 0x1fff) * 8;

      if(fragmentOffset == 0) /* First fragment */
	tcpDataLength = addFragmentInfo(srcHost, dstHost, sport, dport,
					ntohs(ip.ip_id), 1, tcpDataLength);
      else {
	if(!(off & IP_MF)) {
	  /* This is the last fragment */
	  sport = dport = 0;
	  tcpDataLength = getFragmentInfo(srcHost, dstHost, &sport,
					  &dport, ntohs(ip.ip_id),
					  fragmentOffset, DELETE_FRAGMENT,
					  tcpDataLength);
	} else {
	  /* Intermediate fragment */
	  sport = dport = 0;
	  tcpDataLength = getFragmentInfo(srcHost, dstHost, &sport,
					  &dport, ntohs(ip.ip_id),
					  fragmentOffset, KEEP_FRAGMENT,
					  tcpDataLength);
	}
      }
    }

    if((sport > 0) && (dport > 0)) {
      /* It might be that tcpDataLength is 0 when
	 the received packet is fragmented and the main
	 packet has not yet been received */

      if(subnetPseudoLocalHost(srcHost)) {
	if(subnetPseudoLocalHost(dstHost)) {
	  srcHost->tcpSentLocally += length;
	  dstHost->tcpReceivedLocally += length;
	  device[actualDeviceId].tcpGlobalTrafficStats.local += length;
	} else {
	  srcHost->tcpSentRemotely += length;
	  dstHost->tcpReceivedLocally += length;
	  device[actualDeviceId].tcpGlobalTrafficStats.local2remote += length;
	}
      } else {
	/* srcHost is remote */
	if(subnetPseudoLocalHost(dstHost)) {
	  srcHost->tcpSentLocally += length;
	  dstHost->tcpReceivedFromRemote += length;
	  device[actualDeviceId].tcpGlobalTrafficStats.remote2local += length;
	} else {
	  srcHost->tcpSentRemotely += length;
	  dstHost->tcpReceivedFromRemote += length;
	  device[actualDeviceId].tcpGlobalTrafficStats.remote += length;
	}
      }

     /* choose most likely port for protocol traffic accounting
      * by trying lower number port first. This is based
      * on the assumption that lower port numbers are more likely
      * to be the servers and clients usually dont use ports <1024
      * This is only relevant if both port numbers are used to
      * gather service statistics.
      * e.g. traffic between port 2049 (nfsd) and 113 (nntp) will
      * be counted as nntp traffic in all directions by this heuristic
      * and not as nntp in one direction and nfs in the return direction.
      *
      * Courtesy of Andreas Pfaller <a.pfaller@pop.gun.de>
      */
      if (dport < sport) {
	  if(handleIP(dport, srcHostIdx, dstHostIdx, length) == -1)
	    handleIP(sport, srcHostIdx, dstHostIdx, length);
      } else {
	if(handleIP(sport, srcHostIdx, dstHostIdx, length) == -1)
	  handleIP(dport, srcHostIdx, dstHostIdx, length);
      }

      handleTCPSession(srcHostIdx, sport, dstHostIdx,
		       dport, length, &tp, tcpDataLength);
    }
    break;

  case IPPROTO_UDP:
    proto = "UDP";
    device[actualDeviceId].udpBytes += length;
    memcpy(&up, bp+hlen, sizeof(struct udphdr));

    /* print TCP packet useful for debugging */

#ifdef SLACKWARE
    sport = ntohs(up.source);
    dport = ntohs(up.dest);
#else
    sport = ntohs(up.uh_sport);
    dport = ntohs(up.uh_dport);
#endif

    if(sport == 53 /* domain */) {
#ifdef DNS_SNIFF_DEBUG
      printf("(%s -> %s) ",
	     srcHost->hostSymIpAddress,
	     dstHost->hostSymIpAddress);
#endif

      /* The DNS chain will be checked here */
      FD_SET(DNS_HOST_FLAG, &srcHost->flags);
      processDNSPacket(bp, length, hlen);
    } else if((dport == 138 /*  NETBIOS */)
	      && ((srcHost->nbHostName == NULL)
		  || (srcHost->nbDomainName == NULL))) {
      char *name, nbName[64], domain[64];
      int nodeType, i;

      name = ((char*)bp+hlen+22);
      nodeType = name_interpret(name,nbName);
      srcHost->nbNodeType = (char)nodeType;

      for(i=0; nbName[i] != '\0'; i++) if(nbName[i] == ' ') { nbName[i] = '\0'; break; }
      if(srcHost->nbHostName != NULL) free(srcHost->nbHostName);
      srcHost->nbHostName = strdup(nbName);

      name = ((char*)bp+hlen+22+34);

      name_interpret(name, domain);
      for(i=0; domain[i] != '\0'; i++) if(domain[i] == ' ') { domain[i] = '\0'; break; }

      if(srcHost->nbDomainName != NULL) {
	free(srcHost->nbDomainName);
	srcHost->nbDomainName = NULL;
      }

      if(strcmp(domain, "__MSBROWSE__") && strncmp(&domain[2], "__", 2)) {
	srcHost->nbDomainName = strdup(domain);
#ifdef DEBUG
	printf("[%x] %s@'%s' (len=%d)\n", nodeType, nbName, domain, strlen(domain));
#endif
      }
    }

    if(udpChain) {
      u_int displ;

      udpDataLength = ntohs(ip.ip_len) - hlen - sizeof(struct udphdr);

      if (off & 0x3fff)
	displ = 0; /* Fragment */
      else
	displ = sizeof(struct udphdr);

      checkFilterChain(srcHost, srcHostIdx,
		       dstHost, dstHostIdx,
		       sport, dport,
		       udpDataLength, /* packet length */
		       hlen,   /* offset from packet header */
		       0,	   /* there are no UDP flags :-( */
		       IPPROTO_UDP,
		       (u_char)(off & 0x3fff), /* 1 = fragment, 0 = packet */
		       bp, /* pointer to packet content */
		       udpChain, UDP_RULE);
    }

    if (off & 0x3fff) { /* Handle fragmented packets */
      u_int fragmentOffset = (off & 0x1fff) * 8;

      if(fragmentOffset == 0) /* First fragment */
	length = addFragmentInfo(srcHost, dstHost, sport, dport,
				 ntohs(ip.ip_id), 1, length);
      else {
	if(!(off & IP_MF /* More Fragments */)) {
	  /* This is the last fragment */
	  sport = dport = 0;
	  length = getFragmentInfo(srcHost, dstHost, &sport,
				   &dport, ntohs(ip.ip_id),
				   fragmentOffset, DELETE_FRAGMENT,
				   length);
	} else {
	  /* Intermediate fragment */
	  sport = dport = 0;
	  length = getFragmentInfo(srcHost, dstHost, &sport,
				   &dport, ntohs(ip.ip_id),
				   fragmentOffset, KEEP_FRAGMENT,
				   length);
	}
      }
    }

    if((sport > 0) && (dport > 0)) {
      /* It might be that udpBytes is 0 when
	 the received packet is fragmented and the main
	 packet has not yet been received */

      if(subnetPseudoLocalHost(srcHost)) {
	if(subnetPseudoLocalHost(dstHost)) {
	  srcHost->udpSentLocally += length;
	  dstHost->udpReceivedLocally += length;
	  device[actualDeviceId].udpGlobalTrafficStats.local += length;
	} else {
	  srcHost->udpSentRemotely += length;
	  dstHost->udpReceivedLocally += length;
	  device[actualDeviceId].udpGlobalTrafficStats.local2remote += length;
	}
      } else {
	/* srcHost is remote */
	if(subnetPseudoLocalHost(dstHost)) {
	  srcHost->udpSentLocally += length;
	  dstHost->udpReceivedFromRemote += length;
	  device[actualDeviceId].udpGlobalTrafficStats.remote2local += length;
	} else {
	  srcHost->udpSentRemotely += length;
	  dstHost->udpReceivedFromRemote += length;
	  device[actualDeviceId].udpGlobalTrafficStats.remote += length;
	}
      }

      if(handleIP(dport, srcHostIdx, dstHostIdx, length) == -1)
	handleIP(sport, srcHostIdx, dstHostIdx, length);

      handleUDPSession(srcHostIdx, sport, dstHostIdx, dport, length);
    }
    break;

  case IPPROTO_ICMP:
    proto = "ICMP";
    memcpy(&icmpPkt, bp+hlen, sizeof(struct icmp));
    device[actualDeviceId].icmpBytes += length;
    srcHost->icmpSent += length;
    dstHost->icmpReceived += length;

    if(subnetPseudoLocalHost(srcHost))
      if(subnetPseudoLocalHost(dstHost))
	device[actualDeviceId].icmpGlobalTrafficStats.local += length;
      else
	device[actualDeviceId].icmpGlobalTrafficStats.local2remote += length;
    else /* srcHost is remote */
      if(subnetPseudoLocalHost(dstHost))
	device[actualDeviceId].icmpGlobalTrafficStats.remote2local += length;
       else
	device[actualDeviceId].icmpGlobalTrafficStats.remote += length;

    if(icmpChain)
      checkFilterChain(srcHost, srcHostIdx,
		       dstHost, dstHostIdx,
		       0 /* sport */, 0 /* dport */,
		       length, /* packet length */
		       0,   /* offset from packet header */
		       icmpPkt.icmp_type,
		       IPPROTO_ICMP,
		       0, /* 1 = fragment, 0 = packet */
		       bp+hlen, /* pointer to packet content */
		       icmpChain, ICMP_RULE);

    if((icmpPkt.icmp_type == ICMP_ECHO)
       && (broadcastHost(dstHost) || multicastHost(dstHost)))
       smurfAlert(srcHostIdx, dstHostIdx);
    break;

  case IPPROTO_OSPF:
    proto = "OSPF";
    device[actualDeviceId].ospfBytes += length;
    srcHost->ospfSent += length;
    dstHost->ospfReceived += length;
    break;

  case IPPROTO_IGMP:
    proto = "IGMP";
    device[actualDeviceId].igmpBytes += length;
    srcHost->igmpSent += length;
    dstHost->igmpReceived += length;
    break;

  default:
    proto = "IP (Other)";
    device[actualDeviceId].otherIpBytes += length;
    sport = dport = -1;
    srcHost->otherSent += length;
    dstHost->otherReceived += length;
    break;
  }
#ifdef DEBUG
  printf("IP=%d TCP=%d UDP=%d ICMP=%d (len=%d)\n",
	 (int)ipBytes, (int)tcpBytes, (int)udpBytes,
	 (int)icmpBytes, length);
#endif

  /* Unlock the instance */
  srcHost->instanceInUse--, dstHost->instanceInUse--;
}

/* ************************************ */

void updatePacketCount(u_int srcHostIdx, u_int dstHostIdx,
		       TrafficCounter length) {

  HostTraffic *srcHost, *dstHost;

  if((srcHostIdx == dstHostIdx) && (srcHostIdx == broadcastEntryIdx))
    return; /* It looks there's something wrong here */

  if(length > mtuSize[device[deviceId].datalink]) {
    /* Sanity check */
    printf("Wrong packet length (%lu on %s (deviceId=%d)!\n",
	   (unsigned long)length,
	   device[actualDeviceId].name, deviceId);
    /* Fix below courtesy of Andreas Pfaller <a.pfaller@pop.gun.de> */
    length = mtuSize[device[deviceId].datalink];
  }

  srcHost = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(srcHostIdx)];
  dstHost = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(dstHostIdx)];

  if((srcHost == NULL) || (dstHost == NULL))
    return;

  srcHost->pktSent++;

  if((dstHostIdx == broadcastEntryIdx) || broadcastHost(dstHost)) {
    srcHost->pktBroadcastSent++;
    srcHost->bytesBroadcastSent += length;
    device[actualDeviceId].broadcastPkts++;
  } else if(isMulticastAddress(&(dstHost->hostIpAddress))) {
#ifdef DEBUG
    printf("%s -> %s\n", srcHost->hostSymIpAddress, dstHost->hostSymIpAddress);
#endif
    srcHost->pktMulticastSent++;
    srcHost->bytesMulticastSent += length;
    dstHost->pktMulticastRcvd++;
    dstHost->bytesMulticastRcvd += length;
    device[actualDeviceId].multicastPkts++;
  }

  srcHost->bytesSent += length;
  if(dstHost != NULL) dstHost->bytesReceived += length;

  dstHost->pktReceived++;

  if(length < 64) device[actualDeviceId].rcvdPktStats.upTo64++;
  else if(length < 128) device[actualDeviceId].rcvdPktStats.upTo128++;
  else if(length < 256) device[actualDeviceId].rcvdPktStats.upTo256++;
  else if(length < 512) device[actualDeviceId].rcvdPktStats.upTo512++;
  else if(length < 1024) device[actualDeviceId].rcvdPktStats.upTo1024++;
  else if(length < 1518) device[actualDeviceId].rcvdPktStats.upTo1518++;
  else device[actualDeviceId].rcvdPktStats.above1518++;

  if((device[actualDeviceId].rcvdPktStats.shortest == 0)
     || (device[actualDeviceId].rcvdPktStats.shortest > length))
    device[actualDeviceId].rcvdPktStats.shortest = length;

  if(device[actualDeviceId].rcvdPktStats.longest < length)
    device[actualDeviceId].rcvdPktStats.longest = length;

  if((dstHost != NULL) /*&& (!broadcastHost(dstHost))*/)
    addContactedPeers(srcHostIdx, dstHostIdx);
}

/* ************************************ */

#ifdef MULTITHREADED

void queuePacket(u_char * _deviceId,
		 const struct pcap_pkthdr *h,
		 const u_char *p) {

  /****************************
   - If the queue is full then wait until a slot is freed
   - If the queue is getting full then periodically wait
     until a slot is freed
  *****************************/

#ifdef DEBUG
  printf("Got packet from %s (%d)\n", device[*_deviceId].name, *_deviceId);
#endif

#ifdef WIN32_DEMO
  static u_short numQueuedPackets=0;

  if(numQueuedPackets++ >= MAX_NUM_PACKETS)
    return;
#endif

  if(packetQueueLen >= PACKET_QUEUE_LENGTH) {
#ifdef DEBUG
    printf("Dropping packet!!! [packet queue=%d/max=%d]\n",
	   packetQueueLen, maxPacketQueueLen);
#endif
    device[actualDeviceId].droppedPackets++;

#ifdef HAVE_SCHED_H
    sched_yield(); /* Allow other threads (dequeue) to run */
#endif
    sleep(1);
  } else {
#ifdef DEBUG
    printf("About to queue packet... \n");
#endif
    accessMutex(&packetQueueMutex, "queuePacket");
    memcpy(&packetQueue[packetQueueHead].h, h, sizeof(struct pcap_pkthdr));
    memset(packetQueue[packetQueueHead].p, 0, DEFAULT_SNAPLEN);
    memcpy(packetQueue[packetQueueHead].p, p, h->caplen);
    packetQueue[packetQueueHead].deviceId = *_deviceId;
    packetQueueHead = (packetQueueHead+1) % PACKET_QUEUE_LENGTH;
    packetQueueLen++;
    if(packetQueueLen > maxPacketQueueLen)
      maxPacketQueueLen = packetQueueLen;
    releaseMutex(&packetQueueMutex);
#ifdef DEBUG
    printf("Queued packet... [packet queue=%d/max=%d]\n",
	   packetQueueLen, maxPacketQueueLen);
#endif

#ifdef DEBUG_THREADS
    printf("+ [packet queue=%d/max=%d]\n", packetQueueLen, maxPacketQueueLen);
#endif
  }

#ifdef USE_SEMAPHORES
    incrementSem(&queueSem);
#else
    signalCondvar(&queueCondvar);
#endif
#ifdef HAVE_SCHED_H
    sched_yield(); /* Allow other threads (dequeue) to run */
#endif
}

/* ************************************ */

void* dequeuePacket(void* notUsed) {
  PacketInformation pktInfo;

  while(1) {
#ifdef DEBUG
    printf("Waiting for packet...\n");
#endif

/* #ifdef WIN32 */
	while(packetQueueLen == 0)
/*  #endif */
	{
#ifdef USE_SEMAPHORES
	  waitSem(&queueSem);
#else
	  waitCondvar(&queueCondvar);
#endif
	}

#ifdef DEBUG
    printf("Got packet...\n");
#endif
    accessMutex(&packetQueueMutex, "dequeuePacket");
    memcpy(&pktInfo.h, &packetQueue[packetQueueTail].h,
	   sizeof(struct pcap_pkthdr));
    memcpy(pktInfo.p, packetQueue[packetQueueTail].p, DEFAULT_SNAPLEN);
    pktInfo.deviceId = packetQueue[packetQueueTail].deviceId;
    packetQueueTail = (packetQueueTail+1) % PACKET_QUEUE_LENGTH;
    packetQueueLen--;
    releaseMutex(&packetQueueMutex);
#ifdef DEBUG_THREADS
    printf("- [packet queue=%d/max=%d]\n", packetQueueLen, maxPacketQueueLen);
#endif

#ifdef DEBUG
    printf("Processing packet... [packet queue=%d/max=%d]\n",
	   packetQueueLen, maxPacketQueueLen);
#endif

    actTime = time(NULL);
    processPacket((u_char*)((long)pktInfo.deviceId), &pktInfo.h, pktInfo.p);
  }

  return(NULL); /* NOTREACHED */
}

#endif /* MULTITHREADED */


/* ************************************ */


void flowsProcess(const struct pcap_pkthdr *h, const u_char *p) {
  FlowFilterList *list = flowsList;

  while(list != NULL) {
    if((list->fcode[deviceId].bf_insns != NULL)
       && (bpf_filter(list->fcode[deviceId].bf_insns,
		      (u_char*)p, h->len, h->caplen))) {
      list->bytes += h->len;
      list->packets++;
      if(list->pluginPtr != NULL) {
	void(*pluginFunc)(const struct pcap_pkthdr *h, const u_char *p);

	pluginFunc = (void(*)(const struct pcap_pkthdr*,
			      const u_char*))list->pluginPtr->pluginFunc;
	pluginFunc(h, p);
#ifdef DEBUG
	printf("Match on %s for '%s'\n", device[deviceId].name,
	       list->flowName);
#endif
      }
    } else {
#ifdef DEBUG
      printf("No match on %s for '%s'\n", device[deviceId].name,
	     list->flowName);      
#endif
    }

    list = list->next;
  }
}

/* ************************************ */

/*
 * time stamp presentation formats
 */
#define DELTA_FMT      1   /* the time since receiving the previous packet */
#define ABS_FMT        2   /* the current time */
#define RELATIVE_FMT   3   /* the time relative to the first packet received */


struct timeval current_pkt = {0};
struct timeval first_pkt = {0};
struct timeval last_pkt = {0};



/*
 * The time difference in milliseconds.
 */
static time_t delta_time_in_milliseconds (struct timeval * now,
					  struct timeval * before)
{
  /*
   * compute delta in second, 1/10's and 1/1000's second units
   */
  time_t delta_seconds = now -> tv_sec - before -> tv_sec;
  time_t delta_milliseconds = (now -> tv_usec - before -> tv_usec) / 1000;

  if (delta_milliseconds < 0)
    { /* manually carry a one from the seconds field */
      delta_milliseconds += 1000; 		/* 1e3 */
      -- delta_seconds;
    }
  return ((delta_seconds * 1000) + delta_milliseconds);
}



/*
 * Return a well formatted timestamp.
 */
static char * timestamp (const struct timeval * t, int fmt)
{
  static char buf [16] = {0};

  time_t now = time ((time_t *) 0);
  struct tm * tm = localtime (& now);

  gettimeofday (& current_pkt, NULL);

  switch (fmt)
    {
    default:
    case DELTA_FMT:
      /*
       * calculate the difference in milliseconds since the previous packet was displayed
       */
      sprintf (buf, "%10ld ms", delta_time_in_milliseconds (& current_pkt, & last_pkt));
      break;

    case ABS_FMT:
      sprintf (buf, "%02d:%02d:%02d.%06d",
	       tm -> tm_hour, tm -> tm_min, tm -> tm_sec, (int) t -> tv_usec);
      break;

    case RELATIVE_FMT:
      /*
       * calculate the difference in milliseconds since the previous packet was displayed
       */
      sprintf (buf, "%10ld ms", delta_time_in_milliseconds (& current_pkt, & first_pkt));
      break;
    }

  return (buf);
}



/*
 * This is the top level routine of the printer.  'p' is the points
 * to the ether header of the packet, 'tvp' is the timestamp,
 * 'length' is the length of the packet off the wire, and 'caplen'
 * is the number of bytes actually captured.
 */

void processPacket(u_char *_deviceId,
		   const struct pcap_pkthdr *h,
		   const u_char *p)
{
  struct ether_header *ep, ehdr;
  struct tokenRing_header *trp;
  struct fddi_header *fddip;
  u_int hlen, caplen = h->caplen;
  u_int headerDisplacement = 0, length = h->len;
  const u_char *orig_p = p;
  u_char *ether_src=NULL, *ether_dst=NULL;
  unsigned short eth_type=0;
  /* Token-Ring Strings */
  struct tokenRing_llc *trllc;

  FILE * fd;

  /*
    static long numPkt=0; printf("%ld (%ld)\n", numPkt++, length);
  */

  if(rFileName != NULL) {
    printf(".");
    fflush(stdout);
  }

  actTime = time(NULL);

#ifdef WIN32
  deviceId = 0;
#else
  deviceId = (int)_deviceId;
#endif

  actualDeviceId = getActualInterface();

#ifdef DEBUG
  printf("actualDeviceId = %d\n", actualDeviceId);
#endif

  hlen = (device[deviceId].datalink == DLT_NULL) ? NULL_HDRLEN : sizeof(struct ether_header);

#ifdef MULTITHREADED
  accessMutex(&hostsHashMutex, "processPacket");
#endif

  /*
   * Let's check whether it's time to free up
   * some space before to continue....
   */
  if(device[actualDeviceId].hostsno > topHashThreshold)
    purgeIdleHosts(0 /* Delete only idle hosts */);

  memcpy(&lastPktTime, &h->ts, sizeof(lastPktTime));

  fd = device [deviceId] . fdv;

  /*
   * Show a hash character for each packet captured
   */
  if (fd && device [deviceId] . hashing)
    {
      fprintf (fd, "#");
      fflush(fd);
    }

  /* ethernet assumed */
  if (caplen >= hlen) {
    HostTraffic *srcHost=NULL, *dstHost=NULL;
    u_int srcHostIdx, dstHostIdx;

    ep = (struct ether_header *)p;

    switch(device[deviceId].datalink) {
    case DLT_FDDI:
      fddip = (struct fddi_header *)p;
      length -= FDDI_HDRLEN;
      p += FDDI_HDRLEN;
      caplen -= FDDI_HDRLEN;

      extract_fddi_addrs(fddip, (char *)ESRC(&ehdr), (char *)EDST(&ehdr));
      ether_src = (u_char*)ESRC(&ehdr), ether_dst = (u_char*)EDST(&ehdr);

      if ((fddip->fc & FDDIFC_CLFF) == FDDIFC_LLC_ASYNC) {
	struct llc llc;

	memcpy((char *)&llc, (char *)p, min(caplen, sizeof(llc)));
	if (llc.ssap == LLCSAP_SNAP && llc.dsap == LLCSAP_SNAP
	    && llc.llcui == LLC_UI) {
	  if (caplen >= sizeof(llc)) {
	    caplen -= sizeof(llc);
	    length -= sizeof(llc);
	    p += sizeof(llc);

	    if(EXTRACT_16BITS(&llc.ethertype[0]) == ETHERTYPE_IP) {
	      /* encapsulated IP packet */
	      processIpPkt(p, length, ether_src, ether_dst);
	      return;
	    }
	  }
	}
      }
      break;

    case DLT_NULL: /* loopaback interface */
      /*
	 Support for ethernet headerless interfaces (e.g. lo0)
	 Courtesy of Martin Kammerhofer <dada@sbox.tu-graz.ac.at>
      */

      length -= NULL_HDRLEN; /* don't count nullhdr */

      /* All this crap is due to the old little/big endian story... */
      if((p[0] == 0) && (p[1] == 0) && (p[2] == 8) && (p[3] == 0)) {
	eth_type = ETHERTYPE_IP;
	ether_src = ether_dst = dummyEthAddress;
      }
      break;
    case DLT_PPP:
      headerDisplacement = PPP_HDRLEN;
      /*
	PPP is like RAW IP. The only difference is that PPP
	has a header that's not present in RAW IP.

	IMPORTANT: DO NOT PUT A break BELOW this comment
      */
    case DLT_RAW: /* RAW IP (no ethernet header) */
      length -= headerDisplacement; /* don't count PPP header */
      ether_src = ether_dst = NULL;
      processIpPkt(p+headerDisplacement, length, NULL, NULL);
      break;

    case DLT_IEEE802: /* Token Ring */
      trp = (struct tokenRing_header*)p;
      ether_src = (u_char*)trp->trn_shost, ether_dst = (u_char*)trp->trn_dhost;

      hlen = sizeof(struct tokenRing_header) - 18;

      if (trp->trn_shost[0] & TR_RII) /* Source Routed Packet */
	hlen += ((ntohs(trp->trn_rcf) & TR_RCF_LEN_MASK) >> 8);

      length -= hlen, caplen -= hlen;

      p += hlen;
      trllc = (struct tokenRing_llc *)p;

      if (trllc->dsap == 0xAA && trllc->ssap == 0xAA)
	hlen = sizeof(struct tokenRing_llc);
      else
	hlen = sizeof(struct tokenRing_llc) - 5;

      length -= hlen, caplen -= hlen;

      p += hlen;

      if (hlen == sizeof(struct tokenRing_llc))
	eth_type = ntohs(trllc->ethType);
      else
	eth_type = 0;
      break;
    default:
      eth_type = ntohs(ep->ether_type);
      ether_src = ESRC(ep), ether_dst = EDST(ep);
    } /* switch(device[deviceId].datalink) */


#if (0)
    /*
     * Time to show the Ethernet Packet Header (when enabled).
     */
    if (fd && device [deviceId] . ethv)
      fprintf (fd, "ETHER:  ----- Ether Header -----\n"),
	fprintf (fd, "ETHER:\n"),
	fprintf (fd, "ETHER:  Packet %ld arrived at %s\n",
		 device [actualDeviceId] . ethernetPkts, timestamp (& h -> ts, ABS_FMT)),
	fprintf (fd, "ETHER:  Total size  = %d : header = %d : data = %d\n",
		 length, hlen, length - hlen),
	fprintf (fd, "ETHER:  Source      = %s\n", etheraddr_string (ether_src)),
	fprintf (fd, "ETHER:  Destination = %s\n", etheraddr_string (ether_dst));
    fflush (fd);
#endif


    if((device[deviceId].datalink != DLT_PPP) && (device[deviceId].datalink != DLT_RAW)) {
      if((device[deviceId].datalink == DLT_IEEE802) && (eth_type < ETHERMTU)) {
	trp = (struct tokenRing_header*)orig_p;
	ether_src = (u_char*)trp->trn_shost, ether_dst = (u_char*)trp->trn_dhost;
	srcHostIdx = getHostInfo(NULL, ether_src);
	srcHost = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(srcHostIdx)];
	if(srcHost == NULL) {
	  /* Sanity check */
	  printf("Sanity check failed (3)\n");
	} else {
	  /* Lock the instance so that the next call
	     to getHostInfo won't purge it */
	  srcHost->instanceInUse++;
	}

	dstHostIdx = getHostInfo(NULL, ether_dst);
	dstHost = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(dstHostIdx)];
	if(dstHost == NULL) {
	  /* Sanity check */
	  printf("Sanity check failed (4)\n");
	} else {
	  /* Lock the instance so that the next call
	     to getHostInfo won't purge it */
	  dstHost->instanceInUse++;
	}

	srcHost->otherSent += length;
	dstHost->otherReceived += length;
	updatePacketCount(srcHostIdx, dstHostIdx, (TrafficCounter)length);
      } else if((device[deviceId].datalink != DLT_IEEE802) 
		&& (eth_type <= ETHERMTU) && (length > 3)) {
	  /* The code below has been taken from tcpdump */
	  u_char *p1, sap_type;
	  struct llc llcHeader;

	  srcHostIdx = getHostInfo(NULL, ether_src);
	  dstHostIdx = getHostInfo(NULL, ether_dst);
	  srcHost = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(srcHostIdx)];
	  dstHost = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(dstHostIdx)];

	  p1 = (u_char*)(p+hlen);

	  /* Watch out for possible alignment problems */
	  memcpy(&llcHeader, (char*)p1, min(length, sizeof(llcHeader)));

	  sap_type = llcHeader.ssap & ~LLC_GSAP;
	  llcsap_string(sap_type);

	  if ((llcHeader.ssap == LLCSAP_GLOBAL && llcHeader.dsap == LLCSAP_GLOBAL)
	      || (sap_type == 0xE0)
	      || (sap_type == 0x42)) {
	    /* IPX */
	    unsigned char ipxBuffer[128];

	    /* IPX packet beginning */

	    if(length > 128)
	      memcpy(ipxBuffer, p1+3, 128);
	    else
	      memcpy(ipxBuffer, p1+3, length);
	    
	    if((ipxBuffer[16] == 0x04)    /* SAP (Service Advertising Protocol) (byte 0) */
	       && (ipxBuffer[17] == 0x52) /* SAP (Service Advertising Protocol) (byte 1) */
	       && (ipxBuffer[30] == 0x0)  /* SAP Response (byte 0) */
	       && (ipxBuffer[31] == 0x02) /* SAP Response (byte 1) */) {   
	      u_int16_t serverType;
	      char serverName[56];
	      int i;
	      
	      memcpy(&serverType, &ipxBuffer[32], 2);

	      serverType = ntohs(serverType);

	      memcpy(serverName, &ipxBuffer[34], 56); serverName[56] = '\0';
	      for(i=0; i<56; i++)
		if(serverName[i] == '!') {
		  serverName[i] = '\0';
		  break;
		}

	      srcHost->ipxNodeType = serverType;
	      if(srcHost->ipxHostName == NULL) {
		srcHost->ipxHostName = strdup(serverName);
	      }
#ifdef DEBUG
	      printf("%s [%s][%x]\n", serverName, getSAPInfo(serverType, 0), serverType);	  
#endif
	    }

	    srcHost->ipxSent += length;
	    dstHost->ipxReceived += length;
	    device[actualDeviceId].ipxBytes += length;
	  } else if (llcHeader.ssap == LLCSAP_NETBIOS
		     && llcHeader.dsap == LLCSAP_NETBIOS) {
	    /* Netbios */
	    srcHost->netbiosSent += length;
	    dstHost->netbiosReceived += length;
	    device[actualDeviceId].netbiosBytes += length;
	  } else if ((sap_type == 0xF0) || (sap_type == 0xB4)
		     || (sap_type == 0xC4) || (sap_type == 0xF8)) {
	    /* DLC (protocol used for printers) */
	    srcHost->dlcSent += length;
	    dstHost->dlcReceived += length;
	    device[actualDeviceId].dlcBytes += length;
	  } else if (sap_type == 0xAA) {  /* Appletalk */
	    AtDDPheader ddpHeader;

	    p1 = (u_char*)(p1+sizeof(llcHeader));
	    memcpy(&ddpHeader, (char*)p1, sizeof(AtDDPheader));

	    srcHost->atNetwork = ntohs(ddpHeader.srcNet), srcHost->atNode = ddpHeader.srcNode;
	    dstHost->atNetwork = ntohs(ddpHeader.dstNet), dstHost->atNode = ddpHeader.dstNode;

	    if(ddpHeader.ddpType == 2) { /* Appletalk NBP */
	      
	      AtNBPheader nbpHeader;
	      int numTuples;

	      p1 = (u_char*)(p1+13);
	      memcpy(&nbpHeader, (char*)p1, sizeof(AtNBPheader));
	      numTuples = nbpHeader.function & 0x0F;
	      
	      if((nbpHeader.function == 0x31) && (numTuples == 1)) {
		char nodeName[256];

		p1 = (u_char*)(p1+2);

		memcpy(nodeName, &p1[6], p1[5]);
		nodeName[p1[5]] = '\0';
		
		srcHost->atNodeName = strdup(nodeName);
	      }
	    }

	    srcHost->appletalkSent += length;
	    dstHost->appletalkReceived += length;
	    device[actualDeviceId].atalkBytes += length;
	  } else if ((sap_type == 0x06)
		     || (sap_type == 0xFE)
		     || (sap_type == 0xFC)) {  /* OSI */
	    srcHost->osiSent += length;
	    dstHost->osiReceived += length;
	    device[actualDeviceId].osiBytes += length;
	  } else {
	    /* Unknown Protocol */
#ifdef PRINT_UNKNOWN_PACKETS
	    printf("[%u] [%x] %s %s > %s\n", (u_short)sap_type,(u_short)sap_type,
		   etheraddr_string(ether_src),
		   llcsap_string(llcHeader.ssap & ~LLC_GSAP),
		   etheraddr_string(ether_dst));
#endif
	    srcHost->otherSent += length;
	    dstHost->otherReceived += length;
	    device[actualDeviceId].otherBytes += length;
	  }

	  updatePacketCount(srcHostIdx, dstHostIdx, (TrafficCounter)length);
	} else if(eth_type == ETHERTYPE_IP) {
	  if((device[deviceId].datalink == DLT_IEEE802) && (eth_type > ETHERMTU))
	    processIpPkt(p, length, ether_src, ether_dst);
	  else
	    processIpPkt(p+hlen, length, ether_src, ether_dst);
	} else { /* Non IP */
	  struct ether_arp arpHdr;
	  struct in_addr addr;

	  srcHostIdx = getHostInfo(NULL, ether_src);
	  srcHost = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(srcHostIdx)];
	  if(srcHost == NULL) {
	    /* Sanity check */
	    printf("Sanity check failed (5)\n");
	  } else {
	    /* Lock the instance so that the next call
	       to getHostInfo won't purge it */
	    srcHost->instanceInUse++;
	  }

	  dstHostIdx = getHostInfo(NULL, ether_dst);
	  dstHost = device[actualDeviceId].hash_hostTraffic[checkSessionIdx(dstHostIdx)];
	  if(dstHost == NULL) {
	    /* Sanity check */
	    printf("Sanity check failed (6)\n");
	  } else {
	    /* Lock the instance so that the next call
	       to getHostInfo won't purge it */
	    dstHost->instanceInUse++;
	  }

	  if(length > hlen)
	    length -= hlen;
	  else
	    length = 0;

	  switch(eth_type) {
	   case ETHERTYPE_ARP: /* ARP - Address resolution Protocol */
	     memcpy(&arpHdr, p+hlen, sizeof(arpHdr));

	     if (EXTRACT_16BITS(&arpHdr.arp_pro) == ETHERTYPE_IP) {
	       switch (EXTRACT_16BITS(&arpHdr.arp_op)) {
	       case ARPOP_REQUEST: /* ARP request */
		 /* 13:29:22.700000 arp who-has 131.114.20.8 tell 131.114.20.3 (0:a:27:a9:57:bc) */
		 if(srcHost->hostNumIpAddress[0] == 0) {
		   /* The IP address of the sending host is unknown. Thanks
		      to ARP, now we know it */
		   memcpy(&addr.s_addr, arpHdr.arp_spa, sizeof(addr.s_addr));
		   addr.s_addr = ntohl(addr.s_addr);
		   srcHost->hostIpAddress.s_addr = addr.s_addr;
		   strcpy(srcHost->hostNumIpAddress, intoa(addr));
		   if(numericFlag == 0)
		     srcHost->hostSymIpAddress = ipaddr2str(srcHost->hostIpAddress);
		 }
		 break;

	       case ARPOP_REPLY: /* ARP REPLY */
		 if(srcHost->hostNumIpAddress[0] == 0) {
		   /* The IP address of the sending host is unknown. Thanks
		      to ARP, now we know it */
		   memcpy(&addr.s_addr, arpHdr.arp_spa, sizeof(addr.s_addr));
		   addr.s_addr = ntohl(addr.s_addr);
		   srcHost->hostIpAddress.s_addr = addr.s_addr;
		   strcpy(srcHost->hostNumIpAddress, intoa(addr));
		   if(numericFlag == 0)
		     srcHost->hostSymIpAddress = ipaddr2str(srcHost->hostIpAddress);
		 }
		break;

	       }
	     }
	    /* DO NOT ADD A break ABOVE ! */
	  case ETHERTYPE_REVARP: /* Reverse ARP */
	    srcHost->arp_rarpSent += length;
	    dstHost->arp_rarpReceived += length;
	    device[actualDeviceId].arpRarpBytes += length;
	    break;
	  case ETHERTYPE_DN: /* Decnet */
	    srcHost->decnetSent += length;
	    dstHost->decnetReceived += length;
	    device[actualDeviceId].decnetBytes += length;
	    break;
	  case ETHERTYPE_ATALK: /* AppleTalk */
	  case ETHERTYPE_AARP:
	    srcHost->appletalkSent += length;
	    dstHost->appletalkReceived += length;
	    device[actualDeviceId].atalkBytes += length;
	    break;
          case ETHERTYPE_QNX:
            srcHost->qnxSent += length;
            dstHost->qnxReceived += length;
            device[actualDeviceId].qnxBytes += length;
            break;
	  default:
#ifdef PRINT_UNKNOWN_PACKETS
	    printf("%s/%s->%s/%s [eth type %d (0x%x)]\n",
		   srcHost->hostNumIpAddress, srcHost->ethAddressString,
		   dstHost->hostNumIpAddress, dstHost->ethAddressString,
		   eth_type, eth_type);
#endif
	    srcHost->otherSent += length;
	    dstHost->otherReceived += length;
	    device[actualDeviceId].otherBytes += length;
	    break;
	  }

	  updatePacketCount(srcHostIdx, dstHostIdx, (TrafficCounter)length);
	}
    }

    /* Unlock the instances */
    if(srcHost != NULL) srcHost->instanceInUse--;
    if(dstHost != NULL) dstHost->instanceInUse--;
  }

  device[actualDeviceId].ethernetPkts++;
  device[actualDeviceId].ethernetBytes += h->len;

  if(flowsList != NULL) /* Handle flows last */
    flowsProcess(h, p);

#ifdef MULTITHREADED
  releaseMutex(&hostsHashMutex);
#endif
}

/* ************************************ */

void updateOSName(HostTraffic *el) {
#ifdef HAVE_GDBM_H
  datum key_data, data_data;
#endif

  if(el->osName == NULL) {
    char *theName = NULL, tmpBuf[64];

    if(el->hostNumIpAddress[0] == '\0') {
      el->osName = strdup("");
      return;
    }

#ifdef DEBUG
    printf("updateOSName(%s)\n", el->hostNumIpAddress);
#endif

#ifdef HAVE_GDBM_H
    sprintf(tmpBuf, "@%s", el->hostNumIpAddress);
    key_data.dptr = tmpBuf;
    key_data.dsize = strlen(tmpBuf)+1;

#ifdef MULTITHREADED
    accessMutex(&gdbmMutex, "updateOSName");
#endif

    data_data = gdbm_fetch(gdbm_file, key_data);

#ifdef MULTITHREADED
    releaseMutex(&gdbmMutex);
#endif

    if(data_data.dptr != NULL) {
      strcpy(tmpBuf, data_data.dptr);
      free(data_data.dptr);
      theName = tmpBuf;
    }
#endif /* HAVE_GDBM_H */

    if((theName == NULL)
       && (subnetPseudoLocalHost(el)) /* Courtesy of Jan Johansson <j2@mupp.net> */
       ) 
      theName = getHostOS(el->hostNumIpAddress, -1, NULL);

    if(theName == NULL)
      el->osName = strdup("");
    else {
      el->osName = strdup(theName);

      updateDBOSname(el);

#ifdef HAVE_GDBM_H
      sprintf(tmpBuf, "@%s", el->hostNumIpAddress);
      key_data.dptr = tmpBuf;
      key_data.dsize = strlen(tmpBuf)+1;
      data_data.dptr = el->osName;
      data_data.dsize = strlen(el->osName)+1;

      if(gdbm_store(gdbm_file, key_data, data_data, GDBM_REPLACE) != 0)
	printf("Error while adding osName for '%s'\n.\n", el->hostNumIpAddress);
      else {
#ifdef GDBM_DEBUG
	printf("Added data: %s [%s]\n", tmpBuf, el->osName);
#endif
      }
#endif /* HAVE_GDBM_H */
    }
  }
}

