/*
 *  Copyright (C) 1998-2000 Luca Deri <deri@ntop.org>
 *                      
 *  			  Centro SERRA, University of Pisa
 *  			  http://www.ntop.org/
 *  					
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "ntop.h"
#include "globals-report.h"

extern int GDC_yaxis; 
extern char* GDC_ylabel_fmt;

extern int out_graph(short gifwidth,
		     short gifheight,  
		     FILE  *gif_fptr,
		     GDC_CHART_T type,
		     int  num_points,
		     char *xlbl[],
		     int  num_sets,
		     ... );



typedef struct icmpData {
  struct icmp icmpPkt;
  char dummy_data[16];
} IcmpData;

typedef struct icmpPktInfo {
  time_t         pktTime;
  struct in_addr sourceHost;
  struct in_addr destHost;
  IcmpData       icmpData;
} IcmpPktInfo;

typedef struct icmpHostInfo {
  unsigned long icmpMsgSent[ICMP_MAXTYPE+1];
  unsigned long icmpMsgRcvd[ICMP_MAXTYPE+1];
  struct in_addr hostIpAddress;
  time_t         lastUpdated;
  HostTraffic* host;
} IcmpHostInfo;

IcmpHostInfo *icmpHostsTable[HASHNAMESIZE];

static time_t garbageTime;

#define ICMP_LIST_MAX_LEN  128
static IcmpPktInfo  icmpHostsList[ICMP_LIST_MAX_LEN+2];
static unsigned int icmpListEntries;

static void runICMPgarbageCollector();

/* ****************************** */

static GDBM_FILE icmpDB;
static int icmpColumnSort = 0, numIcmpEntries=0;

struct tok {
  int v;    /* value  */
  char *s;  /* string */
};

/* Formats for most of the ICMP_UNREACH codes */
static struct tok unreach2str[] = {
  { ICMP_UNREACH_NET,		"net %s unreachable" },
  { ICMP_UNREACH_HOST,		"host %s unreachable" },
  { ICMP_UNREACH_SRCFAIL,
    "%s unreachable - source route failed" },
  { ICMP_UNREACH_NET_UNKNOWN,	"net %s unreachable - unknown" },
  { ICMP_UNREACH_HOST_UNKNOWN,	"host %s unreachable - unknown" },
  { ICMP_UNREACH_ISOLATED,
    "%s unreachable - source host isolated" },
  { ICMP_UNREACH_NET_PROHIB,
    "net %s unreachable - admin prohibited" },
  { ICMP_UNREACH_HOST_PROHIB,
    "host %s unreachable - admin prohibited" },
  { ICMP_UNREACH_TOSNET,
    "net %s unreachable - tos prohibited" },
  { ICMP_UNREACH_TOSHOST,
    "host %s unreachable - tos prohibited" },
  { ICMP_UNREACH_FILTER_PROHIB,
    "host %s unreachable - admin prohibited filter" },
  { ICMP_UNREACH_HOST_PRECEDENCE,
    "host %s unreachable - host precedence violation" },
  { ICMP_UNREACH_PRECEDENCE_CUTOFF,
    "host %s unreachable - precedence cutoff" },
  { 0,				NULL }
};

/* Formats for the ICMP_REDIRECT codes */
static struct tok type2str[] = {
	{ ICMP_REDIRECT_NET,		"redirect %s to net %s" },
	{ ICMP_REDIRECT_HOST,		"redirect %s to host %s" },
	{ ICMP_REDIRECT_TOSNET,		"redirect-tos %s to net %s" },
	{ ICMP_REDIRECT_TOSHOST,	"redirect-tos %s to net %s" },
	{ 0,				NULL }
};

/* rfc1191 */
struct mtu_discovery {
	short unused;
	short nexthopmtu;
};

/* rfc1256 */
struct ih_rdiscovery {
	u_char ird_addrnum;
	u_char ird_addrsiz;
	u_short ird_lifetime;
};

struct id_rdiscovery {
	u_int32_t ird_addr;
	u_int32_t ird_pref;
};

static char *tok2str(register const struct tok *lp, register const char *fmt,
		     register int v)
{
  static char buf[128];
  
  while (lp->s != NULL) {
    if (lp->v == v)
      return (lp->s);
    ++lp;
  }
  if (fmt == NULL)
    fmt = "#%d";
  (void)sprintf(buf, fmt, v);
  return (buf);
}

/* *********************************** */

static int getIcmpHostInfo(struct in_addr hostIpAddress) {
  u_int i, idx, found=0;

  idx = hostIpAddress.s_addr%actualHashSize;
  for(i=0; i<actualHashSize; i++) {
    if(icmpHostsTable[idx] != NULL) {
      if(icmpHostsTable[idx]->hostIpAddress.s_addr == hostIpAddress.s_addr) {
	found = 1;
	break;
      } else {
	idx = (idx+1)%actualHashSize;
      }
    } else {
      found = 1;
      break;
    }
  }
  
  if(!found) {
    /* Garbage collector */
    idx = 0;

    for(i=0; i<actualHashSize; i++)
      if(icmpHostsTable[i]->lastUpdated <  icmpHostsTable[idx]->lastUpdated) {
	idx = i;	
      }

    memset(icmpHostsTable[idx], 0, sizeof(IcmpHostInfo));
    icmpHostsTable[idx]->lastUpdated = actTime;
    icmpHostsTable[idx]->hostIpAddress = hostIpAddress;
  } else {
    if(icmpHostsTable[idx] == NULL) {
      /* New entry */
      numIcmpEntries++;
      icmpHostsTable[idx] = malloc(sizeof(IcmpHostInfo));
      memset(icmpHostsTable[idx], 0, sizeof(IcmpHostInfo));
      icmpHostsTable[idx]->lastUpdated = actTime;
      icmpHostsTable[idx]->hostIpAddress = hostIpAddress;
    }
  }


  return(idx);
}

/* ***************************** */

static void handleIcmpPacket(const struct pcap_pkthdr *h, const u_char *p) {
  IcmpData icmpData;
  struct ip ip;
  u_int hlen, off;
  int src_idx, dst_idx;
  datum key_data, data_data;
  char tmpStr[32];
  IcmpPktInfo pktInfo;
 
  memcpy(&ip, (p+headerSize[device[deviceId].datalink]), sizeof(struct ip));
  hlen = (u_int)ip.ip_hl * 4;
  
  off = ntohs(ip.ip_off);

  if((off & 0x3fff) && (off & IP_MF)) {
    /*
      ntop skips ICMP fragments other than the main one.
      This is not a problem since fragments do not have
      to be counted.
    */
#ifdef DEBUG
    printf("Skipping fragment \n");
#endif
    return;
  } 
  memcpy(&icmpData, (p+headerSize[device[deviceId].datalink]+hlen), sizeof(IcmpData)); 

  if(icmpData.icmpPkt.icmp_type>ICMP_MAXTYPE) return;

  NTOHL(ip.ip_src.s_addr);
  NTOHL(ip.ip_dst.s_addr);

  runICMPgarbageCollector();

  src_idx = getIcmpHostInfo(ip.ip_src);     
  dst_idx = getIcmpHostInfo(ip.ip_dst);

#ifdef DEBUG
  printf("%d [%d@%d-%d@%d]\n", icmpData.icmpPkt.icmp_type,
	 icmpHostsTable[src_idx]->icmpMsgSent[icmpData.icmpPkt.icmp_type], src_idx,
	 icmpHostsTable[dst_idx]->icmpMsgRcvd[icmpData.icmpPkt.icmp_type], dst_idx);
#endif
  (icmpHostsTable[src_idx]->icmpMsgSent[icmpData.icmpPkt.icmp_type])++;
  (icmpHostsTable[dst_idx]->icmpMsgRcvd[icmpData.icmpPkt.icmp_type])++;      

  switch (icmpData.icmpPkt.icmp_type) {
    case ICMP_ECHOREPLY:
    case ICMP_ECHO:
      /* Do not log anything */
      break;
      
    case ICMP_UNREACH:
    case ICMP_REDIRECT:
    case ICMP_ROUTERADVERT:
    case ICMP_TIMXCEED:
    case ICMP_PARAMPROB:
    case ICMP_MASKREPLY:
    case ICMP_MASKREQ:
    case ICMP_INFO_REQUEST:
    case ICMP_INFO_REPLY:
    case ICMP_TIMESTAMP:
    case ICMP_TIMESTAMPREPLY:
    case ICMP_SOURCE_QUENCH:
      sprintf(tmpStr, "%lu/%lu", 
	      (unsigned long)h->ts.tv_sec,
	      (unsigned long)h->ts.tv_usec);
      key_data.dptr = tmpStr; key_data.dsize = strlen(key_data.dptr)+1;
      pktInfo.pktTime = h->ts.tv_sec;
      pktInfo.sourceHost.s_addr = ip.ip_src.s_addr;
      pktInfo.destHost.s_addr = ip.ip_dst.s_addr;
      memcpy(&pktInfo.icmpData, &icmpData, sizeof(IcmpData));
      data_data.dptr = (char*)&pktInfo; data_data.dsize = sizeof(IcmpPktInfo)+1;

#ifdef DEBUG
      if(icmpData.icmpPkt.icmp_type == 5)
	printf("Adding %u/%u [%d] @ %s\n", 
	       pktInfo.sourceHost.s_addr, pktInfo.destHost.s_addr,
	       pktInfo.icmpData.icmpPkt.icmp_type, tmpStr); 
#endif

#ifdef MULTITHREADED
      accessMutex(&gdbmMutex, "sortICMPhosts");
#endif 
      gdbm_store(icmpDB, key_data, data_data, GDBM_REPLACE);	
#ifdef MULTITHREADED
      releaseMutex(&gdbmMutex);
#endif 
      break;
    }
 

  /* Note: ipaddr2str uses the gdbm semaphore !!! */
}


/* ****************************** */

static int sortICMPhosts(const void *_a, const void *_b) {
  IcmpHostInfo **a = (IcmpHostInfo **)_a;
  IcmpHostInfo **b = (IcmpHostInfo **)_b;
  unsigned long n1, n2;
  int rc;

  if(((*a) == NULL) && ((*b) != NULL)) {
    printf("WARNING (1)\n");
    return(1);
  } else if(((*a) != NULL) && ((*b) == NULL)) {
    printf("WARNING (2)\n");
    return(-1);
  } else if(((*a) == NULL) && ((*b) == NULL)) {
    printf("WARNING (3)\n");
    return(0);
  }
  
  switch(icmpColumnSort) {
  case 2:
    n1 = (*a)->icmpMsgSent[ICMP_ECHO] + (*a)->icmpMsgSent[ICMP_ECHOREPLY] +
      (*a)->icmpMsgRcvd[ICMP_ECHO]+(*a)->icmpMsgRcvd[ICMP_ECHOREPLY];
    n2 = (*b)->icmpMsgSent[ICMP_ECHO] + (*b)->icmpMsgSent[ICMP_ECHOREPLY] + 
      (*b)->icmpMsgRcvd[ICMP_ECHO]+ (*b)->icmpMsgRcvd[ICMP_ECHOREPLY];
    if(n1 > n2) return(1); else if(n1 < n2) return(-1); else return(0);
    break;

  case 3:
    n1 = (*a)->icmpMsgSent[ICMP_UNREACH] + (*a)->icmpMsgRcvd[ICMP_UNREACH];
    n2 = (*b)->icmpMsgSent[ICMP_UNREACH] + (*b)->icmpMsgRcvd[ICMP_UNREACH];
    if(n1 > n2) return(1); else if(n1 < n2) return(-1); else return(0);
    break;

  case 4:
    n1 = (*a)->icmpMsgSent[ICMP_REDIRECT] + (*a)->icmpMsgRcvd[ICMP_REDIRECT];
    n2 = (*b)->icmpMsgSent[ICMP_REDIRECT] + (*b)->icmpMsgRcvd[ICMP_REDIRECT];
    if(n1 > n2) return(1); else if(n1 < n2) return(-1); else return(0);
    break;

  case 5:
    n1 = (*a)->icmpMsgSent[ICMP_ROUTERADVERT] + (*a)->icmpMsgRcvd[ICMP_ROUTERADVERT];
    n2 = (*b)->icmpMsgSent[ICMP_ROUTERADVERT] + (*b)->icmpMsgRcvd[ICMP_ROUTERADVERT];
    if(n1 > n2) return(1); else if(n1 < n2) return(-1); else return(0);
    break;

  case 6:
    n1 = (*a)->icmpMsgSent[ICMP_TIMXCEED] + (*a)->icmpMsgRcvd[ICMP_TIMXCEED];
    n2 = (*b)->icmpMsgSent[ICMP_TIMXCEED] + (*b)->icmpMsgRcvd[ICMP_TIMXCEED];
    if(n1 > n2) return(1); else if(n1 < n2) return(-1); else return(0);
    break;

  case 7:
    n1 = (*a)->icmpMsgSent[ICMP_PARAMPROB] + (*a)->icmpMsgRcvd[ICMP_PARAMPROB];
    n2 = (*b)->icmpMsgSent[ICMP_PARAMPROB] + (*b)->icmpMsgRcvd[ICMP_PARAMPROB];
    if(n1 > n2) return(1); else if(n1 < n2) return(-1); else return(0);
    break;

  case 8:
    n1 = (*a)->icmpMsgSent[ICMP_MASKREQ] + (*a)->icmpMsgSent[ICMP_MASKREPLY] + 
      (*a)->icmpMsgRcvd[ICMP_MASKREQ]+ (*a)->icmpMsgRcvd[ICMP_MASKREPLY];
    n2 = (*b)->icmpMsgSent[ICMP_MASKREQ] + (*b)->icmpMsgSent[ICMP_MASKREPLY] + 
      (*b)->icmpMsgRcvd[ICMP_MASKREQ]+ (*b)->icmpMsgRcvd[ICMP_MASKREPLY];
    if(n1 > n2) return(1); else if(n1 < n2) return(-1); else return(0);
    break;


  case 9:
    n1 = (*a)->icmpMsgSent[ICMP_SOURCE_QUENCH] + (*a)->icmpMsgRcvd[ICMP_SOURCE_QUENCH];
    n2 = (*b)->icmpMsgSent[ICMP_SOURCE_QUENCH] + (*b)->icmpMsgRcvd[ICMP_SOURCE_QUENCH];
    if(n1 > n2) return(1); else if(n1 < n2) return(-1); else return(0);
    break;

  case 10:
    n1 = (*a)->icmpMsgSent[ICMP_TIMESTAMP] + (*a)->icmpMsgSent[ICMP_TIMESTAMPREPLY] + 
      (*a)->icmpMsgRcvd[ICMP_TIMESTAMP]+ (*a)->icmpMsgRcvd[ICMP_TIMESTAMPREPLY];
    n2 = (*b)->icmpMsgSent[ICMP_TIMESTAMP] + (*b)->icmpMsgSent[ICMP_TIMESTAMPREPLY] +
      (*b)->icmpMsgRcvd[ICMP_TIMESTAMP]+ (*b)->icmpMsgRcvd[ICMP_TIMESTAMPREPLY];
    if(n1 > n2) return(1); else if(n1 < n2) return(-1); else return(0);
    break;

  case 11:
    n1 = (*a)->icmpMsgSent[ICMP_INFO_REQUEST] + (*a)->icmpMsgSent[ICMP_INFO_REPLY] +
      (*a)->icmpMsgRcvd[ICMP_INFO_REQUEST]+ (*a)->icmpMsgRcvd[ICMP_INFO_REPLY];
    n2 = (*b)->icmpMsgSent[ICMP_INFO_REQUEST] + (*b)->icmpMsgSent[ICMP_INFO_REPLY] +
      (*b)->icmpMsgRcvd[ICMP_INFO_REQUEST]+ (*b)->icmpMsgRcvd[ICMP_INFO_REPLY];
    if(n1 > n2) return(1); else if(n1 < n2) return(-1); else return(0);
    break;

  default:
#ifdef MULTITHREADED
    accessMutex(&addressResolutionMutex, "addressResolution");
#endif 

    if((*a)->host->hostSymIpAddress == NULL) 
      (*a)->host->hostSymIpAddress = (*a)->host->hostNumIpAddress;
    if((*b)->host->hostSymIpAddress == NULL) 
      (*b)->host->hostSymIpAddress = (*b)->host->hostNumIpAddress;		

    rc = strcasecmp((*a)->host->hostSymIpAddress, (*b)->host->hostSymIpAddress);

#ifdef MULTITHREADED
    releaseMutex(&addressResolutionMutex);
#endif 
    return(rc);
    break;
  }
}

/* ******************************* */

static void insertICMPPkt(IcmpPktInfo *icmpPktInfo) {
  if(icmpListEntries < ICMP_LIST_MAX_LEN) {
    memcpy(&icmpHostsList[icmpListEntries], 
	   icmpPktInfo, sizeof(IcmpPktInfo));
    icmpListEntries++;
    /* printf("num=%d\n", icmpListEntries); */
  }
}

/* ******************************* */

static void printIcmpPkt(IcmpPktInfo *icmpPktInfo) {
  int s_idx, d_idx;
  char icmpBuf[512];
  struct ip *oip;
  u_int hlen;
  u_int dport, mtu;
  char *str, *fmt, *cp;
  const struct udphdr *ouh;
  unsigned long theTime = icmpPktInfo->pktTime;

  s_idx = findHostInfo(&icmpPktInfo->sourceHost);
  d_idx = findHostInfo(&icmpPktInfo->destHost);
  
  if((s_idx == -1) || (d_idx == -1))
    return;

  sendString("<TR ");
  sendString(getRowColor());
  sendString("><TD>");
  sendString(ctime((time_t*)&theTime));
  sendString("</TD>");
  sendString(makeHostLink(device[actualReportDeviceId].hash_hostTraffic[checkSessionIdx(s_idx)], LONG_FORMAT, 0, 0));
  sendString(makeHostLink(device[actualReportDeviceId].hash_hostTraffic[checkSessionIdx(d_idx)], LONG_FORMAT, 0, 0));
  sendString("<TD>");

  switch (icmpPktInfo->icmpData.icmpPkt.icmp_type) {

  case ICMP_ECHOREPLY:
    strcpy(icmpBuf, "ECHO reply");
    break;

  case ICMP_ECHO:
    strcpy(icmpBuf, "ECHO request");
    break;

  case ICMP_UNREACH:
    switch (icmpPktInfo->icmpData.icmpPkt.icmp_code) {

    case ICMP_UNREACH_PROTOCOL:
       NTOHL(icmpPktInfo->icmpData.icmpPkt.icmp_ip.ip_dst.s_addr);
      (void)sprintf(icmpBuf, "%s protocol 0x%X unreachable",
		    ipaddr2str(icmpPktInfo->icmpData.icmpPkt.icmp_ip.ip_dst),
		    icmpPktInfo->icmpData.icmpPkt.icmp_ip.ip_p);
      break;

    case ICMP_UNREACH_PORT:
      oip = &icmpPktInfo->icmpData.icmpPkt.icmp_ip;
      hlen = oip->ip_hl * 4;
      ouh = (struct udphdr *)(((u_char *)oip) + hlen);
#ifdef SLACKWARE
      dport = ntohs(ouh->dest);
#else
      dport = ntohs(ouh->uh_dport);
#endif
      NTOHL(oip->ip_dst.s_addr);
      switch (oip->ip_p) {

      case IPPROTO_TCP:	
	(void)sprintf(icmpBuf,
		      "%s tcp port %d unreachable",
		      ipaddr2str(oip->ip_dst),
		      dport);
	break;

      case IPPROTO_UDP:
	(void)sprintf(icmpBuf,
		      "%s udp port %d unreachable",
		      ipaddr2str(oip->ip_dst),
		      dport);
	break;

      default:
	(void)sprintf(icmpBuf,
		      "%s protocol 0x%X port %d unreachable",
		      ipaddr2str(oip->ip_dst),
		      oip->ip_p, dport);
	break;
      }
      break;

    case ICMP_UNREACH_NEEDFRAG:
      {
	register const struct mtu_discovery *mp;

	mp = (struct mtu_discovery *)&icmpPktInfo->icmpData.icmpPkt.icmp_void;
	mtu = EXTRACT_16BITS(&mp->nexthopmtu);
	NTOHL(icmpPktInfo->icmpData.icmpPkt.icmp_ip.ip_dst.s_addr);
	if (mtu)
	  (void)sprintf(icmpBuf,
			"%s unreachable - need to frag (mtu %d)",
			ipaddr2str(icmpPktInfo->icmpData.icmpPkt.icmp_ip.ip_dst), mtu);
	else
	  (void)sprintf(icmpBuf,
			"%s unreachable - need to frag",
			ipaddr2str(icmpPktInfo->icmpData.icmpPkt.icmp_ip.ip_dst));
      }
      break;

    default:
      NTOHL(icmpPktInfo->icmpData.icmpPkt.icmp_ip.ip_dst.s_addr);
      fmt = tok2str(unreach2str, "#%d %%s unreachable",
		    icmpPktInfo->icmpData.icmpPkt.icmp_code);
      (void)sprintf(icmpBuf, fmt,
		    ipaddr2str(icmpPktInfo->icmpData.icmpPkt.icmp_ip.ip_dst));
      break;
    }
    break;

  case ICMP_REDIRECT:
    NTOHL(icmpPktInfo->icmpData.icmpPkt.icmp_ip.ip_dst.s_addr);
    NTOHL(icmpPktInfo->icmpData.icmpPkt.icmp_gwaddr.s_addr);
    fmt = tok2str(type2str, "redirect-#%d %%s to net %%s",
		  icmpPktInfo->icmpData.icmpPkt.icmp_code);
    (void)sprintf(icmpBuf, fmt,
		  ipaddr2str(icmpPktInfo->icmpData.icmpPkt.icmp_ip.ip_dst),
		  ipaddr2str(icmpPktInfo->icmpData.icmpPkt.icmp_gwaddr));
    break;

  case ICMP_ROUTERADVERT:
    {
      register const struct ih_rdiscovery *ihp;
      register const struct id_rdiscovery *idp;
      u_int lifetime, num, size;

      (void)strcpy(icmpBuf, "router advertisement");
      cp = icmpBuf + strlen(icmpBuf);

      ihp = (struct ih_rdiscovery *)&icmpPktInfo->icmpData.icmpPkt.icmp_void;
      (void)strcpy(cp, " lifetime ");
      cp = icmpBuf + strlen(icmpBuf);
      lifetime = EXTRACT_16BITS(&ihp->ird_lifetime);
      if (lifetime < 60)
	(void)sprintf(cp, "%u", lifetime);
      else if (lifetime < 60 * 60)
	(void)sprintf(cp, "%u:%02u",
		      lifetime / 60, lifetime % 60);
      else
	(void)sprintf(cp, "%u:%02u:%02u",
		      lifetime / 3600,
		      (lifetime % 3600) / 60,
		      lifetime % 60);
      cp = icmpBuf + strlen(icmpBuf);

      num = ihp->ird_addrnum;
      (void)sprintf(cp, " %d:", num);
      cp = icmpBuf + strlen(icmpBuf);

      size = ihp->ird_addrsiz;
      if (size != 2) {
	(void)sprintf(cp, " [size %d]", size);
	break;
      }
      idp = (struct id_rdiscovery *)icmpPktInfo->icmpData.icmpPkt.icmp_data;
      while (num-- > 0) {
	struct in_addr theAddr;

	theAddr.s_addr = idp->ird_addr;
	NTOHL(theAddr.s_addr);
	(void)sprintf(cp, " {%s %u}",
		      ipaddr2str(theAddr),
		      EXTRACT_32BITS(&idp->ird_pref));
	cp = icmpBuf + strlen(icmpBuf);
      }
    }
    break;

  case ICMP_TIMXCEED:
    switch (icmpPktInfo->icmpData.icmpPkt.icmp_code) {

    case ICMP_TIMXCEED_INTRANS:
      str = "time exceeded in-transit";
      break;

    case ICMP_TIMXCEED_REASS:
      str = "ip reassembly time exceeded";
      break;

    default:
      (void)sprintf(icmpBuf, "time exceeded-#%d", icmpPktInfo->icmpData.icmpPkt.icmp_code);
      break;
    }
    break;

  case ICMP_PARAMPROB:
    if (icmpPktInfo->icmpData.icmpPkt.icmp_code)
      (void)sprintf(icmpBuf, "parameter problem - code %d",
		    icmpPktInfo->icmpData.icmpPkt.icmp_code);
    else {
      (void)sprintf(icmpBuf, "parameter problem - octet %d",
		    icmpPktInfo->icmpData.icmpPkt.icmp_pptr);
    }
    break;

  case ICMP_MASKREQ:
    strcpy(icmpBuf, "ICMP network mask request");
    break;

  case ICMP_MASKREPLY:
    (void)sprintf(icmpBuf, "address mask is 0x%08x",
		  (u_int32_t)ntohl(icmpPktInfo->icmpData.icmpPkt.icmp_mask));
    break;

  default:
    (void)sprintf(icmpBuf, "type-#%d", icmpPktInfo->icmpData.icmpPkt.icmp_type);
    break;
  }

  sendString(icmpBuf);
  sendString("</TR>\n");
}

/* ******************************* */

static int sortICMPHostsInfo(const void *_a, const void *_b) {
  IcmpPktInfo *a = (IcmpPktInfo *)_a;
  IcmpPktInfo *b = (IcmpPktInfo *)_b;

    if(a->pktTime > b->pktTime)
      return(1);
    else if(a->pktTime < b->pktTime)
      return(-1);
    else
      return(0);
}

/* ******************************* */

static void runICMPgarbageCollector() {
  datum key_data;
  datum return_data;
  char tmpTime[32];
  time_t theTime;

  if(actTime > garbageTime) {
#ifdef DEBUG
    printf("runICMPgarbageCollector()\n");
#endif

#ifdef MULTITHREADED
    accessMutex(&gdbmMutex, "runICMPgarbageCollector");
#endif 
    return_data = gdbm_firstkey (icmpDB);
#ifdef MULTITHREADED
    releaseMutex(&gdbmMutex);
#endif 

    while (return_data.dptr != NULL) {
      key_data = return_data;
#ifdef MULTITHREADED
      accessMutex(&gdbmMutex, "runICMPgrbageCollector-2");
#endif 
      return_data = gdbm_nextkey(icmpDB, key_data);    
#ifdef MULTITHREADED
      releaseMutex(&gdbmMutex);
#endif 
      strcpy(tmpTime, key_data.dptr);    
      theTime = atol(strtok(tmpTime, "/"));
      if(theTime < garbageTime) {
#ifdef DEBUG
	printf("Purging entry %u/%u\n", theTime,garbageTime);
#endif
#ifdef MULTITHREADED
	accessMutex(&gdbmMutex, "runICMPgarbageCollector-3");
#endif 
	gdbm_delete(icmpDB, key_data);
#ifdef MULTITHREADED
	releaseMutex(&gdbmMutex);
#endif 
      }
      free(key_data.dptr);
    }

    garbageTime = actTime+(15*60); /* 15 minutes */
  }
}

/* ******************************* */

static void printIcmpHostPkts(struct in_addr hostIpAddress, 
			      int icmpId) {
  datum key_data, data_data;
  datum return_data;
  IcmpPktInfo icmpPktInfo;
  u_int num=0;

  runICMPgarbageCollector();

  icmpListEntries=0;
  memset(icmpHostsList, 0, sizeof(icmpHostsList));

#ifdef DEBUG
    printf("Searching for '%u' [%d]...\n", hostIpAddress.s_addr, icmpId); 
#endif

#ifdef MULTITHREADED
    accessMutex(&gdbmMutex, "printICMPHostsPkts");
#endif 
  return_data = gdbm_firstkey (icmpDB);
#ifdef MULTITHREADED
  releaseMutex(&gdbmMutex);
#endif 

  while (return_data.dptr != NULL) {
    key_data = return_data;
#ifdef MULTITHREADED
    accessMutex(&gdbmMutex, "printICMPHostsPkts");
#endif 
    return_data = gdbm_nextkey(icmpDB, key_data);    
    data_data = gdbm_fetch(icmpDB, key_data);
#ifdef MULTITHREADED
    releaseMutex(&gdbmMutex);
#endif 

    if(data_data.dptr != NULL) {
      memcpy(&icmpPktInfo, data_data.dptr, sizeof(IcmpPktInfo));
#ifdef DEBUG
      printf("%d) %u/%u [%d]\n", ++num,
	     icmpPktInfo.sourceHost.s_addr,
	     icmpPktInfo.destHost.s_addr,
	     icmpPktInfo.icmpData.icmpPkt.icmp_type); 
#endif
      if((icmpPktInfo.sourceHost.s_addr == hostIpAddress.s_addr)
	 || (icmpPktInfo.destHost.s_addr == hostIpAddress.s_addr)) {
	switch(icmpId) {
	case ICMP_ECHO:
	  if((icmpPktInfo.icmpData.icmpPkt.icmp_type == ICMP_ECHO)
	     || (icmpPktInfo.icmpData.icmpPkt.icmp_type == ICMP_ECHOREPLY))
	    insertICMPPkt(&icmpPktInfo);
	  break;
	case ICMP_UNREACH:
	  if(icmpPktInfo.icmpData.icmpPkt.icmp_type == ICMP_UNREACH)
	    insertICMPPkt(&icmpPktInfo);
	  break;
	case ICMP_REDIRECT:
	  if(icmpPktInfo.icmpData.icmpPkt.icmp_type == ICMP_REDIRECT)
	    insertICMPPkt(&icmpPktInfo);
	  break;
	case ICMP_ROUTERADVERT:
	  if(icmpPktInfo.icmpData.icmpPkt.icmp_type == ICMP_ROUTERADVERT)
	    insertICMPPkt(&icmpPktInfo);
	  break;
	case ICMP_TIMXCEED:
	  if(icmpPktInfo.icmpData.icmpPkt.icmp_type == ICMP_TIMXCEED)
	    insertICMPPkt(&icmpPktInfo);
	  break;
	case ICMP_PARAMPROB:
	  if(icmpPktInfo.icmpData.icmpPkt.icmp_type == ICMP_PARAMPROB)
	    insertICMPPkt(&icmpPktInfo);
	  break;
	case ICMP_MASKREQ:
	  if((icmpPktInfo.icmpData.icmpPkt.icmp_type == ICMP_MASKREQ)
	     || (icmpPktInfo.icmpData.icmpPkt.icmp_type == ICMP_MASKREPLY))
	    insertICMPPkt(&icmpPktInfo);
	  break;
	  break;
	case ICMP_SOURCE_QUENCH:
	  if(icmpPktInfo.icmpData.icmpPkt.icmp_type == ICMP_SOURCE_QUENCH)
	    insertICMPPkt(&icmpPktInfo);
	  break;
	case ICMP_TIMESTAMP:
	  if((icmpPktInfo.icmpData.icmpPkt.icmp_type == ICMP_TIMESTAMP)
	     || (icmpPktInfo.icmpData.icmpPkt.icmp_type == ICMP_TIMESTAMPREPLY))
	    insertICMPPkt(&icmpPktInfo);
	  break;
	case ICMP_INFO_REQUEST:
	  if((icmpPktInfo.icmpData.icmpPkt.icmp_type == ICMP_INFO_REQUEST)
	     || (icmpPktInfo.icmpData.icmpPkt.icmp_type == ICMP_INFO_REPLY))
	    insertICMPPkt(&icmpPktInfo);
	  break;
	}
      }
    }

    if(data_data.dptr != NULL) free(data_data.dptr);
    free(key_data.dptr);
  } /* while */

  /* ************************ */

  sendString("<CENTER><TABLE BORDER>\n");
  sendString("<TH>Time</TH><TH>Source</TH><TH>Dest</TH>"
	     "<TH>Packet</TH></TR>\n");

  quicksort(icmpHostsList, icmpListEntries, 
	    sizeof(IcmpPktInfo), sortICMPHostsInfo);
  
  for(num=0; num<icmpListEntries; num++)
    printIcmpPkt(&icmpHostsList[num]);

  sendString("</TABLE></CENTER>\n");
  printHTTPtrailer();
}

/* ******************************* */

static void handleIcmpWatchHTTPrequest(char* url) {
  char buf[1024], anchor[256], fileName[64];
  char *sign = "-";
  char *pluginName = "<A HREF=/plugins/icmpWatch";
  u_int i, revertOrder=0;
  int num, idx, icmpId=-1;
  IcmpHostInfo *localIcmpHostsTable[HASHNAMESIZE];
  struct in_addr hostIpAddress;
  char  *lbls[HASHNAMESIZE];
  float s[HASHNAMESIZE], r[HASHNAMESIZE];

  tmpnam(fileName);

  memset(localIcmpHostsTable, 0, sizeof(localIcmpHostsTable));
  memset(s, 0, sizeof(s));
  memset(r, 0, sizeof(r));
  memset(lbls, 0, sizeof(lbls));

  for(i=0, num=0; i<actualHashSize; i++) 
    if(icmpHostsTable[i] != NULL) {
      idx = findHostInfo(&icmpHostsTable[i]->hostIpAddress);      
      if((idx != -1) && (device[actualReportDeviceId].hash_hostTraffic[checkSessionIdx(idx)] != NULL)) {
	localIcmpHostsTable[num++] = icmpHostsTable[i];
	icmpHostsTable[i]->host = device[actualReportDeviceId].hash_hostTraffic[idx];
      }
    }

  hostIpAddress.s_addr = 0;

  if(url[0] == '\0')
    icmpColumnSort = 0;
  else if(strncmp(url, "reset", strlen("reset")) == 0) {
    memset(icmpHostsTable, 0, sizeof(icmpHostsTable));
    numIcmpEntries = 0;
    icmpColumnSort = 0;
    sendString("HTTP/1.1 302 Found\nContent-type: text/html\n");
    sendString("Location: /plugins/icmpWatch\n\n");
    return;
  } else if((url[0] == '-') || isdigit(url[0])) {
    if(url[0] == '-') {
      sign = "";
      revertOrder = 1;
      icmpColumnSort = atoi(&url[1]);
    } else
      icmpColumnSort = atoi(url);
  } else /* host=3240847503&icmp=3 */ {   
    char *tmpStr;

    if(strncmp(url, "chart", strlen("chart")) == 0) {
      /* GIF */      
      char tmpStr[256];
      u_int len, tot=0;
      FILE *fd;
      unsigned long  sc[2] = { 0xFF0000, 0x8080FF };

      GDC_BGColor   = 0xFFFFFFL;                  /* backgound color (white) */
      GDC_LineColor = 0x000000L;                  /* line color      (black) */
      GDC_SetColor  = &(sc[0]);                   /* assign set colors */
      GDC_ytitle = "Packets";

      for(i=0; i<actualHashSize; i++) {
	if(localIcmpHostsTable[i] != NULL) {
	  int j;
	  HostTraffic *host = localIcmpHostsTable[i]->host;

	  s[tot] = 0, r[tot] = 0;
	    
	  for(j=0; j<ICMP_MAXTYPE; j++) {
	    s[tot] += localIcmpHostsTable[i]->icmpMsgSent[j];
	    r[tot] += localIcmpHostsTable[i]->icmpMsgRcvd[j];
	  }

	  lbls[tot++] = host->hostSymIpAddress;
	}
      }
	
      /* printf("file=%s\n", fileName); */

      fd = fopen(fileName, "wb");

      GDC_title = "ICMP Host Traffic";
      /* The line below causes a crash on Solaris/SPARC (who knows why) */
      /* GDC_yaxis=1; */
      GDC_ylabel_fmt = NULL;
      out_graph(600, 450,           /* width, height           */
		fd,                 /* open FILE pointer       */
		GDC_3DBAR,          /* chart type              */
		tot,                /* num points per data set */
		lbls,               /* X labels array of char* */
		2,                  /* number of data sets     */
		s, r);              /* dataset 2               */
      
      fclose(fd);
      
      sendHTTPProtoHeader();
      sendGIFHeaderType();

      fd = fopen(fileName, "rb");
      for(;;) {
	len = fread(tmpStr, sizeof(char), 255, fd);
	if(len <= 0) break;
	sendStringLen(tmpStr, len);
      }
  
      fclose(fd);  

      unlink(fileName);

      return;
    }

    strtok(url, "=");
    
    tmpStr = strtok(NULL, "&");
    hostIpAddress.s_addr = strtoul(tmpStr, (char **)NULL, 10); 
#ifdef DEBUG
    printf("-> %s [%u]\n", tmpStr, hostIpAddress.s_addr);
#endif
    strtok(NULL, "=");
    icmpId = atoi(strtok(NULL, "&")); 
  }

  sendHTTPProtoHeader(); sendHTTPHeaderType(); printHTTPheader();

  sendString("<CENTER><FONT FACE=Helvetica><H1>ICMP Statistics</H1><p>\n");

  if(numIcmpEntries == 0) {
    printNoDataYet();
    printHTTPtrailer();
    return;
  }

  if(hostIpAddress.s_addr == 0)
    sendString("<br><IMG SRC=/plugins/icmpWatch?chart><p>\n");
 
  if(icmpId != -1) {  
    printIcmpHostPkts(hostIpAddress, icmpId);
    return;
  }

  sendString("<TABLE BORDER>\n");
  sprintf(buf, "<TR><TH>%s?%s1>Host</A><br>[Pkt&nbsp;Sent/Rcvd]</TH>"
	 "<TH>%s?%s2>Echo</A></TH>"
	 "<TH>%s?%s3>Unreach</A></TH>"
	 "<TH>%s?%s4>Redirect</A></TH>"
	 "<TH>%s?%s5>Router<br>Advert.</A></TH>"
	 "<TH>%s?%s6>Time<br>Exceeded</A></TH>"
	 "<TH>%s?%s7>Param.<br>Problem</A></TH>"
	 "<TH>%s?%s8>Network<br>Mask</A></TH>"
	 "<TH>%s?%s9>Source<br>Quench</A></TH>"
	 "<TH>%s?%s10>Timestamp</A></TH>"
	 "<TH>%s?%s11>Info</A></TH>"
	 "</TR>\n",
	  pluginName, sign,
	  pluginName, sign,
	  pluginName, sign,
	  pluginName, sign,
	  pluginName, sign,
	  pluginName, sign,
	  pluginName, sign,
	  pluginName, sign,
	  pluginName, sign,
	  pluginName, sign,
	  pluginName, sign);
  sendString(buf);

  quicksort(localIcmpHostsTable, num, sizeof(struct localIcmpHostsTable*), sortICMPhosts);

  for(i=0; i<actualHashSize; i++) 
    if(localIcmpHostsTable[i] != NULL) {
      unsigned long tot;
      char *postAnchor;
      int idx;
      HostTraffic *host;

      if(revertOrder)
	idx = num-i-1;
      else
	idx = i;

      host = localIcmpHostsTable[idx]->host;

      sprintf(buf, "<TR %s> %s", 	  
	      getRowColor(),
	      makeHostLink(host, LONG_FORMAT, 0, 0));
      sendString(buf);
      
      sprintf(buf, "<TD ALIGN=right>%s/%s</TD>",  
	      formatPkts((TrafficCounter)(localIcmpHostsTable[idx]->icmpMsgSent[ICMP_ECHO]+
			 localIcmpHostsTable[idx]->icmpMsgSent[ICMP_ECHOREPLY])),
	      formatPkts((TrafficCounter)(localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_ECHO]+
			 localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_ECHOREPLY])));
      sendString(buf);


      tot=localIcmpHostsTable[idx]->icmpMsgSent[ICMP_UNREACH]+
	localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_UNREACH];      
      if(tot > 0) {
	sprintf(anchor, "%s?host=%lu&icmp=%d>", 
		pluginName, 
		(unsigned long)localIcmpHostsTable[idx]->hostIpAddress.s_addr, 
		(int)ICMP_UNREACH);
	postAnchor = "</A>";
      } else {
	anchor[0] = '\0';
	postAnchor = "";
      }
      sprintf(buf, "<TD ALIGN=center>%s%s/%s%s</TD>",
	      anchor,
	      formatPkts((TrafficCounter)localIcmpHostsTable[idx]->icmpMsgSent[ICMP_UNREACH]),
	      formatPkts((TrafficCounter)localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_UNREACH]),
	      postAnchor);
      sendString(buf);

      
      tot=localIcmpHostsTable[idx]->icmpMsgSent[ICMP_REDIRECT]+
	localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_REDIRECT];
      if(tot > 0) {
	sprintf(anchor, "%s?host=%lu&icmp=%d>", 
		pluginName, 
		(unsigned long)localIcmpHostsTable[idx]->hostIpAddress.s_addr, 
		(int)ICMP_REDIRECT);
	postAnchor = "</A>";
      } else {
	anchor[0] = '\0';
	postAnchor = "";
      }
      sprintf(buf, "<TD ALIGN=center>%s%s/%s%s</TD>", anchor,
	      formatPkts((TrafficCounter)localIcmpHostsTable[idx]->icmpMsgSent[ICMP_REDIRECT]),
	      formatPkts((TrafficCounter)localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_REDIRECT]),
	      postAnchor);
      sendString(buf);

      tot=localIcmpHostsTable[idx]->icmpMsgSent[ICMP_ROUTERADVERT]+
	localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_ROUTERADVERT];
      if(tot > 0) {
	sprintf(anchor, "%s?host=%lu&icmp=%d>", 
		pluginName, 
		(unsigned long)localIcmpHostsTable[idx]->hostIpAddress.s_addr, 
		(int)ICMP_ROUTERADVERT);
	postAnchor = "</A>";
      } else {
	anchor[0] = '\0';
	postAnchor = "";
      }
      sprintf(buf, "<TD ALIGN=center>%s%s/%s%s</TD>", anchor,
	      formatPkts((TrafficCounter)localIcmpHostsTable[idx]->icmpMsgSent[ICMP_ROUTERADVERT]),
	      formatPkts((TrafficCounter)localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_ROUTERADVERT]),
	      postAnchor);
      sendString(buf);
      
      tot=localIcmpHostsTable[idx]->icmpMsgSent[ICMP_TIMXCEED]+
	localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_TIMXCEED];
      if(tot > 0) {
	sprintf(anchor, "%s?host=%lu&icmp=%d>", 
		pluginName, 
		(unsigned long)localIcmpHostsTable[idx]->hostIpAddress.s_addr, 
		(int)ICMP_TIMXCEED);
	postAnchor = "</A>";
      } else {
	anchor[0] = '\0';
	postAnchor = "";
      }
      sprintf(buf, "<TD ALIGN=center>%s%s/%s%s</TD>", anchor,
	      formatPkts((TrafficCounter)localIcmpHostsTable[idx]->icmpMsgSent[ICMP_TIMXCEED]),
	     formatPkts((TrafficCounter)localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_TIMXCEED]),
	      postAnchor);
      sendString(buf);

      tot=localIcmpHostsTable[idx]->icmpMsgSent[ICMP_PARAMPROB]+
	localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_PARAMPROB];
      if(tot > 0) {
	sprintf(anchor, "%s?host=%lu&icmp=%d>", 
		pluginName, 
		(unsigned long)localIcmpHostsTable[idx]->hostIpAddress.s_addr, 
		(int)ICMP_PARAMPROB);
	postAnchor = "</A>";
      } else {
	anchor[0] = '\0';
	postAnchor = "";
      }
      sprintf(buf, "<TD ALIGN=center>%s%s/%s%s</TD>", anchor,
	      formatPkts((TrafficCounter)localIcmpHostsTable[idx]->icmpMsgSent[ICMP_PARAMPROB]),
	      formatPkts((TrafficCounter)localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_PARAMPROB]),
	      postAnchor);
      sendString(buf);

      tot=localIcmpHostsTable[idx]->icmpMsgSent[ICMP_MASKREQ]+
	localIcmpHostsTable[idx]->icmpMsgSent[ICMP_MASKREPLY]+
	localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_MASKREQ]+
	localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_MASKREPLY];
      if(tot > 0) {
	sprintf(anchor, "%s?host=%lu&icmp=%d>", 
		pluginName, 
		(unsigned long)localIcmpHostsTable[idx]->hostIpAddress.s_addr, 
		(int)ICMP_MASKREQ);
	postAnchor = "</A>";
      } else {
	anchor[0] = '\0';
	postAnchor = "";
      }
      sprintf(buf, "<TD ALIGN=center>%s%s/%s%s</TD>", anchor,
	      formatPkts((TrafficCounter)(localIcmpHostsTable[idx]->icmpMsgSent[ICMP_MASKREQ]+
			 localIcmpHostsTable[idx]->icmpMsgSent[ICMP_MASKREPLY])),
	      formatPkts((TrafficCounter)(localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_MASKREQ]+
			 localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_MASKREPLY])),
	      postAnchor);
      sendString(buf);

      tot=localIcmpHostsTable[idx]->icmpMsgSent[ICMP_SOURCE_QUENCH]+
	localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_SOURCE_QUENCH];
      if(tot > 0) {
	sprintf(anchor, "%s?host=%lu&icmp=%d>", 
		pluginName, 
		(unsigned long)localIcmpHostsTable[idx]->hostIpAddress.s_addr, 
		(int)ICMP_SOURCE_QUENCH);
	postAnchor = "</A>";
      } else {
	anchor[0] = '\0';
	postAnchor = "";
      }
      sprintf(buf, "<TD ALIGN=center>%s%s/%s%s</TD>", anchor,
	      formatPkts((TrafficCounter)localIcmpHostsTable[idx]->icmpMsgSent[ICMP_SOURCE_QUENCH]),
	      formatPkts((TrafficCounter)localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_SOURCE_QUENCH]),
	      postAnchor);
      sendString(buf);

      tot=localIcmpHostsTable[idx]->icmpMsgSent[ICMP_TIMESTAMP]+
	localIcmpHostsTable[idx]->icmpMsgSent[ICMP_TIMESTAMPREPLY]+
	localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_TIMESTAMP]+
	localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_TIMESTAMPREPLY];
      if(tot > 0) {
	sprintf(anchor, "%s?host=%lu&icmp=%d>", 
		pluginName, 
		(unsigned long)localIcmpHostsTable[idx]->hostIpAddress.s_addr, 
		(int)ICMP_TIMESTAMP);
	postAnchor = "</A>";
      } else {
	anchor[0] = '\0';
	postAnchor = "";
      }
      sprintf(buf, "<TD ALIGN=center>%s%s/%s%s</TD>", anchor,
	      formatPkts((TrafficCounter)(localIcmpHostsTable[idx]->icmpMsgSent[ICMP_TIMESTAMP]+
			 localIcmpHostsTable[idx]->icmpMsgSent[ICMP_TIMESTAMPREPLY])),
	      formatPkts((TrafficCounter)(localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_TIMESTAMP]+
			 localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_TIMESTAMPREPLY])),
	      postAnchor);
      sendString(buf);

      tot=localIcmpHostsTable[idx]->icmpMsgSent[ICMP_INFO_REQUEST]+
	localIcmpHostsTable[idx]->icmpMsgSent[ICMP_INFO_REPLY]+
	localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_INFO_REQUEST]+
	localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_INFO_REPLY];
      if(tot > 0) {
	sprintf(anchor, "%s?host=%lu&icmp=%d>", 
		pluginName, 
		(unsigned long)localIcmpHostsTable[idx]->hostIpAddress.s_addr, 
		(int)ICMP_INFO_REQUEST);
	postAnchor = "</A>";
      } else {
	anchor[0] = '\0';
	postAnchor = "";
      }
      sprintf(buf, "<TD ALIGN=center>%s%s/%s%s</TD>", anchor,
	      formatPkts((TrafficCounter)(localIcmpHostsTable[idx]->icmpMsgSent[ICMP_INFO_REQUEST]+
			 localIcmpHostsTable[idx]->icmpMsgSent[ICMP_INFO_REPLY])),
	      formatPkts((TrafficCounter)(localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_INFO_REQUEST]+
			 localIcmpHostsTable[idx]->icmpMsgRcvd[ICMP_INFO_REPLY])),
	      postAnchor);
      sendString(buf);

      sendString("</TR>\n");
  }

  sendString("</TABLE>\n");

  sendString("<p></CENTER><H4><A HREF=\"/plugins/icmpWatch?reset\">Reset Stats</A></H4>\n");

  printHTTPtrailer();
}

/* ****************************** */

static void termIcmpFunct() {
  printf("Thanks for using icmpWatch.\n");
  
  if(icmpDB != NULL) {
    gdbm_close(icmpDB);
    icmpDB = NULL;
  }
}

/* ****************************** */

static PluginInfo icmpPluginInfo[] = {
  { "icmpWatchPlugin",
    "This plugin handles ICMP packets",
    "1.0", /* version */
    "<A HREF=http://jake.unipi.it/~deri/>Luca Deri</A>", 
    "icmpWatch", /* http://<host>:<port>/plugins/icmpWatch */
    termIcmpFunct, /* TermFunc   */
    handleIcmpPacket, /* PluginFunc */
    handleIcmpWatchHTTPrequest,
    "icmp" /* BPF filter: filter all the ICMP packets */
  }
};

/* Plugin entry fctn */
#ifdef STATIC_PLUGIN
PluginInfo* icmpPluginEntryFctn() {
#else
PluginInfo* PluginEntryFctn() {
#endif
	char tmpBuf[200];

  printf("Welcome to %s. (C) 1999 by Luca Deri.\n", icmpPluginInfo->pluginName);

  /* Fix courtesy of Ralf Amandi <Ralf.Amandi@accordata.net> */
  sprintf(tmpBuf,"%s/icmpWatch.db",dbPath);
  icmpDB = gdbm_open (tmpBuf, 0, GDBM_NEWDB, 00664, NULL);

  if(icmpDB == NULL) 
    printf("Unable to open icmpWatch database. This plugin will be disabled.\n");
  else {
    memset(icmpHostsTable, 0, sizeof(icmpHostsTable));
    numIcmpEntries = 0;
  }

  garbageTime = actTime+(15*60); /* 15 minutes */
  return(icmpPluginInfo);
}
