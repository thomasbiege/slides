/*
 *  Copyright (C) 1998-2000 Luca Deri <deri@ntop.org>
 *
 *  			  Centro SERRA, University of Pisa
 *  			  http://www.ntop.org/
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "ntop.h"
#include "remoteInterface.h"
#include "globals-report.h"

extern int webPort; /* main.c */

static pthread_t remIntTreadId;
static int remIntSock;

static void termRemIntFunct() {
  if(remIntSock > 0) {
    closeNwSocket(&remIntSock);
    remIntSock = 0;
  }
}

/* ****************************** */

void returnHostEntry(HostTraffic* theHost, char* udpBuf) {
  char theTime[64];

  char buf1[384], buf2[384], buf3[384], buf4[384];

  if(theHost == NULL) {
    sprintf(udpBuf, "%s\n", EMPTY_SLOT_RC);
    return;    
  }

  strcpy(theTime, ctime(&theHost->lastSeen));
  theTime[strlen(theTime)-1] = '\0';

  sprintf(buf1, "%s\t" /* Return code */
	  "%s\t%s\t"
	  "%s\t%s\t"
	  "%s\t"
	  "%d\t%s\t%s\t" /* NetBIOS */
	  "%d\t%d\t%s\t" /* AppleTalk */
	  "%d\t%s\t",     /* IPX */
	  OK_RC, theTime,
	  (theHost->ethAddressString != NULL)? theHost->ethAddressString : "",
	  theHost->hostNumIpAddress, theHost->hostSymIpAddress, 
	  (theHost->osName != NULL)? theHost->osName : "",

	  (int)theHost->nbNodeType,
	  ((theHost->nbHostName != NULL)? theHost->nbHostName : ""),
	  ((theHost->nbDomainName != NULL)? theHost->nbDomainName : ""),

	  (int)theHost->atNetwork, (int)theHost->atNode, 
	  ((theHost->atNodeName != NULL)? theHost->atNodeName : ""),

	  (int)theHost->ipxNodeType,
	  ((theHost->ipxHostName != NULL)? theHost->ipxHostName : "")
	  );

  sprintf(buf2,
	  "%ld\t%ld\t%ld\t%ld\t%ld\t%ld\t%ld\t"
	  "%ld\t%ld\t%ld\t%ld\t%ld\t%ld\t%ld\t",
	  (unsigned long)theHost->pktSent,
	  (unsigned long)theHost->pktReceived,
	  (unsigned long)theHost->pktBroadcastSent, 
	  (unsigned long)theHost->bytesBroadcastSent,
	  (unsigned long)theHost->pktMulticastSent,
	  (unsigned long)theHost->bytesMulticastSent,
	  (unsigned long)theHost->pktMulticastRcvd,
	  (unsigned long)theHost->bytesMulticastRcvd,
	  (unsigned long)theHost->bytesSent,
	  (unsigned long)theHost->bytesSentLocally, 
	  (unsigned long)theHost->bytesSentRemotely,
	  (unsigned long)theHost->bytesReceived, 
	  (unsigned long)theHost->bytesReceivedLocally,
	  (unsigned long)theHost->bytesReceivedFromRemote);

  sprintf(buf3, "%f\t%f\t%f\t%f\t%f\t%f\t%f\t"
	  "%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t",
	  (float)theHost->actualRcvdThpt,
	  (float)theHost->lastHourRcvdThpt, 
	  (float)theHost->averageRcvdThpt, 
	  (float)theHost->peakRcvdThpt,
	  (float)theHost->actualSentThpt,
	  (float)theHost->lastHourSentThpt, 
	  (float)theHost->averageSentThpt,
	  (float)theHost->peakSentThpt,
	  (float)theHost->actualRcvdPktThpt,
	  (float)theHost->averageRcvdPktThpt,
	  (float)theHost->peakRcvdPktThpt,
	  (float)theHost->actualSentPktThpt,
	  (float)theHost->averageSentPktThpt, 
	  (float)theHost->peakSentPktThpt,
	  (float)theHost->actBandwidthUsage);

  sprintf(buf4, 
	  "%ld\t%ld\t%ld\t%ld\t%ld\t%ld\t%ld\t%ld\t%ld\t"
	  "%ld\t%ld\t%ld\t%ld\t%ld\t%ld\t%ld\t%ld\t%ld\n",
	  (unsigned long)theHost->ipxSent, 
	  (unsigned long)theHost->ipxReceived,
	  (unsigned long)theHost->osiSent, 
	  (unsigned long)theHost->osiReceived,
	  (unsigned long)theHost->dlcSent, 
	  (unsigned long)theHost->dlcReceived,
	  (unsigned long)theHost->arp_rarpSent, 
	  (unsigned long)theHost->arp_rarpReceived,
	  (unsigned long)theHost->decnetSent,
	  (unsigned long)theHost->decnetReceived,
	  (unsigned long)theHost->appletalkSent, 
	  (unsigned long)theHost->appletalkReceived,
	  (unsigned long)theHost->netbiosSent, 
	  (unsigned long)theHost->netbiosReceived,
	  (unsigned long)theHost->qnxSent, 
	  (unsigned long)theHost->qnxReceived,
	  (unsigned long)theHost->otherSent, 
	  (unsigned long)theHost->otherReceived);


  sprintf(udpBuf, "%s%s%s%s", buf1, buf2, buf3, buf4);
}

/* ****************************** */

void returnHostEntryIdx(int idx, char* udpBuf) {
  if((idx < 0) || (idx > actualHashSize)) {
    sprintf(udpBuf, "%s\n", OUT_OF_RANGE_RC);
    return;
  }

  returnHostEntry(device[actualReportDeviceId].hash_hostTraffic[idx], udpBuf);
}

/* ****************************** */

#ifdef MULTITHREADED
void* remIntLoop(void* notUsed) {
  struct sockaddr_in sin;
  fd_set mask;

  remIntSock = socket(AF_INET, SOCK_DGRAM, 0);
  if (remIntSock < 0) {
    printf("socket error: %d", errno);
    return(NULL);
  }

  sin.sin_family      = AF_INET;
  sin.sin_port        = (int)htons((unsigned short int)webPort+2);
  sin.sin_addr.s_addr = INADDR_ANY;

  if(bind(remIntSock, (struct sockaddr *)&sin, sizeof(sin)) < 0) {
    printf("bind: port %d already in use.", webPort);
    closeNwSocket(&remIntSock);
    return(NULL);
  }

  printf("Welcome to ntop Remote Interface [listening on port %d]\n", webPort+2);

  FD_ZERO(&mask);
  FD_SET((unsigned int)remIntSock, &mask);

  while(1) {
    char udpBuf[4096];
    struct sockaddr_in source;

    if(select(remIntSock+1, &mask, 0, 0, NULL) == 1) {
      int rc, length = sizeof(struct sockaddr);
      
      rc = recvfrom(remIntSock, udpBuf, 4096, 0, (struct sockaddr*)&source, &length);
      
      if(rc > 0) {
	udpBuf[rc] = '\0';
#ifdef DEBUG
	printf("Received: [%s]\n", udpBuf);
#endif
      } else {
	printf("Error while reading from socket.\n");
      }

      if(strncasecmp(udpBuf, HELLO_CMD, strlen(HELLO_CMD)) == 0) {
	sprintf(udpBuf, "%s\n%s",  OK_RC, HELLO_CMD);
	rc = sendto(remIntSock, udpBuf, strlen(udpBuf), 0, 
		    (struct sockaddr*)&source, sizeof(source));
      } else if(strncasecmp(udpBuf, GETHOST_CMD, strlen(GETHOST_CMD)) == 0) {
	char *strIdx = strtok(&udpBuf[strlen(GETHOST_CMD)+1], " ");
	u_int idx;
	
	if(strIdx == NULL) {
	  sprintf(udpBuf, "%s\n", WRONG_COMMAND_SYNTAX_RC);
	  rc = sendto(remIntSock, udpBuf, strlen(udpBuf), 0, 
		      (struct sockaddr*)&source, sizeof(source));
	  continue;
	} 
	  
	idx = atoi(strIdx);
	
	returnHostEntryIdx(idx, udpBuf);
	rc = sendto(remIntSock, udpBuf, strlen(udpBuf), 0, 
		    (struct sockaddr*)&source, sizeof(source));
      } else if(strncasecmp(udpBuf, FIND_HOST_BY_IP_CMD, 
			    strlen(FIND_HOST_BY_IP_CMD)) == 0) {
	char *ipAddress = strtok(&udpBuf[strlen(FIND_HOST_BY_IP_CMD)+1], " ");
	
	if(ipAddress == NULL) {
	  sprintf(udpBuf, "%s\n", WRONG_COMMAND_SYNTAX_RC);
	  rc = sendto(remIntSock, udpBuf, strlen(udpBuf), 0, 
		      (struct sockaddr*)&source, sizeof(source));
	  continue;
	}
      } else if(strncasecmp(udpBuf, FIND_HOST_BY_MAC_CMD, 
			    strlen(FIND_HOST_BY_MAC_CMD)) == 0) {
	char *macAddress = strtok(&udpBuf[strlen(FIND_HOST_BY_MAC_CMD)+1], " ");
	
	if(macAddress == NULL) {
	  sprintf(udpBuf, "%s\n", WRONG_COMMAND_SYNTAX_RC);
	  rc = sendto(remIntSock, udpBuf, strlen(udpBuf), 0, 
		      (struct sockaddr*)&source, sizeof(source));
	  continue;
	} 
	
	returnHostEntry(findHostByMAC(macAddress), udpBuf);
	rc = sendto(remIntSock, udpBuf, strlen(udpBuf), 0, 
		    (struct sockaddr*)&source, sizeof(source));
      } else {
	printf("Error while reading from Remote Interface Socket.\n");
	break;
      }
    }
  }
  
  if(remIntSock > 0) {
    closeNwSocket(&remIntSock);
    remIntSock = 0;
  }

  return(0);
}
#endif

/* ****************************** */
  
static void handleRemIntHTTPrequest(char* url) {
  sendHTTPProtoHeader();
  sendHTTPHeaderType();
  printHTTPheader();

  sendString("<CENTER><FONT FACE=Helvetica><H1>"
	     "ntop Remote Interface"
	     "</H1><p></CENTER>\n");
  printHTTPtrailer();
}

/* ****************************** */

static PluginInfo pluginInfo[] = {
  { "remoteInterface",
    "describe what this plugin does",
    "1.0", /* plugin version */
    "<A HREF=http://jake.unipi.it/~deri/>Luca Deri</A>",
    "remoteInterface", /* http://<host>:<port>/plugins/remoteInterface */
    termRemIntFunct, /* TermFunc */
    NULL, /* PluginFunc */
    handleRemIntHTTPrequest,
    NULL /* BPF filter */
  }
};

/* Plugin entry fctn */
#ifdef STATIC_PLUGIN
PluginInfo* RemIntPluginEntryFctn() {
#else
PluginInfo* PluginEntryFctn() {
#endif

  remIntSock = 0;
#ifndef MULTITHREAD
  createThread(&remIntTreadId, remIntLoop, NULL);
#endif

  return(pluginInfo);
}

