/*
 *  Copyright (C) 2000    Luca Deri <deri@ntop.org>
 *
 *		  	  Centro SERRA, University of Pisa
 *		 	  http://www.ntop.org/
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef _REMOTE_INTERFACE_H_
#define _REMOTE_INTERFACE_H_

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/time.h>
#include <netdb.h>

/* ********************************************* */

#define boolean char

typedef struct HashEntry {
  char* key_name;
  char* entry_data;
} HashEntry;

#define FREE_NO_MEMORY                 0
#define FREE_DATA_MEMORY_ONLY          1
#define FREE_KEY_MEMORY_ONLY           2
#define FREE_DATA_AND_KEY_MEMORY       3

class HashTable {
private:
  int totalSlots, slotsInUse;
  HashEntry* slots;
  char** keys;
  char** values;
  int computeHashValue(char*);
  boolean freeMemory;

public:
  HashTable(unsigned int numSlots=256, boolean _freeMemory=FREE_NO_MEMORY);
  ~HashTable();
  void  addEntry(char* key, char* data);
  char* retrieveEntry(char* key);
  void removeEntry(char* key);
  void removeAllEntries();
  char** getEntries();
  char** getEntryKeys();
  int getNumEntries() { return(slotsInUse); };
};

/* ********************************************* */

class NtopHandle {

 private:
  int sockFd;
  char password[17];
  char udpBuf[4096];
  struct sockaddr_in addr;
  unsigned short timeout;

  char* tabTokenize(char* myString);

public:
  NtopHandle(char* host=NULL /* Local */, int port=3002, 
	     int rcvTmeout=30, char* password=NULL) throw(char*);
  ~NtopHandle();

  void setTimeout(int);
  void sendMessage(char* message, HashTable *theHash) throw(char*);
};

/* ********************************************* */

class NtopRemoteInterface {
protected:
  NtopHandle *proxy;

 private:
  HashTable *hash;

  public:
  NtopRemoteInterface(char* host=NULL /* Local */, int port=3002,
		      char* passwd=NULL) throw(char*);
  ~NtopRemoteInterface();

  char* getAttribute(char* name);
  void removeAttribute(char* name);
  char** getAttributes();
  char** getAttributeKeys();
  void removeAllAttributes();
  void print();

  /* ************** */
  
  void getHostByIndex(int idx) throw(char*);
  void findHostByIP(char*) throw(char*);
  void findHostByMAC(char*) throw(char*);
};




#endif /* _REMOTE_INTERFACE_H_ */

