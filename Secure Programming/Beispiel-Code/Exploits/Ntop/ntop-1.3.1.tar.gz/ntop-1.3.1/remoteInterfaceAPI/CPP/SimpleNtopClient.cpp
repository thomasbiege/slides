/*
 *  Copyright (C) 2000    Luca Deri <deri@ntop.org>
 *
 *		  	  Centro SERRA, University of Pisa
 *		 	  http://www.ntop.org/
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */


#include "NtopRemoteInterface.h"


int main(int argc, char *argv[]) {
  NtopRemoteInterface *remInt;

  if(argc < 3) {
    printf("Usage:   %s <host> <port>\n", argv[0]);
    printf("Example: %s localhost 3002\n", argv[0]);
    return -1;
  }  

  remInt = new NtopRemoteInterface(argv[1], atoi(argv[2]));
  
  for(int i=0; i<4096; i++) {
    try {
      remInt->getHostByIndex(i);
      printf("%d) %s\n", i, remInt->getAttribute("hostSymIpAddress"));
    } catch(char *error) {
      printf("%d) empty\n", i);
    }
  }
  
  printf("\n");
  
  delete remInt;
}
