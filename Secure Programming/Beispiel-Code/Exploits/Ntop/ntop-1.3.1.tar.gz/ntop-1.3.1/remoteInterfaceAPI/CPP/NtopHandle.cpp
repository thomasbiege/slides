/*
 *  Copyright (C) 2000    Luca Deri <deri@ntop.org>
 *
 *		  	  Centro SERRA, University of Pisa
 *		 	  http://www.ntop.org/
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "NtopRemoteInterface.h"


/* *************************************** */

NtopHandle::NtopHandle(char* host, int port, int rcvTimeout, char* passwd) throw(char*) {  
  int sockopt = 1;
  
  sockFd = socket(AF_INET, SOCK_DGRAM, 0);

  if(sockFd == -1)
    throw("Unable to create socket");

  setsockopt(sockFd, SOL_SOCKET, SO_REUSEADDR, 
	     (char *)&sockopt, sizeof(sockopt));

  addr.sin_family = AF_INET;
  addr.sin_port = htons(port);

  if((host == NULL) || (host[0] == '\0'))
    addr.sin_addr.s_addr = INADDR_ANY;
  else {
    struct hostent *hostAddr;
      
    hostAddr = gethostbyname(host);      

    if(hostAddr == NULL)
      throw("Unable to find specified host");
    else
      memcpy(&addr.sin_addr.s_addr, 
	     hostAddr->h_addr_list[0], 
	     hostAddr->h_length);
  }

  timeout = rcvTimeout;
  if(passwd == NULL)
    password[0] = '\0';
  else {
    if(strlen(passwd) > 16) {
      strncpy(password, passwd, 16);
      password[16] = '\0';
    } else
      strcpy(password, passwd);
  }
}

/* *************************************** */

NtopHandle::~NtopHandle() {
  if(sockFd != -1)
    close(sockFd);
}
  
/* *************************************** */

void NtopHandle::sendMessage(char* message, HashTable *theHash) throw(char*) {
  int rc;
  fd_set fds;
  struct timeval wait_time;
  static char returnCode[8];

  rc = sendto(sockFd, message, strlen(message),
	      0, (struct sockaddr*)&addr, sizeof(addr));

  FD_ZERO(&fds);
  FD_SET(sockFd, &fds);
  
  wait_time.tv_sec = timeout, wait_time.tv_usec = 0;   
  if(select(sockFd+1, &fds, NULL, NULL, &wait_time) > 0) {
    struct sockaddr_in source;
    unsigned int length;
    
    memset(udpBuf, 0, sizeof(udpBuf));
    length = sizeof(struct sockaddr);

    if((rc = recvfrom(sockFd, udpBuf, 4096, 0, 
		(struct sockaddr*)&source, &length)) > 0) {     
      udpBuf[rc] = '\0';
      
      theHash->removeAllEntries();

#ifdef DEBUG
      printf("------------------------------\n");
      printf("%s\n", udpBuf);
      printf("------------------------------\n");
#endif

      strcpy(returnCode, tabTokenize(udpBuf));
      rc = atoi(returnCode);

      if(rc == 200) {	/* OK */
	theHash->addEntry(strdup("lastSeen"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("ethAddressString"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("hostNumIpAddress"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("hostSymIpAddress"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("osName"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("nbNodeType"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("nbHostName"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("nbDomainName"), strdup(tabTokenize(NULL)));	
	theHash->addEntry(strdup("atNetwork"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("atNode"), strdup(tabTokenize(NULL))); 
	theHash->addEntry(strdup("atNodeName"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("ipxNodeType"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("ipxHostName"), strdup(tabTokenize(NULL)));       
	theHash->addEntry(strdup("pktSent"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("pktReceived"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("pktBroadcastSent"), strdup(tabTokenize(NULL))); 
	theHash->addEntry(strdup("bytesBroadcastSent"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("pktMulticastSent"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("bytesMulticastSent"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("pktMulticastRcvd"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("bytesMulticastRcvd"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("bytesSent"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("bytesSentLocally"), strdup(tabTokenize(NULL))); 
	theHash->addEntry(strdup("bytesSentRemotely"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("bytesReceived"), strdup(tabTokenize(NULL))); 
	theHash->addEntry(strdup("bytesReceivedLocally"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("bytesReceivedFromRemote"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("actualRcvdThpt"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("lastHourRcvdThpt"), strdup(tabTokenize(NULL))); 
	theHash->addEntry(strdup("averageRcvdThpt"), strdup(tabTokenize(NULL))); 
	theHash->addEntry(strdup("peakRcvdThpt"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("actualSentThpt"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("lastHourSentThpt"), strdup(tabTokenize(NULL))); 
	theHash->addEntry(strdup("averageSentThpt"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("peakSentThpt"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("actualRcvdPktThpt"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("averageRcvdPktThpt"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("peakRcvdPktThpt"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("actualSentPktThpt"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("averageSentPktThpt"), strdup(tabTokenize(NULL))); 
	theHash->addEntry(strdup("peakSentPktThpt"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("actBandwidthUsage"), strdup(tabTokenize(NULL)));    
	theHash->addEntry(strdup("ipxSent"), strdup(tabTokenize(NULL))); 
	theHash->addEntry(strdup("ipxReceived"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("osiSent"), strdup(tabTokenize(NULL))); 
	theHash->addEntry(strdup("osiReceived"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("dlcSent"), strdup(tabTokenize(NULL))); 
	theHash->addEntry(strdup("dlcReceived"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("arp_rarpSent"), strdup(tabTokenize(NULL))); 
	theHash->addEntry(strdup("arp_rarpReceived"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("decnetSent"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("decnetReceived"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("appletalkSent"), strdup(tabTokenize(NULL))); 
	theHash->addEntry(strdup("appletalkReceived"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("netbiosSent"), strdup(tabTokenize(NULL))); 
	theHash->addEntry(strdup("netbiosReceived"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("qnxSent"), strdup(tabTokenize(NULL))); 
	theHash->addEntry(strdup("qnxReceived"), strdup(tabTokenize(NULL)));
	theHash->addEntry(strdup("otherSent"), strdup(tabTokenize(NULL))); 
	theHash->addEntry(strdup("otherReceived"), strdup(tabTokenize(NULL)));    
      } else {
	throw(returnCode);
      }
    } else {
      throw("Error while reading from socket.\n");
    }
  }
}

/* *************************************** */

void NtopHandle::setTimeout(int rcvTimeout) {  
  timeout = rcvTimeout;
}

/* *************************************** */

char* NtopHandle::tabTokenize(char* myString) {  
  static char* theString = NULL;
  int i;

  if(myString != NULL)
    theString = myString;

  for(i=0; theString[i] != '\0'; i++) {
    if(theString[i] == '\t') {
      char *retStr;

      theString[i] = '\0';
      retStr = theString;
      theString = &theString[i+1];
      return(retStr);
    }
  }

  return("<>");
}

