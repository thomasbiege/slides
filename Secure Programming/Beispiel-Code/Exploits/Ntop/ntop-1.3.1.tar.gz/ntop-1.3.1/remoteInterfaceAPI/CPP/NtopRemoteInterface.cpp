/*
 *  Copyright (C) 2000    Luca Deri <deri@ntop.org>
 *
 *		  	  Centro SERRA, University of Pisa
 *		 	  http://www.ntop.org/
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "NtopRemoteInterface.h"


/* ********************************************* */

NtopRemoteInterface::NtopRemoteInterface(char* host, int port, 
					 char* passwd) throw(char*) {
  proxy = new NtopHandle(host, port, 30, passwd);
  hash = new HashTable(32, FREE_DATA_AND_KEY_MEMORY);
}

/* ********************************************* */

NtopRemoteInterface::~NtopRemoteInterface() {
  delete hash;
  delete proxy;
}

/* ********************************************* */

char* NtopRemoteInterface::getAttribute(char* name) {
  return((char*)hash->retrieveEntry(name));
}

/* ********************************************* */

void NtopRemoteInterface::removeAttribute(char* name) {
  hash->removeEntry(name);
 }

/* ********************************************* */

char** NtopRemoteInterface::getAttributes() {
  return((char**)(hash->getEntries()));
}

/* ********************************************* */

char** NtopRemoteInterface::getAttributeKeys() {
  return(hash->getEntryKeys());
}

/* ********************************************* */

void NtopRemoteInterface::removeAllAttributes() {
  hash->removeAllEntries();
}

/* ********************************************* */

void NtopRemoteInterface::print() {
  char **keys = getAttributeKeys();
  char **values = getAttributes();

  for(int i=0; keys[i] != NULL; i++)
    {
      if(i == 0)
	printf("[");
      else
	printf(", ");
      printf("%s=%s", keys[i], values[i]);
    }

  printf("]\n");
}

/* ********************************************* */

void NtopRemoteInterface::getHostByIndex(int idx) throw(char*) {
  char message[32];

  sprintf(message, "gethostbyindex %d", idx);
  proxy->sendMessage(message, hash);
}

/* ********************************************* */

void NtopRemoteInterface::findHostByIP(char* theIp) throw(char*) {
  char message[32];

  sprintf(message, "findhostbyip %s", theIp);
  proxy->sendMessage(message, hash);
}

/* ********************************************* */

void NtopRemoteInterface::findHostByMAC(char* theMac) throw(char*) {
  char message[32];

  sprintf(message, "findhostbymac %s", theMac);
  proxy->sendMessage(message, hash);
}
