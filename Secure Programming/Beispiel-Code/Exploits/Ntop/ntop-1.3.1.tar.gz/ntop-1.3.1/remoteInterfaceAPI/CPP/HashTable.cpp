/*
 *  Copyright (C) 2000    Luca Deri <deri@ntop.org>
 *
 *		  	  Centro SERRA, University of Pisa
 *		 	  http://www.ntop.org/
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "NtopRemoteInterface.h"


HashTable::HashTable(unsigned int numSlots, boolean _freeMemory)
{
  int i;

  freeMemory = _freeMemory;
  totalSlots = numSlots;
  slotsInUse = 0;
  slots = new HashEntry[numSlots];
  keys = new char*[numSlots];
  values = new char*[numSlots];

  for(i=0; i<totalSlots; i++)
    slots[i].key_name = NULL;
}


HashTable::~HashTable()
{
  removeAllEntries();
  delete slots;
  delete keys;
  delete values;
}

int HashTable::computeHashValue(char* key)
{
  int seed;

  if(key == NULL)
    return -1;
  else
    {
      seed=0;
      for(int i=strlen(key); i>=0; i--)
	seed = seed+(i*key[i])+key[i];
    }

  return(seed % totalSlots);
}

void HashTable::addEntry(char* key, char* data)
{
  int startPoint, position, i;
  
#ifdef DEBUG
  printf("Adding: '%s' - '%s'\n", key, data);
#endif

  if(totalSlots == slotsInUse)
    {
      /* Not enough room: the table must be larged */ 
      int _totalSlots=totalSlots;

      HashEntry *_slots = slots;
      char **_keys = getEntryKeys();
      char **_values = getEntries();

      totalSlots *= 2; // Double the table
      slots = new HashEntry[totalSlots];
      keys = new char*[totalSlots];
      values = new char*[totalSlots];
      slotsInUse = 0;

      for(i=0; i<totalSlots; i++)
	slots[i].key_name = NULL;

      for(i=0; i<_totalSlots; i++)
	addEntry(_keys[i], _values[i]);
      
      delete _slots;
      delete _keys;
      delete _values;
      //printf("Table expanded: new size is %d\n", totalSlots);
    }

  position = computeHashValue(key);
  if(position != -1)
    {
      startPoint = position;

      while(slots[position].key_name != NULL)
	{
	  if(strcmp(slots[position].key_name, key) == 0)
	    {
	      /* Override Value */
	      switch(freeMemory)
		{
		case FREE_NO_MEMORY:
		  /* Nothing to do */
		  break;
		case FREE_DATA_MEMORY_ONLY:
		  if(slots[position].entry_data != NULL)
		    {
		      delete slots[position].entry_data;
		      slots[position].entry_data = NULL;
		    }
		  break;
		case FREE_KEY_MEMORY_ONLY:
		  /* Nothing to do */
		  break;
		case FREE_DATA_AND_KEY_MEMORY:
		  if(slots[position].entry_data != NULL)
		    {
		      delete slots[position].entry_data;
		      slots[position].entry_data = NULL;
		    }
		  break;
		}

	      slots[position].entry_data = data;
	      return;
	    }

	  position = ((position+1) % totalSlots);

	  if(position == startPoint) /* There are no slots available */
	    return; 
	}

      slots[position].key_name = key;
      slots[position].entry_data = data;
      slotsInUse++;
    }
}


void HashTable::removeEntry(char* key)
{
  int startPoint, position = computeHashValue(key);

  if(position != -1)
    {
      startPoint = position;

      while(slots[position].key_name != NULL)
	{
	  if(strcmp(slots[position].key_name, key) == 0)
	    {
	      /* Remove Entry */
	      switch(freeMemory)
		{
		case FREE_NO_MEMORY:
		  /* Nothing to do */
		  break;
		case FREE_DATA_MEMORY_ONLY:
		  if(slots[position].entry_data != NULL)
		    {
		      delete slots[position].entry_data;
		      slots[position].entry_data = NULL;
		    }
		  break;
		case FREE_KEY_MEMORY_ONLY:
		  delete slots[position].key_name;
		  break;
		case FREE_DATA_AND_KEY_MEMORY:
		  delete slots[position].key_name;		  
		  if(slots[position].entry_data != NULL)
		    {
		      delete slots[position].entry_data;
		      slots[position].entry_data = NULL;
		    }
		  break;
		}
	      
	      slots[position].key_name = NULL;
	      slotsInUse--;
	      break;	      
	    }

	  position = ((position+1) % totalSlots);

	  if(position == startPoint) /* There are no slots available */
	    break;
	}

      /* Nothing found */
    }
}


char* HashTable::retrieveEntry(char* key)
{
  int startPoint, position;

  if(slotsInUse == 0)
    return(NULL);
  else
    position = computeHashValue(key);

  if(position != -1)
    {
      startPoint = position;

      while(slots[position].key_name != NULL)
	{
	  if(strcmp(slots[position].key_name, key) == 0)
	    {
	      /* Found */
	      return(slots[position].entry_data);
	    }

	  position = ((position+1) % totalSlots);

	  if(position == startPoint) /* There are no slots available */
	    return(NULL); 
	}

      /* Nothing found */
    }

  return(NULL); 
}

char** HashTable::getEntries()
{
  int i, j;

  for(i=0, j=0; i<totalSlots; i++)
    {
      if(slots[i].key_name != NULL)
	values[j++] = slots[i].entry_data;
    }
  values[j] = NULL;
  return(values);
}

char** HashTable::getEntryKeys()
{
  int i, j;

  for(i=0, j=0; i<totalSlots; i++)
    {
      if(slots[i].key_name != NULL)
	keys[j++] = slots[i].key_name;
    }

  keys[j] = NULL;
  return(keys);
}

void HashTable::removeAllEntries()
{
  int i;

  for(i=0; i<totalSlots; i++)
    if(slots[i].key_name != NULL)
      {
	switch(freeMemory)
	  {
	  case FREE_NO_MEMORY:
	    /* Nothing to do */
	    break;
	  case FREE_DATA_MEMORY_ONLY:
	    if(slots[i].entry_data != NULL)
	      {
		delete slots[i].entry_data;
		slots[i].entry_data = NULL;
	      }
	    break;
	  case FREE_KEY_MEMORY_ONLY:
	    delete slots[i].key_name;
	    break;
	  case FREE_DATA_AND_KEY_MEMORY:
	    delete slots[i].key_name;		  
	    if(slots[i].entry_data != NULL)
	      {
		delete slots[i].entry_data;
		slots[i].entry_data = NULL;
	      }
	    break;
	  }

	slots[i].key_name = NULL;
      }

  slotsInUse = 0;
}
