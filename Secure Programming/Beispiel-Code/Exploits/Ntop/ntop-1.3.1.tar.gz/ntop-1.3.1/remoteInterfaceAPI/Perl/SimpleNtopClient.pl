#!/usr/bin/perl

require "NtopRemoteInterface.pl";


$ntopHandle = ntopAPI->new(host => "localhost",
			   port => 3002, 
			   password => "admin");

#$rc = $ntopHandle->findHostByIP("192.168.0.4");

for($i=0; $i<4096; $i++) {
  $ntopHandle->getHostByIndex($i);
  if(($rc = $ntopHandle->returnCode()) == 200) {
    print "$i) '".$ntopHandle->getAttribute("hostSymIpAddress")."'\n";;
  } else {
    print ".";
  }
}

