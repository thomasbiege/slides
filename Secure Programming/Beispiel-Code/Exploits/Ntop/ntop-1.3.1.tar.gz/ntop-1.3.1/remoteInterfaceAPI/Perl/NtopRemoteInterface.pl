#
# L.Deri - May 2000
#

package ntopAPI;

#use strict;

use IO::Socket;


###########################################

sub new
{
  my $this = shift if @_ % 2;
  my $class = ref($this) || $this;

  my %args = @_;

  # Ok, let's bless an object now!
  my $obj = bless {};

  $obj->{host} = $args{host};
  $obj->{port} = $args{port};
  $obj->{password} = $args{password};
  
  $obj->{timeout}     = 10;
  $obj->{maxlen}      = 4096;
  $obj->{returnCode}  = 200;  # OK

  $obj->{hash} = bless {};

  #-- Build the socket and bind to port
  $obj->{sock} = IO::Socket::INET->new(Proto     => 'udp',
				       PeerPort  => $obj->{port},
				       PeerAddr  => $obj->{host})
    or { $obj->{returnCode} = 408 };
  
  $obj;
}

###########################################
# 
# getHostByIndex(idx)
#
###########################################

sub getHostByIndex {
  my $obj = shift;
  local($idx)=@_;

  return($obj->sendServerMsg("gethostbyindex ".$idx));
}


###########################################
# 
# findHostByIP(ipAddress)
#
###########################################

sub findHostByIP {
  my $obj = shift;
  local($ipAddress)=@_;

  return($obj->sendServerMsg("findhostbyip ".$ipAddress));
}


###########################################
# 
# findHostByMAC(macAddress)
#
###########################################

sub findHostByMAC {
  my $obj = shift;
  local($macAddress)=@_;

  return($obj->sendServerMsg("findhostbymac ".$macAddress));
}


###########################################
# 
# getObject
#
###########################################

sub getObject {
  my $obj = shift;
  
  return($obj->{hash});
}


###########################################
# 
# returnCode
#
###########################################

sub returnCode {
  my $obj = shift;
  
  return(int($obj->{returnCode}));
}


###########################################
# 
# getAttribute(attributeName)
#
###########################################

sub getAttribute {
  my $obj = shift;
  local($attribute)=@_;
  
  return($obj->{hash}->{$attribute});
}


###########################################
# 
# sendServerMsg(message)
#
###########################################

sub sendServerMsg {
  my $obj = shift;
  my $ok=1;
  local($message)=@_;

  $obj->{hash} = bless {};

  $msg = "";

  #-- Send a msg to the server    

  #print "sending $message\n";
  $obj->{sock}->send($message) or die "send: $!";
  
  #-- Alarm loop
  local $SIG{ALRM} = sub { $ok=0; };
  alarm $obj->{timeout};
  
  #-- Receive msg from the server
  $obj->{sock}->recv($msg, $obj->{maxlen}) or die "recv: $!";
  
  alarm 0;
  
  if($ok == 1) {
    @in = split(/\t/, $msg);
    my $i=0;   
    
    ($obj->{returnCode}, $msg) = $in[$i++];
    
    if($obj->{returnCode} == 200) {    
      $obj->{hash}{lastSeen} = $in[$i++];
      $obj->{hash}{ethAddressString} = $in[$i++];
      $obj->{hash}{hostNumIpAddress} = $in[$i++];
      $obj->{hash}{hostSymIpAddress} = $in[$i++];
      $obj->{hash}{osName} = $in[$i++];
      $obj->{hash}{nbNodeType} = $in[$i++];
      $obj->{hash}{nbHostName} = $in[$i++];
      $obj->{hash}{nbDomainName} = $in[$i++];	
      $obj->{hash}{atNetwork} = $in[$i++];
      $obj->{hash}{atNode} = $in[$i++]; 
      $obj->{hash}{atNodeName} = $in[$i++];
      $obj->{hash}{ipxNodeType} = $in[$i++];
      $obj->{hash}{ipxHostName} = $in[$i++];       
      $obj->{hash}{pktSent} = $in[$i++];
      $obj->{hash}{pktReceived} = $in[$i++];
      $obj->{hash}{pktBroadcastSent} = $in[$i++]; 
      $obj->{hash}{bytesBroadcastSent} = $in[$i++];
      $obj->{hash}{pktMulticastSent} = $in[$i++];
      $obj->{hash}{bytesMulticastSent} = $in[$i++];
      $obj->{hash}{pktMulticastRcvd} = $in[$i++];
      $obj->{hash}{bytesMulticastRcvd} = $in[$i++];
      $obj->{hash}{bytesSent} = $in[$i++];
      $obj->{hash}{bytesSentLocally} = $in[$i++]; 
      $obj->{hash}{bytesSentRemotely} = $in[$i++];
      $obj->{hash}{bytesReceived} = $in[$i++]; 
      $obj->{hash}{bytesReceivedLocally} = $in[$i++];
      $obj->{hash}{bytesReceivedFromRemote} = $in[$i++];
      $obj->{hash}{actualRcvdThpt} = $in[$i++];
      $obj->{hash}{lastHourRcvdThpt} = $in[$i++]; 
      $obj->{hash}{averageRcvdThpt} = $in[$i++]; 
      $obj->{hash}{peakRcvdThpt} = $in[$i++];
      $obj->{hash}{actualSentThpt} = $in[$i++];
      $obj->{hash}{lastHourSentThpt} = $in[$i++]; 
      $obj->{hash}{averageSentThpt} = $in[$i++];
      $obj->{hash}{peakSentThpt} = $in[$i++];
      $obj->{hash}{actualRcvdPktThpt} = $in[$i++];
      $obj->{hash}{averageRcvdPktThpt} = $in[$i++];
      $obj->{hash}{peakRcvdPktThpt} = $in[$i++];
      $obj->{hash}{actualSentPktThpt} = $in[$i++];
      $obj->{hash}{averageSentPktThpt} = $in[$i++]; 
      $obj->{hash}{peakSentPktThpt} = $in[$i++];
      $obj->{hash}{actBandwidthUsage} = $in[$i++];    
      $obj->{hash}{ipxSent} = $in[$i++]; 
      $obj->{hash}{ipxReceived} = $in[$i++];
      $obj->{hash}{osiSent} = $in[$i++]; 
      $obj->{hash}{osiReceived} = $in[$i++];
      $obj->{hash}{dlcSent} = $in[$i++]; 
      $obj->{hash}{dlcReceived} = $in[$i++];
      $obj->{hash}{arp_rarpSent} = $in[$i++]; 
      $obj->{hash}{arp_rarpReceived} = $in[$i++];
      $obj->{hash}{decnetSent} = $in[$i++];
      $obj->{hash}{decnetReceived} = $in[$i++];
      $obj->{hash}{appletalkSent} = $in[$i++]; 
      $obj->{hash}{appletalkReceived} = $in[$i++];
      $obj->{hash}{netbiosSent} = $in[$i++]; 
      $obj->{hash}{netbiosReceived} = $in[$i++];
      $obj->{hash}{qnxSent} = $in[$i++]; 
      $obj->{hash}{qnxReceived} = $in[$i++];
      $obj->{hash}{otherSent} = $in[$i++]; 
      $obj->{hash}{otherReceived} = $in[$i++];    
    
      bless $obj->{hash};
    }
  }

  return(0);
}


###########################################

1;

__END__
